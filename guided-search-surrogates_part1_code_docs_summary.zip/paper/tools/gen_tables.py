# Generates the LaTeX tables of the manuscript from the result files in results/.
# Usage: python paper/tools/gen_tables.py results paper/tables
import pandas as pd, numpy as np, json, glob, os, sys
S = sys.argv[1]; OUT = sys.argv[2]; os.makedirs(OUT, exist_ok=True)
C2, MC, FB = f'{S}/C2', f'{S}/MCD', f'{S}/FB2'
GJ = ['C-RN', 'S-RN', 'S-ViT']; GR = ['C-ViT', 'I-RN']; GA = GJ + GR
GN = {'C-RN': 'CIFAR RN', 'S-RN': 'Shapes RN', 'S-ViT': 'Shapes ViT', 'C-ViT': 'CIFAR ViT', 'I-RN': 'ImageNet RN'}
f3 = lambda x: ('$-$' if x < 0 else '') + f'{abs(x):.3f}'.lstrip('0') if np.isfinite(x) else '--'
s3 = lambda x: ('$+$' if x >= 0 else '$-$') + f'{abs(x):.3f}'.lstrip('0')
def w(name, s): open(f'{OUT}/{name}.tex', 'w').write(s)

# ---- Table: main pre-registered results
V = pd.read_csv(f'{C2}/C2_verdict.csv')
rows = [('H0a', 'H0 ★', 'Decision fidelity vs.\\ original method', 0), ('H0b', 'H0 ★', 'Region-swap fidelity vs.\\ original method', 1), ('H1', 'H1 ★', 'Decision fidelity vs.\\ position mean', None),
        ('H2', 'H2 ★', 'Axis-swap fidelity vs.\\ position mean', None), ('H6', 'H6 ★', 'Real-counterfactual fidelity vs.\\ position mean', None)]
lines = []
for key, no, desc, nth in rows:
    cells = []
    for g in GA:
        sub = V[(V.group == g) & (V.no == no)]
        if nth is not None: sub = sub.iloc[[nth]] if len(sub) > nth else sub.iloc[0:0]
        if not len(sub): cells.append('--'); continue
        r = sub.iloc[0]; star = '$^{\\dagger}$' if r.verdict == 'confirmed' else ''
        cells.append(f'{s3(r["mean"])}{star} ({int(r.win)}/{int(r.n)})')
    lines.append(f'{key} & {desc} & ' + ' & '.join(cells) + ' \\\\')
w('tab_main', '\n'.join(lines))
pmax = V[V.group.isin(GJ) & V.no.isin(['H0 ★', 'H1 ★', 'H2 ★', 'H6 ★'])].p_holm.max(); print('max p_holm main', pmax)

# ---- Table: scoring rules (k = 16)
F = pd.read_csv(f'{C2}/C2_rules_fid.csv'); F = F[F.k == 16].set_index('group'); NP = pd.read_csv(f'{C2}/C2_rules_nparam.csv'); NP = NP[NP.k == 16].set_index('group')
RG = pd.read_csv(f'{C2}/C2_rules_cf_reg.csv'); RG = RG[RG.k == 16].set_index('group')
RL = [('mean', 'Position mean (original rule)'), ('mlp_pool', 'Pooled MLP, parameter-matched'), ('whatwhere2', 'Static spatial map (SF-type)'), ('tvaf_where', 'TVA weights + class priors'),
      ('poslin', 'Position-wise linear'), ('spotlight', 'Spotlight only'), ('guided', 'Guided search only'), ('gs_spot', '\\textbf{Guided search + spotlight (ours)}')]
lines = []
for r, nm in RL:
    best = lambda g: F.loc[g, r] >= max(F.loc[g, x] for x, _ in RL) - 1e-9
    cells = [(('\\textbf{' + f3(F.loc[g, r]) + '}') if best(g) else f3(F.loc[g, r])) for g in GA]
    lines.append(f'{nm} & ' + ' & '.join(cells) + f' & {f3(RG.loc["C-RN", r]) if r != "mlp_pool" or True else "--"} & {int(NP.loc["C-RN", r])} \\\\')
w('tab_rules', '\n'.join(lines))

# ---- Table: dictionaries (fidelity with GS-spot, decision ceiling)
DD = pd.read_csv(f'{C2}/C2_all.csv'); DD = DD[DD.k == 16]; MM = pd.read_csv(f'{MC}/MCD_all.csv')
def dv(g, d, rule):
    if d == 'mcd':
        x = MM[(MM.group == g) & (MM.dict == 'mcd') & (MM.rule == rule)].fid; return x.mean() if len(x) else np.nan
    x = DD[(DD.group == g) & (DD.dict == d) & (DD.rule == rule)].fid; return x.mean() if len(x) else np.nan
DL = [('lrp_svd', 'LRP-SVD (original)'), ('pca', 'PCA'), ('prca', 'PRCA'), ('nmf', 'NMF (CRAFT/ICE)'), ('sae', 'SAE ($k$ atoms)'), ('mcd', 'MCD'), ('tvo', '\\textbf{tv-O (ours)}')]
lines = []
for d, nm in DL:
    c1 = [dv(g, d, 'gs_spot') for g in GA]; c2 = [dv(g, d, 'proj') for g in GA]
    def fmt(v, g, rule):
        if not np.isfinite(v): return '--'
        b = max(dv(g, x, rule) for x, _ in DL if np.isfinite(dv(g, x, rule))); return ('\\textbf{' + f3(v) + '}') if v >= b - 1e-9 else f3(v)
    lines.append(f'{nm} & ' + ' & '.join(fmt(v, g, 'gs_spot') for v, g in zip(c1, GA)) + ' & ' + ' & '.join(fmt(v, g, 'proj') for v, g in zip(c2, GA)) + ' \\\\')
lines.append('\\midrule')
tk = [dv(g, 'sae_topk', 'gs_spot') for g in GA]; tk2 = [dv(g, 'sae_topk', 'proj') for g in GA]
lines.append('TopK SAE ($4k$ atoms)$^{\\ast}$ & ' + ' & '.join(f3(v) for v in tk) + ' & ' + ' & '.join(f3(v) for v in tk2) + ' \\\\')
w('tab_dicts', '\n'.join(lines))

# ---- Table: distribution shift of axis swaps
O = pd.read_csv(f'{C2}/C2_ood.csv')
def ood(g, d):
    if d == 'mcd':
        x = MM[(MM.group == g) & (MM.dict == 'mcd') & (MM.rule == 'ood')]; return (x.ratio.mean(), x.out99.mean()) if len(x) else (np.nan, np.nan)
    x = O[(O.group == g) & (O.kind == ('region' if d == 'region' else f'axis|{d}'))]; return (float(x.ratio.iloc[0]), float(x.out99.iloc[0])) if len(x) else (np.nan, np.nan)
OL = DL[:5] + [('mcd', 'MCD'), ('sae_topk', 'TopK SAE ($4k$)'), ('tvo', '\\textbf{tv-O (ours)}'), ('region', 'Region swap (shared)')]
lines = []
for d, nm in OL:
    cells = []
    for g in GA:
        r_, o_ = ood(g, d); cells.append('--' if not np.isfinite(r_) else f'{r_:.2f} ({o_*100:.1f})')
    lines.append(f'{nm} & ' + ' & '.join(cells) + ' \\\\')
w('tab_ood', '\n'.join(lines))

# ---- Table: map metrics
DI = pd.read_csv(f'{C2}/C2_delins.csv').set_index('group'); MS = pd.read_csv(f'{C2}/C2_maxsens.csv').set_index('group'); SA = pd.read_csv(f'{C2}/C2_sanity.csv').set_index('group')
ML = [('ours', 'Ours'), ('orig', 'Original method'), ('static', 'Static map'), ('gradcam', 'Grad-CAM (same layer)'), ('gradcam_last', 'Grad-CAM (last layer)'), ('ig', 'IG'), ('gxi', 'Grad$\\times$Input')]
lines = []
for m, nm in ML:
    a = [f3(DI.loc[g, m]) for g in GA]; b = [f3(MS.loc[g, m]) if m in MS.columns else '--' for g in GJ + GR]; c = [f3(SA.loc[g, m]) if m in SA.columns else '--' for g in GA]
    lines.append(f'{nm} & ' + ' & '.join(a) + ' & ' + ' & '.join(c) + ' \\\\')
w('tab_maps', '\n'.join(lines))
lines = []
for m, nm in [x for x in ML if x[0] in MS.columns]:
    lines.append(f'{nm} & ' + ' & '.join(f'{MS.loc[g, m]:.4f}'.lstrip('0') for g in GA) + ' \\\\')
w('tab_maxsens', '\n'.join(lines))

# ---- Table: A1 shortcut audit (all 27 Shapes networks)
A = pd.read_csv(f'{C2}/C2_A1_audit.csv'); A = A[A.group == 'S-all']
lines = []
for m, nm in [('ours', 'Ours'), ('gradcam', 'Grad-CAM (same layer)$^{\\ddagger}$'), ('gradcam_last', 'Grad-CAM (last layer)$^{\\ddagger}$'), ('ig', 'IG$^{\\ddagger}$'), ('gxi', 'Grad$\\times$Input'), ('static', 'Static map'), ('orig', 'Original method')]:
    r = A[A.method == m].iloc[0]; d = '--' if m == 'ours' else f'[{s3(r.ours_minus_lo)}, {s3(r.ours_minus_hi)}]'
    lines.append(f'{nm} & {s3(r.spearman)} & [{s3(r.ci_lo)}, {s3(r.ci_hi)}] & {d} \\\\')
w('tab_a1', '\n'.join(lines))

# ---- Table: A2 risk prediction
RK = {g: [] for g in ['C-RN', 'C-ViT']}
for f in glob.glob(f'{C2}/per_network/r3_C-*.json'):
    R = json.load(open(f)); g = 'C-RN' if 'C-RN' in f else 'C-ViT'; RK[g].append({k: R['risk'][k]['brier'] for k in ['tvo_cp|16', 'pca_or|16', 'ta_or|16', 'cpta_cp|16', 'rand_cp|16', 'full|0', 'noisyor_case', 'noisyor_rate', 'oracle_rate']})
lines = []
for k, nm in [('tvo_cp|16', '\\textbf{tv-O axes (ours)}'), ('pca_or|16', 'PCA axes'), ('ta_or|16', 'TA axes'), ('cpta_cp|16', 'CP-TA axes'), ('rand_cp|16', 'Random axes'), ('full|0', 'Full hidden state'), ('noisyor_case', 'Noisy-OR, per image (axis-free)'), ('noisyor_rate', 'Noisy-OR, rates (axis-free)'), ('oracle_rate', 'Oracle pair rate$^{\\ast}$')]:
    cells = []
    for g in ['C-RN', 'C-ViT']:
        x = np.array([d[k] for d in RK[g]]); cells.append(f'{x.mean():.3f}'.lstrip('0') + f' $\\pm$ {x.std(ddof=1):.3f}'.replace('0.', '.'))
    lines.append(f'{nm} & ' + ' & '.join(cells) + ' \\\\')
w('tab_a2', '\n'.join(lines))

# ---- Table: FunnyBirds
M = pd.read_csv(f'{FB}/FB2_metrics.csv'); RJ = json.load(open(f'{FB}/res_FB2.json'))
FL = {'resnet50': [('ours', 'Ours'), ('orig', 'Original method'), ('IG', 'IG'), ('GradCAM', 'Grad-CAM'), ('InputXGradient', 'Input$\\times$Gradient')],
      'vit': [('ours', 'Ours$^{\\S}$'), ('orig', 'Original method$^{\\S}$'), ('IG', 'IG'), ('CheferLRP', 'Chefer LRP'), ('ViTGradCAM', 'Grad-CAM'), ('Rollout', 'Rollout'), ('InputXGradient', 'Input$\\times$Gradient')]}
lines = []
for kind, lab in [('resnet50', 'ResNet-50'), ('vit', 'ViT-B/16')]:
    lines.append(f'\\multicolumn{{10}}{{l}}{{\\textit{{{lab}}}}} \\\\')
    for m, nm in FL[kind]:
        r = M[(M.model == kind) & (M.method == m)].iloc[0]; sf = RJ[kind]['surrogate'].get(m, {}).get('fid_holdout', np.nan) if m in ('ours', 'orig') else np.nan
        lines.append(f'{nm} & ' + ('--' if not np.isfinite(sf) else f3(sf)) + ' & ' + ' & '.join(f3(r[c]) for c in ['CSDC', 'PC', 'DC', 'D', 'SD', 'TS', 'Com', 'mX']) + ' \\\\')
    lines.append('\\midrule')
w('tab_fb', '\n'.join(lines[:-1]))
print('done')
