# Redraws Figure 5 (shortcut audit scatter) from the per-network results.
# Usage: python paper/tools/fig_a1_scatter.py results/C2/per_network figures/fig_A1_scatter_col.png
import json, glob, sys, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.stats import spearmanr
D, OUT = sys.argv[1], sys.argv[2]
S = []
for f in sorted(glob.glob(f'{D}/r3_S-*_rho*_s*.json')):
    d = json.load(open(f)); g = f.split('r3_')[1].split('_')[0]; rho = float(f.split('rho')[1].split('_')[0]); S.append((g, rho, d))
y = np.array([d['R_floor'] for _, _, d in S]); cr = np.array([r for _, r, _ in S]); vit = np.array([g == 'S-ViT' for g, _, _ in S])
M = [('ours', 'Ours'), ('gradcam', 'Grad-CAM (same layer)'), ('gradcam_last', 'Grad-CAM (last layer)'), ('ig', 'IG')]
plt.rcParams.update({'font.size': 7})
fig, axs = plt.subplots(2, 2, figsize=(3.5, 3.4), sharey=True)
for j, (k, t) in enumerate(M):
    ax = axs.flat[j]; x = np.array([d['floor_share'][k] for _, _, d in S])
    for sel, m, lab in [(~vit, 'o', 'ResNet'), (vit, '^', 'ViT')]:
        sc = ax.scatter(x[sel], y[sel], c=cr[sel], cmap='viridis', vmin=0, vmax=1, marker=m, s=14, label=lab, edgecolors='none')
    ax.set_title(f'{t}\nSpearman {spearmanr(x, y).correlation:.2f}', fontsize=6.5, pad=3); ax.tick_params(labelsize=6)
axs[0, 0].legend(fontsize=5.5, loc='upper left', handletextpad=0.2, borderpad=0.3)
fig.subplots_adjust(left=0.13, right=0.84, bottom=0.11, top=0.91, wspace=0.12, hspace=0.45)
fig.text(0.485, 0.02, 'floor share of positive evidence', ha='center', fontsize=6.5)
fig.text(0.02, 0.5, 'floor reliance (decision flip rate)', va='center', rotation=90, fontsize=6.5)
cax = fig.add_axes([0.87, 0.2, 0.025, 0.6]); cb = fig.colorbar(sc, cax=cax); cb.ax.tick_params(labelsize=6); cb.ax.set_title(r'$\rho$', fontsize=7)
fig.savefig(OUT, dpi=300); print(len(S), 'networks')
