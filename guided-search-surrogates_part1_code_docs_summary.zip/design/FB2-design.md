# FB2: FunnyBirds re-run (exploratory, 2026-11-11)

*Translated from the Korean original without changes in content. In the paper (Section V-F), the first run with 2000 probe images and k = 16, its fidelity below .30, and the resulting change of settings are stated, and the results of this re-run are reported in Table 9 outside the pre-registered hypotheses.*

This re-run is not pre-registered. The settings were changed after the C2 results were seen, so it is to be marked "exploratory" in the paper.

## Why re-run
In the FunnyBirds part of C2, the surrogate did not track the network. Fidelity on separate training images was .285 for ours and .508 for the original method, compared with .85–.92 in the main study.

Under the same conditions, mX for ResNet-50 was:

| Method | mX |
|---|---|
| Ours | .64 |
| Original method | .73 |
| IG | .81 |

Two likely causes:
- There are 50 classes but only 16 axes.
- The probe set is small: 2000 images, 40 per class.

## Changes (fixed before results were seen, applied equally to ours and the original method)
- **Probe set:** increased to 5000 images. The 1000 separate training images are unchanged.
- **Number of axes k:** for each method, the value in {16, 32, 64} with the highest fidelity on the separate training images; ties go to the smaller k.
- **Unchanged:** λ selection, fitting, and the official metrics are the same as C2. Test images are not used.
- **Comparison methods:** IG, Grad-CAM, and Input×Gradient are taken from the C2 results, since the checkpoints, subsets, and seeds are the same; they are not re-run.

## Reported
- Probe fidelity and fidelity on the separate images for each k
- The six official metrics + mX
- Paired comparisons over the five subsets
- The C2 results at k = 16 are reported as well.

## Interpretation rule
- If surrogate fidelity remains low (e.g., < .7), the FunnyBirds results are reported as "a condition in which the surrogate did not track the network" and are not used as evidence of explanation quality.
