# Additional comparison with MCD (2026-11-11, not pre-registered)

*Translated from the Korean original without changes in content. In the paper, this comparison is reported in Section V-C and Table 4 as its own test family under the same decision rule, separate from the pre-registered hypotheses of Table 2.*

This comparison was added after the C2 results were seen. MCD (Vielhaben, Blücher & Strodthoff, TMLR 2023) represents concepts as subspaces and is therefore the competitor closest to tv-O. It was added because reviewers are likely to ask about it.

## Conditions (same as C2)
- **Networks:** the same 46 networks as C2. CIFAR seeds 5–12 use the files trained in C2.
- **Data:** the same explanation layer, probe images, and test images as C2.
- **Interventions:** region swaps and axis swaps use the same seeds as C2.
- **Fitting:** λ selection and the scoring models (position mean, main rule) are the same as C2.
- **Paired comparison:** tv-O is refitted in the same run for a paired comparison. Its values are compared with those of C2 to check reproducibility.

## MCD implementation (defaults of the original paper)
1. 1000 position features from the probe set are normalized to unit length.
2. Elastic-net subspace clustering (EnSC, You+2016) with γ = 10, τ = .9, and penalty λ_max/γ.
3. The top 25% by ‖r‖₁ are removed as outliers and the model is refitted.
4. Spectral clustering on |R| + |Rᵀ| with n_c = 4 concepts.
5. For each cluster, a subspace from uncentered PCA. The dimension is 4, so the total is 16 = k, the same code dimension as tv-O.
6. Coordinates by oblique projection (least squares), relative to the origin.

**Differences from the original paper:** the original uses the last layer, class-specific concepts, and intrinsic-dimension estimation. Here the conditions are matched to the other dictionaries (explanation layer, shared across classes, same code dimension).

## Verdicts (separate family "MCD (additional)", Holm, same decision rule as C2)

| No. | Comparison | Threshold |
|---|---|---|
| M1 | Fidelity on the main rule: tv-O > MCD | 0 |
| M2 | Axis ceiling: tv-O > MCD | 0 |

**Reported only:**
- M3: region-swap interventional fidelity
- M4: fidelity on the position mean
- M5: main rule − position mean on MCD
- M6: distribution shift of axis swaps

Groups C-ViT and I-RN are reported only.
