# Confirmatory study C1: design v4 (2026-11-11; rigor audit and external review incorporated; FunnyBirds, figures, and outputs fixed before results were seen)

*Translated from the Korean original without changes in content. The study was planned under the working name C1 and executed as the notebook `xai_C2.ipynb` (Drive folder `xai_C2`). Figure numbers and section names below are those planned at the time; see the paper for the final ones.*

- **Notebook:** `xai_C1.ipynb`
  - A single cell that resumes network by network.
  - The Drive folder is `xai_C1`.
  - There are no v1 or v2 results, so v3 is the first confirmatory run. Result files are `r3_*.json`.
- **Pilots this design rests on:** S1p–S5p
  - The attainable gain from the decision rule was ≈ 0.
  - There was large room for gain from the spatial (position) rule.
  - The main rule was fixed in S5p.

## Method (fixed)
- **Axes:** class-global tv-O. k = 16, with k = 8 as a secondary setting. Codes are produced for every position (token).
  - For ViTs, the CLS token is excluded and only patch tokens are used. Writes also go to patch tokens only.
- **Scoring model:** guided search (Wolfe 1994) combined with the attentional spotlight (Eriksen & St. James 1986).
  - Priority map: p_x,c = λ_x − |x − c_c|²/(2 s_c²) + Σ_j Π_jc |z_xj|
  - Attention: softmax over x
  - Score: score_c = Σ_x a_x,c (z_x · B_c) + b_c
- **Fitting (common to all scoring models and dictionaries, v2):**
  - Only probe images (held out from the training split) are used. Labels are the network's predictions.
  - Loss: cross-entropy + λ·||W||²/(2n).
  - Optimization: full-batch Adam for **1200 steps**, the same for every rule. Only poslin uses lr .01 (ceiling / reported only).
  - **λ ∈ {1, 0.3, 3}** is chosen by agreement on a 20% validation split of the probe set. The same procedure applies to every (dictionary, rule) pair; ties go to 1.
  - λ is chosen at k = 16 and reused at k = 8. After λ is chosen, the model is refitted on the whole probe set.
  - Test images are not used to choose λ.

## Controls (same network, layer, probe set, optimization, and λ selection)
- **Scoring models:**
  - Position mean + weighted sum (original method)
  - Fixed spatial map × feature weights (the form of Kumar+2025 SF and Klindt+2017)
  - Full position-wise linear (ceiling)
  - Full TVA + class-specific spatial prior (secondary)
  - **Component ablations (v2):** guidance only (Π, λ_x); spotlight only (center c, width s, λ_x)
- **Dictionaries:**
  - PRCA
  - LRP-SVD (original method)
  - PCA
  - NMF (CRAFT-style, CNNs only)
  - SAE (k atoms, same dimension; used in verdicts)
  - **TopK SAE** (4k atoms, k active; Gao+2024; reported only, v2)
- **Maps:**
  - Grad-CAM (same layer)
  - **Standard Grad-CAM (last layer, v2)**
  - IG (zero baseline, 32 steps)
  - grad×input

## Interventions
- **Axis swap (H2):** for each dictionary, k/2 of its own axes are replaced by the values of a donor image. Only rules on the same dictionary are compared.
- **Region swap (v2; a common intervention independent of the dictionary):** for each image, the hidden state in one of the top, bottom, left, or right halves is replaced by the donor's.
  - All dictionaries and rules are evaluated on the same set of interventions, so this is used for H0, which compares methods with different dictionaries.

## Networks (not used in the pilots)
| Group | Networks | n | Verdict |
|---|---|---|---|
| C-RN | CIFAR-10 ResNet-18, seeds **3–12** (if missing, trained with the same split and recipe) | 10 | ① + ② |
| S-RN | Shapes3D 11d ResNet-18, ρ .25 · .75 · .9 × seeds 2–4 | 9 | ① + ② |
| S-ViT | Shapes3D 13V ViT, 6 values of ρ × seeds 2–4 | 18 | ① + ② |
| C-ViT | CIFAR-10 ViT-S/16 (stage2) | 3 | reported |
| **I-RN** | Imagenette 160 (probe: 4000 training images; test: 3925 validation images), six torchvision ImageNet ResNets (18 · 34 · 50 V1 · 50 V2 · 101 · 152), logits of the 10 classes | 6 | reported |

Power (minimum Wilcoxon p when every network favors ours):
- n = 10: .002
- n = 9: .0039
- n = 18: 2e-5

In v1, C-RN had n = 7, whose minimum p of .0156 could never pass Holm in a family of four or more. It was therefore increased to n = 10.

## Pre-registration (network as the unit, core.judge)
There are two decision criteria (v3):
- ① d > 0 in at least ⌈5/6·n⌉ networks, and the mean of d exceeds the threshold.
- ② A one-sided Wilcoxon test (alternative: median > 0) on **d − threshold**, Holm-corrected within the family.
  - For non-inferiority rows (H3, H4b) and K1, K2, the margin or threshold is already added to d, so they are tested with threshold 0. The test is then itself the non-inferiority / above-threshold test.
  - "Not significant, therefore non-inferior" is never used as a verdict.
- Bootstrap 95% CIs of the mean of d (resampling networks) are also reported.

A hypothesis is confirmed when both pass. The two-sided test of v2 was changed to one-sided because the direction was pre-registered and the test that only compared with 0 had to take the threshold into account.

| No. | Comparison | Threshold | Family |
|---|---|---|---|
| **H0 ★** | Fidelity: tv-O + main rule > LRP-SVD + position mean (the original method as is) | .01 | original method |
| **H0 ★** | Region-swap interventional fidelity: tv-O + main rule > LRP-SVD + position mean | .01 | original method |
| H1 ★ | Fidelity: main rule > position mean (on tv-O) | .01 | fidelity |
| H2 ★ | Axis-swap interventional fidelity: main rule > position mean | .01 | fidelity |
| H3 ★ | Non-inferior fidelity: main rule ≥ fixed spatial map − .01 | 0 | fidelity |
| H6 ★ | Real-counterfactual fidelity (Shapes3D): main rule > position mean | .01 | fidelity |
| H4 ★ | Dictionary (on the main rule): tv-O > PCA · NMF · SAE | 0 | dictionary |
| H5 ★ | Axis ceiling: tv-O > PRCA · LRP-SVD · PCA | 0 | dictionary |
| H4b | Dictionary non-inferiority: tv-O ≥ PRCA · LRP-SVD − .005 | 0 | **dictionary non-inferiority** (separated in v2) |
| A2 ★ | Compound-corruption risk Brier: tv-O < noisy-OR (per image · rates) · TA · CP-TA · PCA | 0 | application (group C) |
| K1 ★ | Kelley attribution (on the main rule) > post hoc assignment + .05 | 0 | Kelley (S-RN) |
| K2 ★ | Kelley fidelity: main rule ≥ position mean + .05 | 0 | Kelley (S-RN) |

**H5 (ViT):** the original definition is used, in which the CLS token keeps its original value.
- Every dictionary receives the same treatment, so the comparison is fair.
- Absolute values are inflated, however, so a ceiling with the CLS token replaced by its probe mean is reported separately.

**Reported (no verdict)**
- R1: insertion − deletion AUC (Petsiuk+2018). Ours vs. Grad-CAM (same and last layer), IG, the original method, and the fixed spatial map.
- R2: Max-Sensitivity (Yeh+2019, r = 2/255). Ours vs. Grad-CAM at both layers and IG.
- R3: |rank correlation| after randomizing downstream layers (Adebayo+2018), on three networks per group.
  - λ is the value chosen on the original network.
  - Last-layer Grad-CAM is included.
- R4: probability EMD (Kumar+2025)
- R5: component ablations: main rule − guidance only, main rule − spotlight only.
- R6: tv-O − TopK SAE
- R7: region-swap interventional fidelity: main rule − fixed spatial map.
- **R8 (v3):** a non-spatial control with matched parameter count (main rule − mlp_pool).
  - mlp_pool places a hidden-layer MLP after position averaging. The hidden size is set so that the parameter count equals that of the main rule.
  - This control separates the effect of added capacity from that of spatial attention.
  - More expressive spatial controls already exist. For CIFAR ResNets, the fixed spatial map has about 4× and the position-wise linear readout about 24× the parameters (about 9× and 66× for Shapes ResNets).
  - The spotlight-only rule serves as an input-independent attention control.
- **R9 (v3):** A2 reference. An oracle Brier score that uses the true flip rate of each combination; used only as a reference, not as a control.
- **Intervention reliability (v3):**
  - Dose-response: at ¼, ½, and ¾ of the axes swapped, measure the change in the network's decisions and the agreement of the scoring model.
  - Distribution shift: whitened distance, as the ratio of the mean to that of natural hidden states, and the fraction of positions beyond the natural 99th percentile. Natural hidden states give 1 and .01, respectively.
  - Interventional fidelity in these experiments is called "representation-level interventional fidelity". It is not claimed to prove causation in the input world.
- **Differences by ρ (v3):** for the S groups, main rule − control is reported by ρ as mean, minimum, and maximum.
  - Groups are already judged separately by architecture (CNNs and ViTs are not pooled).
- **Logged checks (v3):**
  - Convergence: relative decrease of the loss over the last 10% of steps
  - tv-O eigenvalue gap λ_k / λ_k+1
  - Model file path and md5, library versions
- Groups C-ViT and I-RN are reported only, for every item.

**Application A1 (shortcut audit, Shapes3D)**
- Measure: Spearman correlation, across networks, between the share an explanation places on the floor region and the true floor-color reliance.
  - True floor-color reliance is the rate at which decisions flip on real counterfactuals that change only the floor color.
  - The floor region is the set of pixels that change when only the floor color changes.
- **Primary analysis (fixed in v2):** comparison over all 27 networks (S-all).
  - Controls: Grad-CAM (same layer), Grad-CAM (last layer), and IG.
  - Ours is superior if the bootstrap 95% CI of ours − control (2000 resamples of networks) lies above 0.
  - Per-group comparisons and other controls are reported only.
- **Secondary analysis: stratified (v3, removing ρ confounding)**
  - Within each architecture × ρ stratum (three seeds), both quantities are ranked and centered. The ranks are pooled across strata to compute the correlation.
  - The bootstrap resamples within strata.
  - This leaves only differences between networks with the same ρ and architecture. Because the within-stratum differences are only seed noise, the low power of this analysis is stated.
- **Denominator (v3):** images whose total positive evidence is at most 1e-8 of the maximum in that map group are excluded from the mean.

## FunnyBirds (v4, reported)
- **Setting:** the official checkpoints of Hesse+2023 (ResNet-50, ViT-B/16) and the six official metrics (CSDC, PC, DC, D, SD, TS).
  - The five test subsets are the same split as in P5.
  - Paired comparisons across subsets, with Holm correction over the six metrics.
- **Five methods:**
  - Ours: tv-O + main rule
  - Original method: LRP-SVD + position mean
  - IG, Input×Gradient, Grad-CAM (ResNet-50 layer4)
- **Fitting:**
  - The probe set is 2000 FunnyBirds training images, labeled with the network's predictions.
  - λ selection and fitting are as in the main study (k = 16).
  - The surrogate's fidelity is checked on 1000 separate training images.
- **Verdict:** none; reported only. The IG and Grad-CAM values of the original paper are listed for reference.

## Example maps and figures (v4)
- **Saving:** for each network, the inputs, predicted classes, and maps of all methods for the first 8 map images are saved to `maps_*.npz`.
- **Figures:**
  - Figure 1: maps by method for each group
  - Figure 2: our maps for S-RN networks with different ρ and the same seed (shortcut audit example)
  - Figure 3: A1 scatter plots (27 networks, 4 methods)
- Figures only summarize results and are not used for verdicts.

## Expectations and what to report honestly
- **H3:** may fail on Shapes3D. In the pilot the fixed spatial map was +.02. Tuning λ may favor the fixed spatial map further.
- **H4b:** likely to be at the same level as PRCA and LRP-SVD.
- **Kelley:** not applied to ViTs.
  - It is a **supervised extension** that uses factor labels. It is not claimed to discover factors without labels.
  - Subspaces are built from probe counterfactual pairs (checked in the code), and attribution is measured on test bases.
- **A2:** σ and the slope of the combination rule are fitted on single corruptions only. Combined images are used only for comparison with the ground truth (checked in the code).
  - The unit of inference is the network. Dependence between images does not affect the network-level test.
- **Naming:** the position-wise linear readout (poslin) is called "a highly expressive position-wise linear baseline", not a "ceiling".
- **Paper structure:**
  - Core: H0, H1, H2, H4, H5 (axes and scoring model, interventional fidelity)
  - Explanation-map evaluation R1–R3: secondary
  - Main application: A1
  - Additional application: A2
  - Separate extension: Kelley
- **Kumar SF:** reproduced as the fixed spatial form under the same optimization. No comparison with OF (learned concepts).
- **Limitations:**
  - No human-subject experiment.
    - S-RN has n = 9, so power is borderline. With 8/9 networks favoring ours, p ≈ .008.
  - Newly trained CIFAR seeds may mix training recipes with existing models (the recipe is recorded).
  - For I-RN, the probe images are ImageNet training images and the test images are ImageNet validation images; that is, the probe images were seen by the network during training.
  - Axis-swap and region-swap interventions in ViTs do not change the CLS token.
