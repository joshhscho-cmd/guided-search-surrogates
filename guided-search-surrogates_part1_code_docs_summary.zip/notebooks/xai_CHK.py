# ===================================================================================================
# XAI paper experiment CHK (single cell): C2 checks: convergence sensitivity of fitting (1200 · 3600 steps, H1 · H3 re-judged) + Shapes3D figures on noise-free originals
#   method = final model 1–5 (core, sha1 64099c2a4cd7) · design: paper-design.md (fixed 2026-11-10; criteria are not changed after seeing results)
#   usage: GPU runtime → allow Drive access → run this single cell (no QUICK mode). Resumes network by network if interrupted. Results · models · code copy: Drive xai_CHK
#   note: comments and log messages translated from Korean for this repository; the code is identical to the runs.
# ===================================================================================================
import os, sys, subprocess, warnings, json, time, hashlib
warnings.filterwarnings('ignore')
VERSION = 'CHK'; D_ = '/content/drive/MyDrive'
try:
    from google.colab import drive; drive.mount('/content/drive')
except Exception as e:
    print('Drive not used:', e)
    if 'google.colab' in sys.modules: raise SystemExit('⚠ Drive connection failed — cannot resume models · results, stopping.')
OUT = f'{D_}/xai_{VERSION}' if os.path.exists(D_) else f'/content/xai_{VERSION}'; os.makedirs(f'{OUT}/paper', exist_ok=True); DATA = f'{D_}/xai_data'
for pkg, mod in [('h5py', 'h5py'), ('timm', 'timm')]:
    try: __import__(mod)
    except ImportError: subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', pkg], check=False)
import sklearn
if tuple(int(x) for x in sklearn.__version__.split('.')[:2]) >= (1, 8): raise SystemExit(f'⚠ scikit-learn 1.6.1 required (now {sklearn.__version__}) → !pip install scikit-learn==1.6.1, then restart the runtime')
try: _SRC = get_ipython().user_ns['In'][-1]; open(f'{OUT}/code_{VERSION}.py', 'w').write(_SRC); print('code copy saved:', f'{OUT}/code_{VERSION}.py')
except Exception as e: print('code copy skipped:', e)
T_ALL = time.time()

# ===================================================================================================
# ↓↓↓ core.py ↓↓↓
# ===================================================================================================
# ===================================================================================================
# core.py — final model (1–5) and baselines. Every P notebook includes this file unchanged (sha1 recorded).
#   1 contrastive tv-O axes · 2 minimal cause (CESM) · 3 lens (pair · instance) · 4 combination risk prediction (Thurstone Case V + Anderson) · 5 Kelley-specific erasure
#   network interface (archs.py): name · dim[l] · to(x, l) · frm(h, l) · advance(h, l0, l1) · units(h) → (B, U, C) · from_units(u, like) · pool(h) → (B, C)
#   random-number formulas and computation order are the same as in the confirmatory versions (stage15 · 19 · 22c · 23).
# ===================================================================================================
import os, sys, io, json, time, math, itertools, warnings, subprocess, tarfile, zipfile, urllib.request, shutil
import pandas as pd, torchvision
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from scipy.stats import norm as _norm, wilcoxon as _wilcoxon
from scipy.linalg import eigh as _geig
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
dev = 'cuda' if torch.cuda.is_available() else 'cpu'

METHOD = dict(K=16, N_AX=2000, PAIR_POOL=300, PAIR_GRAD=150, PATH_A=[0.25, 0.5, 0.75], N_DONOR=8, EIG_FLOOR=1e-3,
              KS=[1, 2, 4, 8, 16], EPS=1e-3, GAIN=0.005, S_TOL=0.01, MAX_EDITS=2, K_DIAG=16, K95_MAX=16, GRIT_R=[1, 2, 4, 8, 16, 32])

def jsonable(o):
    if isinstance(o, dict): return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [jsonable(v) for v in o]
    if isinstance(o, (np.floating, float)): return float(o)                     # keep NaN as is (json writes and reads NaN; converting to None breaks computations after reloading)
    if isinstance(o, (np.integer,)): return int(o)
    if isinstance(o, (np.bool_,)): return bool(o)
    if isinstance(o, np.ndarray): return jsonable(o.tolist())
    if torch.is_tensor(o): return jsonable(o.detach().cpu().numpy())
    return o

def _download(urls, dst, what):
    if os.path.exists(dst): return dst
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    for u in urls:
        try:
            t0 = time.time(); print(f'  {what} downloading ← {u}', flush=True); urllib.request.urlretrieve(u, dst + '.part'); os.replace(dst + '.part', dst); print(f'  done {time.time()-t0:.0f}s', flush=True); return dst
        except Exception as e: print('  failed:', repr(e)[:150], flush=True)
    raise SystemExit(f'⚠ {what} could not be downloaded. {os.path.basename(dst)} — please upload it to Drive xai_data/.')

CHECK_WARN = []
def soft_check(ok, msg):
    """non-stopping check: on failure, print and record a warning (kept in the result file)"""
    if not ok: print('  ⚠ (continuing)', msg, flush=True); CHECK_WARN.append(msg)
    return bool(ok)

class Std:
    def __init__(s, Z): s.m, s.s = Z.mean(0), Z.std(0) + 1e-9
    def __call__(s, Z): return (Z - s.m)/s.s

# ---------------------------------------------------------------- linear algebra
def msqrt(S, p):
    """Σ^p (torch, eigenvalue floor 1e-3·mean; same as the confirmatory version) → numpy"""
    S = S if torch.is_tensor(S) else torch.tensor(S, dtype=torch.float64)
    ev, V = torch.linalg.eigh(S.double()); ev = torch.clamp(ev, min=METHOD['EIG_FLOOR']*ev.mean().item()); return ((V*ev**p) @ V.T).cpu().numpy()
def top_eig(M):
    """eigenvector rows (eigenvalues in descending order)"""
    M = M if torch.is_tensor(M) else torch.tensor(np.asarray(M)); ev, V = torch.linalg.eigh(M.double()); return V[:, torch.argsort(ev, descending=True)].T.cpu().numpy()
def orth_rows(X): return np.linalg.qr(np.asarray(X).T)[0].T

# ---------------------------------------------------------------- hidden states · covariance · sensitivity
@torch.no_grad()
def hidden(A, X, l, bs=None):
    bs = bs or A.bs; return torch.cat([A.to(X[i:i+bs].to(dev), l).float() for i in range(0, len(X), bs)])

@torch.no_grad()
def predict(A, X, bs=None):
    bs = bs or A.bs; return torch.cat([A.frm(A.to(X[i:i+bs].to(dev), 0), 0).argmax(1) for i in range(0, len(X), bs)]).cpu().numpy()

@torch.no_grad()
def logits(A, X, bs=None):
    bs = bs or A.bs; return torch.cat([A.frm(A.to(X[i:i+bs].to(dev), 0), 0).float() for i in range(0, len(X), bs)]).cpu().numpy()

@torch.no_grad()
def sigma_pos(A, l, X):
    """Σ = E_u Cov_n(h_{n,u}): mean over positions (tokens) of the across-image covariance at the same position"""
    s1, s2, n = None, 0, 0
    for i in range(0, len(X), A.bs):
        u = A.units(A.to(X[i:i+A.bs].to(dev), l).float()).double()
        s1 = u.sum(0) if s1 is None else s1 + u.sum(0); s2 = s2 + torch.einsum('btc,btd->cd', u, u); n += len(u)
    return (s2 - torch.einsum('tc,td->cd', s1, s1)/n)/(n*s1.shape[0])

def m_pos(A, l, H, fn):
    """M = E_n Σ_u g_u g_uᵀ, g_u = ∂fn(logits)/∂h_u"""
    M = 0
    for i in range(0, len(H), A.bs):
        h = H[i:i+A.bs].detach().clone().requires_grad_(True)
        with torch.enable_grad(): g, = torch.autograd.grad(fn(A.frm(h, l)).sum(), h)
        u = A.units(g).double(); M = M + torch.einsum('btc,btd->cd', u, u)
    return (M/len(H)).cpu().numpy()

def m_ta(A, l, Ha, Hb, a, b):
    """N = E Σ_u w_u Δ_uᵀ (Tanyel & Ayvaz), w = ∂(z_b − z_a)/∂h at the midpoint, Δ = h_b − h_a"""
    M = 0
    for i in range(0, len(Ha), A.bs):
        D = Hb[i:i+A.bs] - Ha[i:i+A.bs]; h = (Ha[i:i+A.bs] + D/2).detach().clone().requires_grad_(True)
        with torch.enable_grad(): g, = torch.autograd.grad((A.frm(h, l)[:, b] - A.frm(h, l)[:, a]).sum(), h)
        M = M + torch.einsum('btc,btd->cd', A.units(g).double(), A.units(D).double())
    return (M/len(Ha)).cpu().numpy()

# ---------------------------------------------------------------- 1. axes (all methods from the same pair samples)
def axes_pair(Mp, N, S2, Si2, Qp, k, rand_seed):
    """returns {method: (read R (k×C), write W (k×C))}. _cp = covariance-preserving (R = qΣ^{-½}, W = qΣ^½), _or = orthonormal (R = W = Q)"""
    qt = top_eig(S2 @ Mp @ S2)[:k]; Uta = top_eig((N + N.T)/2)[:k]; Nw = S2 @ N @ Si2; qc = top_eig((Nw + Nw.T)/2)[:k]
    qta = orth_rows(Uta @ S2); Qta = orth_rows(qta @ Si2); qr = orth_rows(np.random.default_rng(rand_seed).normal(size=(k, S2.shape[0]))); Qg = orth_rows(top_eig(Mp)[:k])
    return {'tvo_cp': (qt @ Si2, qt @ S2), 'ta_or': (Qta, Qta), 'cpta_cp': (qc @ Si2, qc @ S2), 'pca_or': (Qp, Qp), 'agop_or': (Qg, Qg), 'rand_cp': (qr @ Si2, qr @ S2)}

def axes_all(A, l, XPR, yp, pairs, seed, k=None):
    """uses the probe split only. Σ: N_AX probe images (rng(seed)) · per pair, PAIR_POOL probe images per class · PAIR_GRAD path pairs (rng(seed·100 + pair index))"""
    k = k or METHOD['K']; rng = np.random.default_rng(seed); ax_i = np.sort(rng.choice(len(XPR), METHOD['N_AX'], replace=False))
    Spos = sigma_pos(A, l, XPR[torch.tensor(ax_i, device=XPR.device)]); S2, Si2 = msqrt(Spos, 0.5), msqrt(Spos, -0.5); Qp = orth_rows(top_eig(Spos)[:k]); AXS = {}; POOL = {}
    for pi, (a, b) in enumerate(pairs):
        ia, ib = np.where(yp == a)[0], np.where(yp == b)[0]
        if len(ia) < 30 or len(ib) < 30: continue
        rp = np.random.default_rng(seed*100 + pi); pa_ = rp.choice(ia, min(len(ia), METHOD['PAIR_POOL']), replace=False); pb_ = rp.choice(ib, min(len(ib), METHOD['PAIR_POOL']), replace=False)
        Ha, Hb = hidden(A, XPR[torch.tensor(pa_, device=XPR.device)], l), hidden(A, XPR[torch.tensor(pb_, device=XPR.device)], l)
        ii, jj = torch.tensor(rp.integers(0, len(Ha), METHOD['PAIR_GRAD']), device=dev), torch.tensor(rp.integers(0, len(Hb), METHOD['PAIR_GRAD']), device=dev)
        Mp = m_pos(A, l, torch.cat([Ha[ii] + al*(Hb[jj] - Ha[ii]) for al in METHOD['PATH_A']]), lambda z: z[:, a] - z[:, b]); N = m_ta(A, l, Ha[ii], Hb[jj], a, b)
        AXS[(a, b)] = axes_pair(Mp, N, S2, Si2, Qp, k, seed*1000 + pi); POOL[(a, b)] = (pa_, pb_); del Ha, Hb
    torch.cuda.empty_cache(); return AXS, S2, Si2, POOL

# ---------------------------------------------------------------- swaps
def swap(A, hb, hs, rd, wr):
    """covariance-preserving swap (all k axes): h' = h_b + (h_s − h_b) Rᵀ W (at every position)"""
    P = torch.as_tensor(np.asarray(rd).T @ np.asarray(wr), device=hb.device, dtype=hb.dtype); u = A.units(hb) + A.units(hs - hb) @ P; return A.from_units(u, hb)

def donor_logits(A, l, H, D, rd, wr, masks, chunk=512):
    """H (n, …) bases · D (nd, …) shared donors or (n, nd, …) per-instance donors · masks (S, k) or (n, S, k) → (n, S, classes) donor-averaged logits.
       only axes with mask 1 take the donor values (covariance-preserving swap)"""
    R = torch.as_tensor(np.asarray(rd), device=H.device, dtype=H.dtype); W = torch.as_tensor(np.asarray(wr), device=H.device, dtype=H.dtype)
    M = torch.as_tensor(np.asarray(masks, np.float32), device=H.device, dtype=H.dtype); pcD = D.dim() == H.dim() + 1; pcM = M.dim() == 3
    S = M.shape[-2]; nd = D.shape[1] if pcD else D.shape[0]; step = max(1, chunk//(S*nd)); out = []; Du = None if pcD else A.units(D)
    for i in range(0, len(H), step):
        Hu = A.units(H[i:i+step]); b = len(Hu)
        Dd = A.units(D[i:i+step].reshape(-1, *D.shape[2:])).reshape(b, nd, *Hu.shape[1:]) if pcD else Du[None].expand(b, *Du.shape)
        co = torch.einsum('bduc,kc->bduk', Dd - Hu[:, None], R); Mi = M[i:i+step] if pcM else M[None].expand(b, *M.shape)
        hh = Hu[:, None, None] + torch.einsum('bduk,bsk,kc->bsduc', co, Mi, W)
        z = A.frm(A.from_units(hh.reshape(-1, *Hu.shape[1:]), H[:1]), l).float(); out.append(z.reshape(b, S, nd, -1).mean(2))
    return torch.cat(out)

# ---------------------------------------------------------------- 2 · 3. pair fit · minimal cause · lens of the final model
class PairModel:
    pass

def fit_pair(A, l, Ha, Hb, Ga, Gb, La, Lb, rd, wr, mu, a, b):
    """axis order = coefficient size of a logistic fit on standardized codes · lens = linear fit from axis codes to the contrast logit z_a − z_b (R_s, coefficients, residual SD) · donors = first N_DONOR images per class"""
    pm = PairModel(); pm.a, pm.b = int(a), int(b); k = len(rd)
    Z = (np.concatenate([Ga, Gb]) - mu) @ np.asarray(rd).T; y = np.r_[np.ones(len(Ga), int), np.zeros(len(Gb), int)]
    o = np.argsort(-np.abs(LogisticRegression(max_iter=2000).fit(Std(Z)(Z), y).coef_[0])); pm.rd, pm.wr, Z = np.asarray(rd)[o], np.asarray(wr)[o], Z[:, o]; pm.order = o; pm.U = list(range(k)); pm.mu = mu
    pm.sd = Std(Z); pm.beta = LogisticRegression(max_iter=2000).fit(pm.sd(Z), y).coef_[0]/pm.sd.s                 # map weights (positive = evidence for a)
    dv = np.r_[La[:, a] - La[:, b], Lb[:, a] - Lb[:, b]]; X1 = np.column_stack([np.ones(len(Z)), Z]); pm.lens_coef = np.linalg.lstsq(X1, dv, rcond=None)[0]; fs = X1 @ pm.lens_coef
    pm.R_s = float(np.corrcoef(fs, dv)[0, 1]) if fs.std() > 0 and dv.std() > 0 else float('nan'); pm.lens_sd = float(np.std(dv - fs)) + 1e-9; pm.flag = False
    nd = METHOD['N_DONOR']; pm.Hd = {pm.a: Ha[:nd].detach().clone(), pm.b: Hb[:nd].detach().clone()}; return pm

def lens_flags(pms):
    """pair-level lens warning: low outlier of R_s among the pairs of the same network (median − 2·1.4826·MAD). Undefined with fewer than 3 pairs"""
    v = np.array([p.R_s for p in pms], float); ok = np.isfinite(v)
    if ok.sum() < 3:
        for p in pms: p.flag = None
        return
    med = np.median(v[ok]); mad = 1.4826*np.median(np.abs(v[ok] - med)); th = med - 2*max(mad, 1e-6)
    for p in pms: p.flag = bool(not np.isfinite(p.R_s) or p.R_s < th)

def case_lens(pm, Pb, Lb):
    """instance-level lens (extension): |actual contrast logit − lens prediction| / residual SD of the fit. Pb = position-averaged hidden state (n, C), Lb = logits"""
    Z = (Pb - pm.mu) @ pm.rd.T; return np.abs((Lb[:, pm.a] - Lb[:, pm.b]) - np.column_stack([np.ones(len(Z)), Z]) @ pm.lens_coef)/pm.lens_sd

@torch.no_grad()
def minimal_cause(A, l, pm, H, a_cur, D=None):
    """'why a_cur and not the other' minimal cause (CESM): stack axes in order of the effect of setting each one to the other side (donor-averaged logits); the first prefix set that changes the decision.
       default donors = N_DONOR probe images of the other class (no original needed). Returns C (list of axis indices per instance, or None) and size (none = k + 1)"""
    b_cur = pm.b if a_cur == pm.a else pm.a; k = len(pm.rd); n = len(H); D = pm.Hd[b_cur] if D is None else D; pc = D.dim() == H.dim() + 1
    single = np.zeros((k + 1, k), np.float32); single[np.arange(k), np.arange(k)] = 1                     # last row = unchanged
    L1 = donor_logits(A, l, H, D, pm.rd, pm.wr, single).cpu().numpy(); c1 = L1[:, :, b_cur] - L1[:, :, a_cur]
    oe = np.argsort(-(c1[:, :k] - c1[:, [k]]), 1); rk = np.argsort(oe, 1); fl = np.zeros((n, k), bool); todo = np.arange(n); t0 = 0
    for t1 in ([4, k] if k > 4 else [k]):                                                                   # first 4 first (same result, less computation)
        if len(todo) == 0: break
        mk = np.stack([(rk[todo] <= t).astype(np.float32) for t in range(t0, t1)], 1); ti = torch.tensor(todo, device=H.device)
        L2 = donor_logits(A, l, H[ti], D[ti] if pc else D, pm.rd, pm.wr, mk).cpu().numpy(); fl[todo, t0:t1] = (L2[:, :, b_cur] - L2[:, :, a_cur]) > 0
        todo = todo[~fl[todo, :t1].any(1)]; t0 = t1
    C, cn = [], np.full(n, k + 1)
    for i in range(n):
        if fl[i].any(): t = int(np.argmax(fl[i])); C.append([int(x) for x in oe[i, :t + 1]]); cn[i] = t + 1
        else: C.append(None)
    return C, cn

@torch.no_grad()
def restore(A, l, pm, H, D, Cs, target):
    """does reverting only the C axes to the values of D give target (no cause = failure)"""
    mk = np.zeros((len(H), 1, len(pm.rd)), np.float32)
    for i, C in enumerate(Cs):
        if C: mk[i, 0, C] = 1
    L = donor_logits(A, l, H, D, pm.rd, pm.wr, mk)[:, 0].cpu().numpy(); return (L.argmax(1) == np.asarray(target)) & np.array([C is not None for C in Cs])

@torch.no_grad()
def cause_map(A, pm, H, a_cur, Cs):
    """attribution map (per position / token): Σ_{j ∈ C} β_j r_j·(h_u − μ)/sd_j, positive toward a_cur. Without a cause, all axes → (n, U)"""
    Hu = A.units(H.float()); R = torch.as_tensor(pm.rd, device=H.device, dtype=torch.float32); mu = torch.as_tensor(pm.mu, device=H.device, dtype=torch.float32)
    co = torch.einsum('nuc,kc->nuk', Hu - mu, R)/torch.as_tensor(pm.sd.s, device=H.device, dtype=torch.float32); Wm = np.zeros((len(H), len(pm.rd)), np.float32)
    for i, C in enumerate(Cs):
        sel = C if C else pm.U; Wm[i, sel] = pm.beta[sel]
    return ((1.0 if a_cur == pm.a else -1.0)*(co*torch.as_tensor(Wm, device=H.device)[:, None, :]).sum(-1)).cpu().numpy()

def fit_pairs(A, l, XPR, yp, AXS, POOL, seed, methods=('tvo_cp',), k=None):
    """reuse the pair samples (POOL) of axes_all to fit a pair model per method + pair-level lens warning"""
    k = k or METHOD['K']; Gp = torch.cat([A.pool(A.to(XPR[i:i+A.bs].to(dev), l).float()).double().cpu() for i in range(0, len(XPR), A.bs)]).numpy(); mu = Gp.mean(0)
    Lp = logits(A, XPR); FPS = {q: {} for q in methods}
    for key, (pa_, pb_) in POOL.items():
        Ha, Hb = hidden(A, XPR[torch.tensor(pa_, device=XPR.device)], l), hidden(A, XPR[torch.tensor(pb_, device=XPR.device)], l)
        for q in methods:
            rd, wr = (np.asarray(x)[:k] for x in AXS[key][q]); FPS[q][key] = fit_pair(A, l, Ha, Hb, Gp[pa_], Gp[pb_], Lp[pa_], Lp[pb_], rd, wr, mu, *key)
        del Ha, Hb
    for q in methods: lens_flags(list(FPS[q].values()))
    torch.cuda.empty_cache(); return FPS, mu

# ---------------------------------------------------------------- 4. combination risk prediction
def proj(h, R): return torch.einsum('bchw,kc->bkhw', h, R) if h.dim() == 4 else torch.einsum('btc,kc->bkt', h, R)
def lift(z, W): return torch.einsum('bkhw,kc->bchw', z, W) if z.dim() == 4 else torch.einsum('bkt,kc->btc', z, W)

def foil_margins(head, AXS, q, k, hb, dz, p0, ncls):
    """for each alternative f, project the hidden-state change onto the k axes of pair (a, f), sum, then margin z_a − z_f (q = 'full': full hidden state)"""
    B = len(hb); ar = torch.arange(B, device=hb.device); M = torch.zeros(B, ncls - 1, device=hb.device)
    others = torch.stack([torch.tensor([c for c in range(ncls) if c != int(a)], device=hb.device) for a in p0.tolist()])
    for t in range(ncls - 1):
        fo = others[:, t]; hn = hb.clone()
        if q == 'full': hn = hb + dz(None, None)
        else:
            for a in range(ncls):
                for f in range(ncls):
                    if a == f: continue
                    m_ = (p0 == a) & (fo == f); key = (min(a, f), max(a, f))
                    if not bool(m_.any()) or key not in AXS: continue
                    rd, wr = (torch.tensor(np.asarray(x)[:k], device=hb.device, dtype=hb.dtype) for x in AXS[key][q]); ii = torch.where(m_)[0]; hn[ii] = hb[ii] + lift(dz(rd, ii), wr)
        L_ = head(hn); M[:, t] = L_[ar, p0] - L_[ar, fo]
    return M

def ece(p, y, nb=10):
    b = np.clip((p*nb).astype(int), 0, nb - 1); return float(sum(abs(p[b == i].mean() - y[b == i].mean())*(b == i).mean() for i in range(nb) if (b == i).any()))

@torch.no_grad()
def risk_eval(head, AXS, methods, partial, combos, ncls):
    """partial: list of (factor name, [(hb, hs) batches, …]) — tests changing one factor at a time · combos: list of (combination name, [(hb, h1, h2, h12) batches, …]).
       σ and slope per method from the partial tests → P(flip) of a combination = 1 − Π_f Φ(m_f/(σ√2)) (m_f = sum of the partial projected changes), compared with the actual flips. Combined images are used only for checking against ground truth"""
    SIG = {}; RE = {nm: [] for nm in methods}; PR = {nm: [] for nm in methods}
    for _, batches in partial:
        for hb, hs in batches:
            p0 = head(hb).argmax(1); Mb = foil_margins(head, AXS, 'full', 0, hb, lambda rd, ii: torch.zeros_like(hb), p0, ncls); Mr = foil_margins(head, AXS, 'full', 0, hb, lambda rd, ii: hs - hb, p0, ncls)
            for nm in methods:
                q, k = nm.split('|'); Mp = Mr if q == 'full' else foil_margins(head, AXS, q, int(k), hb, lambda rd, ii: proj(hs[ii] - hb[ii], rd), p0, ncls)
                RE[nm].append((Mr - Mb).flatten().cpu().numpy()); PR[nm].append((Mp - Mb).flatten().cpu().numpy())
    for nm in methods:
        re_, pr_ = np.concatenate(RE[nm]), np.concatenate(PR[nm]); sl = float((re_*pr_).sum()/max((pr_*pr_).sum(), 1e-12))
        SIG[nm] = {'sigma': float(np.std(re_ - pr_)), 'sigma_cal': float(np.std(re_ - sl*pr_)), 'slope': sl}
    acc = {nm + c_: {m_: [] for m_ in ['brier', 'ece', 'rate_err', 'auroc', 'auroc_emerg', 'main', 'rate_pred', 'rate_real']} for nm in methods for c_ in ('', '|cal')}; names = []
    for cname, batches in combos:
        names.append(cname); MM = {nm: [] for nm in methods}; MB = []; P = {t: [] for t in ('b', '1', '2', '12')}; FO = []
        for hb, h1, h2, h12 in batches:
            for t, h_ in (('b', hb), ('1', h1), ('2', h2), ('12', h12)): P[t].append(head(h_).argmax(1).cpu().numpy())
            p0 = head(hb).argmax(1); MB.append(foil_margins(head, AXS, 'full', 0, hb, lambda rd, ii: torch.zeros_like(hb), p0, ncls).cpu().numpy())
            FO.append(np.stack([np.array([c for c in range(ncls) if c != int(a)]) for a in p0.tolist()]))
            for nm in methods:
                q, k = nm.split('|')
                dz = (lambda rd, ii: (h1 - hb) + (h2 - hb)) if q == 'full' else (lambda rd, ii: proj(h1[ii] - hb[ii], rd) + proj(h2[ii] - hb[ii], rd))
                MM[nm].append(foil_margins(head, AXS, q, int(k), hb, dz, p0, ncls).cpu().numpy())
        P = {t: np.concatenate(v) for t, v in P.items()}; MB = np.concatenate(MB); FO = np.concatenate(FO); p0, p12 = P['b'], P['12']; n = len(p0)
        flip = (p12 != p0).astype(float); emerg = (p12 != p0) & (P['1'] == p0) & (P['2'] == p0)
        for nm in methods:
            M0 = np.concatenate(MM[nm])
            for c_ in ('', '|cal'):
                Mx = M0 if c_ == '' else MB + SIG[nm]['slope']*(M0 - MB); sg = SIG[nm]['sigma_cal' if c_ else 'sigma']*math.sqrt(2)
                pf = 1 - np.prod(_norm.cdf(Mx/max(sg, 1e-6)), axis=1); pc = np.where(Mx.min(1) < 0, FO[np.arange(n), Mx.argmin(1)], p0); hit = pc == p12; a_ = acc[nm + c_]
                a_['brier'].append(float(np.mean((pf - flip)**2))); a_['ece'].append(ece(pf, flip)); a_['rate_err'].append(float(abs(pf.mean() - flip.mean())))
                a_['rate_pred'].append(float(pf.mean())); a_['rate_real'].append(float(flip.mean()))
                a_['auroc'].append(float(roc_auc_score(flip, pf)) if 0 < flip.sum() < n else float('nan'))
                sub = emerg | (flip == 0); a_['auroc_emerg'].append(float(roc_auc_score(emerg[sub], pf[sub])) if emerg.sum() >= 5 and (flip == 0).sum() >= 5 else float('nan'))
                a_['main'].append(((hit[flip == 1].mean() if flip.sum() else np.nan) + (hit[flip == 0].mean() if (flip == 0).sum() else np.nan))/2)
    out = {nm: {**{m_: float(np.nanmean(v)) for m_, v in a_.items() if m_ not in ('rate_pred', 'rate_real')}, 'combos': {c: (a_['rate_pred'][i], a_['rate_real'][i]) for i, c in enumerate(names)}} for nm, a_ in acc.items()}
    for nm in methods: out[nm].update(SIG[nm])
    return out

@torch.no_grad()
def case5(H, AXS, methods, k=16):
    """Thurstone Case V assumption check: |log| variance of axis codes (position · image) · off-diagonal |correlation| (pair mean)"""
    Hc = H - H.mean(0, keepdim=True); out = {}
    for q in methods:
        lv, oc = [], []
        for key in AXS:
            z = proj(Hc, torch.tensor(np.asarray(AXS[key][q][0])[:k], device=H.device, dtype=Hc.dtype)); z = z.transpose(0, 1).reshape(z.shape[1], -1).double()
            C = torch.cov(z).cpu().numpy(); d = np.sqrt(np.diag(C)); Rm = C/np.outer(d, d); lv.append(float(np.mean(np.abs(np.log(np.diag(C)))))); oc.append(float(np.abs(Rm[~np.eye(len(Rm), dtype=bool)]).mean()))
        out[q] = {'abs_log_var': float(np.mean(lv)), 'abs_offdiag_corr': float(np.mean(oc))}
    return out

# ---------------------------------------------------------------- 5. Kelley-specific erasure · erasure baselines
def apply_edit(Mx, h, mu):
    """h − Mx (h − μ) (per position / token)"""
    d = h - mu.to(h.dtype); Mt = Mx.to(h.dtype); return h - (torch.einsum('dc,bchw->bdhw', Mt, d) if h.dim() == 4 else torch.einsum('dc,btc->btd', Mt, d))

def spec_dirs(SDf, SDs, S2, Si2, geom):
    """'w' (ours): whitened coordinates C_f v = λ (C_s + εI) v · 'e': same eigenproblem in original coordinates · 'n': whitened C_f eigenvectors only (no shape contrast). Eigenvalues descending · eigenvectors as columns"""
    Cf, Cs = (SDf, SDs) if geom == 'e' else (Si2 @ SDf @ Si2, Si2 @ SDs @ Si2); Cf, Cs = (Cf + Cf.T)/2, (Cs + Cs.T)/2; d = len(Cs)
    lam, W = np.linalg.eigh(Cf) if geom == 'n' else _geig(Cf, Cs + METHOD['EPS']*np.trace(Cs)/d*np.eye(d)); o = np.argsort(-lam); return lam[o], W[:, o]

def edit_matrix(DIRS, geom, edits, S2, Si2):
    """edits ((factor, k), …) → Mx. 'w' · 'n': Σ-orthogonal removal Σ^½ V Vᵀ Σ^{-½} (V = orthonormal in whitened coordinates) · 'e': orthogonal projection in original coordinates"""
    if not edits: return None
    U = np.concatenate([DIRS[geom][f][1][:, :k] for f, k in edits], 1); Q, R_ = np.linalg.qr(U); dg = np.abs(np.diag(R_)); Q = Q[:, dg > 1e-10*dg.max()]
    return torch.tensor(Q @ Q.T if geom == 'e' else S2 @ Q @ Q.T @ Si2, device=dev, dtype=torch.float32)

def hard_matrix(SD, S2, Si2):
    """stage20 (shortcut given): fully remove whitened principal components of shortcut-factor pairs up to 95% cumulative (at most 16)"""
    Cw = Si2 @ SD @ Si2; c_, Q = np.linalg.eigh((Cw + Cw.T)/2); o = np.argsort(-c_); c_, Q = np.clip(c_[o], 0, None), Q[:, o]
    k = min(max(int(np.searchsorted(np.cumsum(c_)/max(c_.sum(), 1e-12), 0.95) + 1), 1), METHOD['K95_MAX']); Qk = Q[:, :k]
    return torch.tensor(S2 @ Qk @ Qk.T @ Si2, device=dev, dtype=torch.float32), k

def leace_matrix(SHZ, S2, Si2):
    """LEACE (Belrose+2023): Σ^½ P Σ^{-½}, P = col(Σ^{-½} Σ_xz) orthogonal projection. Uses shortcut labels"""
    U, s, _ = np.linalg.svd(Si2 @ SHZ, full_matrices=False); rk = int((s > 1e-6*s.max()).sum()); U = U[:, :rk]
    return torch.tensor(S2 @ U @ U.T @ Si2, device=dev, dtype=torch.float32), rk

def grit_matrix(SD, r):
    """GRIT (Bai+2025): orthogonal projection in original coordinates onto the top r eigenvectors of the shortcut-pair difference covariance"""
    w, V = np.linalg.eigh((SD + SD.T)/2); Vr = V[:, np.argsort(-w)[:r]]; return torch.tensor(Vr @ Vr.T, device=dev, dtype=torch.float32)

class Treat:
    """head of the treated network: hidden state h at explanation layer l → (optional) erasure → remaining layers"""
    def __init__(s, A, l, E=None): s.A, s.l, s.E = A, l, E
    def h(s, h): return h if s.E is None else apply_edit(s.E[0], h, s.E[1])
    def head(s, h): return s.A.frm(s.h(h), s.l)
    def feat(s, h): return s.A.penult(s.A.advance(s.h(h), s.l, s.A.last))    # input features of the output layer (input to DFR · GRIT retraining)

class EditedArch:
    """treated network = original network with erasure inserted at the explanation-layer output (only to · frm · advance change). Used to recompute axes and reapply risk prediction"""
    def __init__(s, A, Mx, mu, l): s._A, s._Mx, s._mu, s._l = A, Mx, mu, l
    def __getattr__(s, k): return getattr(s._A, k)
    def _e(s, h): return apply_edit(s._Mx, h, s._mu)
    def advance(s, h, l0, l1): return s._A.advance(s._e(s._A.advance(h, l0, s._l)), s._l, l1) if l0 < s._l <= l1 else s._A.advance(h, l0, l1)
    def to(s, x, l):
        if l < s._l: return s._A.to(x, l)
        h = s._e(s._A.to(x, s._l)); return h if l == s._l else s._A.advance(h, s._l, l)
    def frm(s, h, l):
        if l < s._l: h, l = s._A.advance(h, l, s._l), s._l
        return s._A.frm(s._e(h), l) if l == s._l else s._A.frm(h, l)

class Selector:
    """selection (probe split only): compute explanation-layer hidden states of shared bases · per-factor counterfactuals · aligned images once, then rerun only the head for each candidate edit.
       Hb (n, …) bases, Hj {factor: (n, …)}, Hag aligned images. J = S − mean_{nuisance pairs} min(1, R_a + R_b), S = flips of the label factor"""
    def __init__(s, A, l, mu, DIRS, S2, Si2, Hb, Hj, Hag, j_label, nuis, names, hb=250):
        s.A, s.l, s.mu, s.DIRS, s.S2, s.Si2, s.Hb, s.Hj, s.Hag, s.jl, s.nuis, s.names, s.hb = A, l, mu, DIRS, S2, Si2, Hb, Hj, Hag, j_label, nuis, names, hb; s.cache = {}
        s.npairs = list(itertools.combinations(nuis, 2))
        with torch.no_grad(): s.ag_ref = torch.cat([A.frm(Hag[i:i+hb], l).argmax(1) for i in range(0, len(Hag), hb)])
    def key(s, geom, edits): return (geom + ':' + '+'.join(f'{s.names[f]}{k}' for f, k in edits)) if edits else 'none'
    @torch.no_grad()
    def get(s, geom, edits):
        kk = s.key(geom, edits)
        if kk in s.cache: return s.cache[kk]
        Mx = edit_matrix(s.DIRS, geom, edits, s.S2, s.Si2); hd = (lambda h: s.A.frm(h, s.l)) if Mx is None else (lambda h: s.A.frm(apply_edit(Mx, h, s.mu), s.l)); fl = {j: [] for j in s.Hj}
        for i in range(0, len(s.Hb), s.hb):
            p0 = hd(s.Hb[i:i+s.hb]).argmax(1)
            for j in s.Hj: fl[j].append((hd(s.Hj[j][i:i+s.hb]).argmax(1) != p0).cpu().numpy())
        R = {j: float(np.concatenate(v).mean()) for j, v in fl.items()}
        ag = float(torch.cat([(hd(s.Hag[i:i+s.hb]).argmax(1) == s.ag_ref[i:i+s.hb]) for i in range(0, len(s.Hag), s.hb)]).float().mean())
        B = {'Mx': Mx, 'R': R, 'S': R[s.jl], 'P': float(np.mean([min(1.0, R[a] + R[b]) for a, b in s.npairs])), 'agree': ag}; B['J'] = B['S'] - B['P']; s.cache[kk] = B; return B
    def J(s, geom, edits):
        B = s.get(geom, edits); return B['J'], B['S'] >= s.get(geom, ())['S'] - METHOD['S_TOL']

def select(sel, geom):
    """candidates = nuisance factor × k ∈ KS. If the best single candidate that satisfies the constraints exceeds J(none) + GAIN, accept it → second factor by the same rule (at most 2)"""
    j0, _ = sel.J(geom, ()); best, bj = (), j0; tr = {'none': (j0, True)}
    sc = {((f, k),): sel.J(geom, ((f, k),)) for f in sel.nuis for k in METHOD['KS']}; tr.update({sel.key(geom, e): v for e, v in sc.items()}); fe = [e for e, (_, ok) in sc.items() if ok]
    if fe:
        e1 = max(fe, key=lambda e: sc[e][0])
        if sc[e1][0] > j0 + METHOD['GAIN']:
            best, bj = e1, sc[e1][0]
            sc2 = {e1 + ((f2, k2),): sel.J(geom, e1 + ((f2, k2),)) for f2 in sel.nuis if f2 != e1[0][0] for k2 in METHOD['KS']}; tr.update({sel.key(geom, e): v for e, v in sc2.items()})
            fe2 = [e for e, (_, ok) in sc2.items() if ok]
            if fe2:
                e2 = max(fe2, key=lambda e: sc2[e][0])
                if sc2[e2][0] > bj + METHOD['GAIN']: best, bj = e2, sc2[e2][0]
    return {'edits': [[sel.names[f], int(k)] for f, k in best], 'key': sel.key(geom, best), 'J': bj, 'J_none': j0, 'n_cand': len(tr), 'trace': {k_: [float(v[0]), bool(v[1])] for k_, v in tr.items()}}, best

def dfr_g(Fv, yv, gv, Ft, seed):
    """DFR (Kirichenko+2023): L1 logistic regression on standardized last-layer features of group-balanced samples gv. C = worst-group accuracy on half of the validation set, mean over 10 balanced samples"""
    r = np.random.default_rng(seed); sd = Std(Fv); Zv, Zt = sd(Fv), sd(Ft); G_ = np.unique(gv)
    def bal(ix):
        n = min((gv[ix] == k).sum() for k in G_); return np.concatenate([r.choice(ix[gv[ix] == k], max(n, 1), replace=False) for k in G_ if (gv[ix] == k).any()])
    def worst(p, ix): return min(float((p[gv[ix] == k] == yv[ix][gv[ix] == k]).mean()) for k in G_ if (gv[ix] == k).any())
    perm = r.permutation(len(yv)); h1, h2 = perm[:len(perm)//2], perm[len(perm)//2:]; best = None
    for C_ in [1.0, 0.7, 0.3, 0.1, 0.07, 0.03, 0.01]:
        b1 = bal(h1); clf = LogisticRegression(penalty='l1', C=C_, solver='liblinear').fit(Zv[b1], yv[b1]); w = worst(clf.predict(Zv[h2]), h2)
        if best is None or w > best[0]: best = (w, C_)
    W_, b_ = 0, 0
    for _ in range(10):
        ix = bal(np.arange(len(yv))); clf = LogisticRegression(penalty='l1', C=best[1], solver='liblinear').fit(Zv[ix], yv[ix]); W_ = W_ + clf.coef_/10; b_ = b_ + clf.intercept_/10
    S_ = Zt @ W_.T + b_; return (S_[:, 0] > 0).astype(int) if S_.shape[1] == 1 else S_.argmax(1)

# ---------------------------------------------------------------- DAS (privileged upper bound)
def train_das(A, l, k, seed, sampler, steps, bs, lr=3e-3):
    """Geiger+2023 DAS: orthonormal U (k×C), swap P = UᵀU. sampler(bs) → (h_base, h_source, target class). Returns (U, U)"""
    from torch.nn.utils import parametrizations
    torch.manual_seed(seed); lin = nn.Linear(A.dim[l], k, bias=False).to(dev); parametrizations.orthogonal(lin); opt = torch.optim.Adam(lin.parameters(), lr=lr)
    for _ in range(steps):
        hb, hs, tg = sampler(bs)
        with torch.enable_grad():
            V = lin.weight; u = A.units(hb) + A.units(hs - hb) @ (V.T @ V); loss = F.cross_entropy(A.frm(A.from_units(u, hb), l).float(), tg)
        opt.zero_grad(); loss.backward(); opt.step()
    U = orth_rows(lin.weight.detach().double().cpu().numpy()); return U, U

# ---------------------------------------------------------------- verdict statistics
def holm(ps):
    ps = np.asarray(ps, float); o = np.argsort(ps); m = len(ps); adj = np.empty(m); run = 0.0
    for r, i in enumerate(o): run = max(run, (m - r)*ps[i]); adj[i] = min(1.0, run)
    return adj

def judge(rows):
    """rows: [{'no', 'desc', 'fam', 'd' (ours − control per model, larger = ours better), 'thr', 'kind' ('diff' | 'count' | 'report'), (optional) 'cond' (extra condition true/false)}, …].
       diff: ① ≥⌈5/6·n⌉ wins + mean difference > thr, ② two-sided Wilcoxon (n ≥ 6) + Holm (within family). count: d = list of true/false, ① only. report: reported"""
    out = []
    for r in rows:
        d = np.asarray([x for x in r['d'] if x is not None and np.isfinite(x)], float); n = len(d); need = math.ceil(5*n/6)
        if r['kind'] == 'count':
            w = int(d.sum()); out.append({**r, 'n': n, 'win': w, 'mean': np.nan, 'p': np.nan, 'pass1': bool(n > 0 and w >= need)}); continue
        w = int((d > 0).sum()); p = float(_wilcoxon(d).pvalue) if n >= 6 and np.any(d != 0) else float('nan')
        out.append({**r, 'n': n, 'win': w, 'mean': float(d.mean()) if n else np.nan, 'p': p, 'pass1': bool(n > 0 and w >= need and d.mean() > r['thr'] and r.get('cond', True))})
    for fam in {o['fam'] for o in out if o['kind'] == 'diff'}:
        ix = [i for i, o in enumerate(out) if o['fam'] == fam and o['kind'] == 'diff']; adj = holm([out[i]['p'] if np.isfinite(out[i]['p']) else 1.0 for i in ix])
        for i, a in zip(ix, adj): out[i]['p_holm'] = float(a)
    for o in out:
        o.setdefault('p_holm', np.nan)
        o['verdict'] = 'reported' if o['kind'] == 'report' else ('passed' if o['kind'] == 'count' and o['pass1'] else 'confirmed' if o['pass1'] and o['p_holm'] < 0.05 else 'only ① passed' if o['pass1'] else 'not confirmed')
    return out

# ===================================================================================================
# ↓↓↓ archs.py ↓↓↓
# ===================================================================================================
# ===================================================================================================
# archs.py — model definitions and network interface (used by core: name · dim[l] · last · bs · to · frm · advance · units · from_units · pool · penult)
#   units: intervention units (ResNet = positions, ViT = tokens; the explanation layer is always intermediate, so all tokens including CLS). pool: mean over positions / tokens. penult: input features of the output layer
# ===================================================================================================

class ConvUnits:
    def units(s, h): return h.permute(0, 2, 3, 1).reshape(h.shape[0], -1, h.shape[1])
    def from_units(s, u, like): return u.reshape(u.shape[0], like.shape[2], like.shape[3], like.shape[1]).permute(0, 3, 1, 2)
    def pool(s, h): return h.mean((2, 3))
class TokUnits:
    def units(s, h): return h
    def from_units(s, u, like): return u
    def pool(s, h): return h.mean(1)

def make_prep(mean, std):
    m_, s_ = torch.tensor(mean, device=dev).view(1, 3, 1, 1), torch.tensor(std, device=dev).view(1, 3, 1, 1)
    def prep(x): return ((x.float()/255 if x.dtype == torch.uint8 else x.float()) - m_)/s_       # input: uint8 or float in [0, 1]
    return prep
PREP_CIFAR = ((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
PREP_IMNET = ((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))

# ---------------------------------------------------------------- ResNet-18 (CIFAR-style stem: 3×3, stride 1, no max pooling)
class Block(nn.Module):
    def __init__(s, cin, cout, stride):
        super().__init__()
        s.c1 = nn.Conv2d(cin, cout, 3, stride, 1, bias=False); s.b1 = nn.BatchNorm2d(cout); s.c2 = nn.Conv2d(cout, cout, 3, 1, 1, bias=False); s.b2 = nn.BatchNorm2d(cout)
        s.sc = nn.Sequential() if stride == 1 and cin == cout else nn.Sequential(nn.Conv2d(cin, cout, 1, stride, bias=False), nn.BatchNorm2d(cout))
    def forward(s, x): return F.relu(s.b2(s.c2(F.relu(s.b1(s.c1(x))))) + s.sc(x))
class ResNet18(nn.Module):
    def __init__(s, nc):
        super().__init__()
        s.stem = nn.Sequential(nn.Conv2d(3, 64, 3, 1, 1, bias=False), nn.BatchNorm2d(64), nn.ReLU())
        s.stages = nn.ModuleList([nn.Sequential(Block(a, b, st), Block(b, b, 1)) for a, b, st in [(64, 64, 1), (64, 128, 2), (128, 256, 2), (256, 512, 2)]]); s.fc = nn.Linear(512, nc)
    def forward(s, x):
        h = s.stem(x)
        for st in s.stages: h = st(h)
        return s.fc(h.mean((2, 3)))

class RN18Arch(ConvUnits):
    name, last = 'rn18', 4
    def __init__(s, m, prep, bs=250): s.m, s.prep, s.bs = m, prep, bs; s.dim = {0: 64, 1: 64, 2: 128, 3: 256, 4: 512}
    def to(s, x, l):
        h = s.m.stem(s.prep(x))
        for st in s.m.stages[:l]: h = st(h)
        return h
    def advance(s, h, l0, l1):
        for st in s.m.stages[l0:l1]: h = st(h)
        return h
    def frm(s, h, l): return s.m.fc(s.advance(h, l, 4).mean((2, 3)))
    def penult(s, h_last): return h_last.mean((2, 3))

# ---------------------------------------------------------------- torchvision ResNet-50 (ImageNet stem)
class RN50Arch(ConvUnits):
    name, last = 'rn50', 4
    def __init__(s, m, prep, bs=64): s.m, s.prep, s.bs = m, prep, bs; s.st = [m.layer1, m.layer2, m.layer3, m.layer4]; s.dim = {0: 64, 1: 256, 2: 512, 3: 1024, 4: 2048}
    def to(s, x, l):
        m = s.m; h = m.maxpool(m.relu(m.bn1(m.conv1(s.prep(x)))))
        for st in s.st[:l]: h = st(h)
        return h
    def advance(s, h, l0, l1):
        for st in s.st[l0:l1]: h = st(h)
        return h
    def frm(s, h, l): return s.m.fc(torch.flatten(s.m.avgpool(s.advance(h, l, 4)), 1))
    def penult(s, h_last): return torch.flatten(s.m.avgpool(h_last), 1)
def resnet50(nc, pretrained):
    m = torchvision.models.resnet50(weights=torchvision.models.ResNet50_Weights.IMAGENET1K_V1 if pretrained else None); m.fc = nn.Linear(2048, nc); return m

# ---------------------------------------------------------------- ViT (timm VisionTransformer; residual stream after l blocks)
def make_vit(nc, img, patch, dim, depth, heads, drop=0.0):
    from timm.models.vision_transformer import VisionTransformer
    return VisionTransformer(img_size=img, patch_size=patch, num_classes=nc, embed_dim=dim, depth=depth, num_heads=heads, mlp_ratio=4.0, class_token=True, global_pool='token', drop_rate=drop)
class ViTArch(TokUnits):
    name = 'vit'
    def __init__(s, m, prep, bs=250, size=None):
        s.m, s.prep, s.bs, s.size = m, prep, bs, size; s.last = len(m.blocks); s.dim = {l: m.embed_dim for l in range(s.last + 1)}
    def to(s, x, l):
        x = s.prep(x)
        if s.size and x.shape[-1] != s.size: x = F.interpolate(x, size=(s.size, s.size), mode='bilinear', align_corners=False)
        m = s.m; h = m._pos_embed(m.patch_embed(x))
        for nm in ['patch_drop', 'norm_pre']:
            if hasattr(m, nm): h = getattr(m, nm)(h)
        for b in m.blocks[:l]: h = b(h)
        return h
    def advance(s, h, l0, l1):
        for b in s.m.blocks[l0:l1]: h = b(h)
        return h
    def frm(s, h, l): return s.m.forward_head(s.m.norm(s.advance(h, l, s.last)))
    def penult(s, h_last): return s.m.forward_head(s.m.norm(h_last), pre_logits=True)

def explain_layer(A): return 3 if A.name in ('rn18', 'rn50') else A.last//2          # ResNet layer3 · ViT middle block

@torch.no_grad()
def arch_check(A, x):
    """path check (stop condition): to(x, l) → frm(·, l) gives the same logits for every l, and units ↔ from_units round trip is the identity"""
    z0 = A.frm(A.to(x, 0), 0).float(); err = 0.0
    for l in range(1, A.last + 1):
        h = A.to(x, l); err = max(err, float((A.frm(h, l).float() - z0).abs().max())); err = max(err, float((A.from_units(A.units(h), h) - h).abs().max()))
        err = max(err, float((A.advance(A.to(x, l - 1), l - 1, l) - h).abs().max()))
    assert err < 1e-3*max(1.0, float(z0.abs().max())), f'⚠ path check failed ({err})'
    return err

# ===================================================================================================
# ↓↓↓ grid.py ↓↓↓
# ===================================================================================================
# ===================================================================================================
# grid.py — shared pipeline of experiments P1–P3 on factor-grid data (Shapes3D · MPI3D-real · Waterbirds-CF)
#   data modules build GridData: factor names · number of values · label · shortcut factor · img(index) → uint8 (B, 3, H, W) · alignment rule
#   experiments of one model (run_model): ① axes · pair fit → experiment 1 (E1–E3) → ② Kelley diagnosis · selection · treatment (C1–C8, C10) → ③ integration (X1–X4) → ④ risk prediction before (C0) / after (C9) treatment
#   methods use only the probe split (assert). The test split and true counterfactuals are for evaluation only
# ===================================================================================================

class GridData:
    def __init__(s, name, FACT, NV, J_LABEL, J_SC, img, SIG, sc_values):
        """sc_values(label array) → per label 'bound' list of shortcut values (aligned image = shortcut value in that list)"""
        s.name, s.FACT, s.NV, s.J_LABEL, s.J_SC, s.img, s.SIG, s.sc_values = name, list(FACT), np.asarray(NV), J_LABEL, J_SC, img, SIG, sc_values
        s.N = int(np.prod(s.NV)); s.STRIDE = np.array([int(np.prod(s.NV[i + 1:])) for i in range(len(s.NV))]); s.NCLS = int(s.NV[J_LABEL])
        s.NUIS = [j for j in range(len(FACT)) if j != J_LABEL]; s.NPAIRS = list(itertools.combinations(s.NUIS, 2)); s.PAIRS = list(itertools.combinations(range(s.NCLS), 2))
        assert s.J_SC == 0, 'μ of the Kelley diagnosis is taken on shortcut-factor (first factor) bases (same convention as the confirmatory version)'
    def idx_of(s, Fi): return (np.asarray(Fi, dtype=np.int64)*s.STRIDE).sum(-1)
    def F(s, idx): return np.stack(np.unravel_index(np.asarray(idx, dtype=np.int64), s.NV), 1)
    def label(s, idx): return s.F(idx)[:, s.J_LABEL]
    def aligned(s, idx):
        Fi = s.F(idx); return np.array([f[s.J_SC] in s.sc_values(f[s.J_LABEL]) for f in Fi]) if len(Fi) < 1000 else s._aligned_vec(Fi)
    def _aligned_vec(s, Fi):
        out = np.zeros(len(Fi), bool)
        for c in range(s.NCLS): m = Fi[:, s.J_LABEL] == c; out[m] = np.isin(Fi[m, s.J_SC], s.sc_values(c))
        return out
    def cf_index(s, base, j, r):
        """indices of images with only factor j changed to another value (uniform; other factors unchanged)"""
        Fc = s.F(base); Fc[:, j] = (Fc[:, j] + r.integers(1, s.NV[j], len(base))) % s.NV[j]; return s.idx_of(Fc)
    def sc_align(s, base, r):
        """indices with only the shortcut factor changed to a value bound to the label (uniform if several) · pass only bases that are not already aligned"""
        Fc = s.F(base); Fc[:, s.J_SC] = [int(r.choice(s.sc_values(c))) for c in Fc[:, s.J_LABEL]]; return s.idx_of(Fc)
    @torch.no_grad()
    def noisy(s, idx, seed, ch=2000):
        """fixed-noise input: same seed and same length give the same noise (same noise for base and counterfactual). Returns half (dev)"""
        idx = np.asarray(idx); out = []
        for c, i in enumerate(range(0, len(idx), ch)):
            x = s.img(idx[i:i+ch]).to(dev).float()/255
            if s.SIG > 0: g = torch.Generator(device=dev).manual_seed(int(seed)*100003 + c); x = x + s.SIG*torch.randn(x.shape, device=dev, generator=g)
            out.append(x.half())
        return torch.cat(out)
    def region_change(s, rows=slice(None), cols=slice(None), n=300):
        """mean pixel change in region (rows × cols) when only one factor changes"""
        r = np.random.default_rng(0); b = s.idx_of(np.stack([r.integers(0, v, n) for v in s.NV], 1)); x0 = s.img(b).float(); out = {}
        for j in range(len(s.FACT)): out[s.FACT[j]] = float((s.img(s.cf_index(b, j, r)).float() - x0)[:, :, rows, cols].abs().mean())
        return out
    def corner_change(s, n=300, px=8, bottom=False):
        """corner (top left, or bottom left if bottom) px×px"""
        return s.region_change(slice(-px, None) if bottom else slice(0, px), slice(0, px), n)
    def check_factor(s, j_big, j_small, ratio=3.0, n=300, px=8, bottom=False):
        """factor-order check (stop condition): changing only j_big must change the corner more than ratio times j_small"""
        out = s.corner_change(n, px, bottom)
        print('  factor-order check (mean corner change when one factor changes): ' + ' '.join(f'{k_} {v:.1f}' for k_, v in out.items()), flush=True)
        assert out[s.FACT[j_big]] > ratio*out[s.FACT[j_small]], f'⚠ factor-order check failed: {s.FACT[j_big]} ({out[s.FACT[j_big]]:.2f}) vs {s.FACT[j_small]} ({out[s.FACT[j_small]]:.2f})'
        return out

class Split:
    """probe · test · training pool from the generative grid without overlap (fixed split seed). XPR · XTE = fixed-noise images"""
    def __init__(s, D, C):
        s.D = D; perm = np.random.default_rng(C['SPLIT']).permutation(D.N); n1, n2 = C['N_PROBE'], C['N_PROBE'] + C['N_TEST']
        s.PR_I, s.TE_I, s.TR_POOL = perm[:n1], perm[n1:n2], perm[n2:]
        assert not np.intersect1d(s.PR_I, s.TE_I).size and not np.intersect1d(s.PR_I, s.TR_POOL[:200000]).size
        s.ytp, s.ytt = D.label(s.PR_I), D.label(s.TE_I); s.alp, s.alt = D.aligned(s.PR_I), D.aligned(s.TE_I)
        s.XPR, s.XTE = D.noisy(s.PR_I, C['NZ']['pr']), D.noisy(s.TE_I, C['NZ']['te']); s.NZ_CF = C['NZ']['cf']
        s.PR_SET = set(s.PR_I.tolist()); s.TE_SET = set(s.TE_I.tolist())
        print(f'  split {C["SPLIT"]}: probe {len(s.PR_I)} · test {len(s.TE_I)} · training pool {len(s.TR_POOL)} · aligned fraction in probe {s.alp.mean():.3f}', flush=True)
    def train_sample(s, rho, seed, n):
        """fraction ρ from aligned images, the rest uniformly from the whole training pool (no overlap with probe · test)"""
        r = np.random.default_rng(700 + seed + int(rho*1000)); al = s.TR_POOL[s.D.aligned(s.TR_POOL)]; n_al = int(round(rho*n)); assert n_al <= len(al), (n_al, len(al))
        a_ = r.choice(al, n_al, replace=False); rest = np.setdiff1d(s.TR_POOL, a_); return np.concatenate([a_, r.choice(rest, n - n_al, replace=False)])
    def probe_only(s, idx, what):
        assert all(int(i) in s.PR_SET for i in np.asarray(idx).ravel()[:5000]), f'⚠ leak: {what} is outside the probe split'

def pairs_of(S, j, seed, n, off=0):
    """counterfactual pairs from the probe split with only factor j changed (same noise). off separates sample batches"""
    D = S.D; r = np.random.default_rng(46000 + 100*j + 7*off + seed); base = S.PR_I[np.sort(r.choice(len(S.PR_I), n, replace=False))]; src = D.cf_index(base, j, r)
    sd = 4600 + 10*j + 1000*off + seed; return D.noisy(base, sd), D.noisy(src, sd), base

# ---------------------------------------------------------------- training (P1 · P2: Wiles+2022 App. F)
def train_grid(S, make_arch, rho, seed, lr, fn, C):
    """from scratch, Adam, batch 128, no augmentation, validation every epoch (N_VAL images held out from the training distribution) → save the best epoch. Training noise redrawn every batch (σ = SIG of the data)"""
    D = S.D; idx = S.train_sample(rho, seed, C['N_TRAIN']); r = np.random.default_rng(880 + seed + int(rho*1000)); p = r.permutation(len(idx))
    vi, ti = np.sort(idx[p[:C['N_VAL']]]), np.sort(idx[p[C['N_VAL']:]]); Xt, Yt = D.img(ti).to(dev), torch.tensor(D.label(ti), device=dev); Xv, Yv = D.noisy(vi, 990 + seed), torch.tensor(D.label(vi), device=dev)
    torch.manual_seed(seed); A = make_arch(seed); m = A.m.train(); opt = torch.optim.Adam(m.parameters(), lr=lr); g = torch.Generator(device=dev).manual_seed(seed); best = (-1.0, -1, None); curve = []; t0 = time.time()
    for ep in range(C['EPOCHS']):
        m.train(); perm = torch.randperm(len(Xt), device=dev, generator=g); tl = torch.zeros((), device=dev); nb = 0
        for i in range(0, len(Xt), C['BS']):
            b = perm[i:i+C['BS']]; xb = Xt[b].float()/255
            if D.SIG > 0: xb = xb + D.SIG*torch.randn(xb.shape, device=dev, generator=g)
            with torch.autocast('cuda', dtype=torch.bfloat16, enabled=(dev == 'cuda')): loss = F.cross_entropy(A.frm(A.to(xb, 0), 0), Yt[b])
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step(); tl = tl + loss.detach(); nb += 1
        m.eval(); tl = float(tl)/max(nb, 1)
        with torch.no_grad(): va = float((torch.tensor(predict(A, Xv), device=dev) == Yv).float().mean())
        curve.append([ep, tl, va])
        if va > best[0]: best = (va, ep, {k_: v.detach().clone() for k_, v in m.state_dict().items()})
        if not np.isfinite(tl): print(f'    diverged (epoch {ep}) → stopped', flush=True); break
    torch.save(best[2], fn); info = {'rho': rho, 'seed': seed, 'lr': lr, 'best_val': best[0], 'best_ep': best[1], 'curve': curve, 'time': time.time() - t0}
    json.dump(info, open(fn + '.json', 'w')); del Xt, Xv, m, opt; torch.cuda.empty_cache(); return info

def train_group(S, gk, Gc, C, mdir):
    """learning rate: {1e-2, 1e-3, 1e-4} best validation of ρ=0 · first seed among (once per architecture). The chosen model is the ρ=0 · first-seed model"""
    import shutil
    os.makedirs(mdir, exist_ok=True); f = f'{mdir}/lr_{gk}.json'; s0 = C['SEEDS'][0]
    if os.path.exists(f): lr = json.load(open(f))['lr']
    else:
        res = {}
        for lr_ in C['LRS']:
            fn = f'{mdir}/lrsel_{gk}_lr{lr_}.pt'; res[lr_] = json.load(open(fn + '.json')) if os.path.exists(fn + '.json') else train_grid(S, Gc['make'], 0.0, s0, lr_, fn, C)
            print(f'  learning-rate candidate [{gk}] {lr_}: best validation {res[lr_]["best_val"]:.4f} (epoch {res[lr_]["best_ep"]})', flush=True)
        lr = max(res, key=lambda x: res[x]['best_val']); fn0 = f'{mdir}/{gk}_rho0.0_s{s0}.pt'
        shutil.copy(f'{mdir}/lrsel_{gk}_lr{lr}.pt', fn0); shutil.copy(f'{mdir}/lrsel_{gk}_lr{lr}.pt.json', fn0 + '.json')
        json.dump({'lr': lr, 'cands': {str(k_): v['best_val'] for k_, v in res.items()}}, open(f, 'w')); print(f'  → [{gk}] learning rate {lr}', flush=True)
    TR = {'lr': lr, 'models': {}}
    for rho in C['RHOS']:
        for seed in C['SEEDS']:
            fn = f'{mdir}/{gk}_rho{rho}_s{seed}.pt'
            info = json.load(open(fn + '.json')) if os.path.exists(fn) and os.path.exists(fn + '.json') else train_grid(S, Gc['make'], rho, seed, lr, fn, C)
            TR['models'][f'rho{rho}_s{seed}'] = {k_: info[k_] for k_ in ['best_val', 'best_ep', 'time']}
            print(f'  training [{gk} ρ={rho} seed {seed}] best validation {info["best_val"]:.4f} (epoch {info["best_ep"]})', flush=True)
    return TR

# ---------------------------------------------------------------- experiment 1: true counterfactuals (IIA; Geiger+2021) — axis swap · minimal cause · DAS
def das_sampler(A, S, seed):
    """DAS training (privileged): probe bases + counterfactuals with one factor changed (same noise), target = network prediction on the counterfactual image"""
    D = S.D; r = np.random.default_rng(4000 + seed)
    def f(bs):
        b = S.PR_I[r.integers(0, len(S.PR_I), bs)]; j = int(r.integers(0, len(D.FACT))); src = D.cf_index(b, j, r); sd = int(r.integers(1 << 30))
        Xb, Xs = D.noisy(b, sd), D.noisy(src, sd)
        with torch.no_grad(): t = A.frm(A.to(Xs, 0), 0).argmax(1); hb, hs = A.to(Xb, S.l), A.to(Xs, S.l)
        return hb.float(), hs.float(), t
    return f

@torch.no_grad()
def _swap_pred(A, l, hb, hs, rd, wr): return A.frm(swap(A, hb, hs, rd, wr), l).argmax(1).cpu().numpy()

def exp1(A, l, S, AXS, FPS, seed, C):
    """on test image pairs differing only in factor f, swap only the k axes of the explanation to the counterfactual values → does it reproduce the actual change of decision. Capture = accuracy on changed instances, specificity = accuracy on unchanged instances.
       pair = (current decision, changed decision or runner-up). Final model (fm|16) = only the minimal-cause C axes (found with probe donors) set to counterfactual values — first N_FM instances (paired with the axis methods on the same instances)"""
    T0 = time.time(); D = S.D; K = METHOD['K']; S.l = l
    DAS = train_das(A, l, K, seed, das_sampler(A, S, seed), C['DAS_STEPS'], C['DAS_BS'])
    rc = np.random.default_rng(9100 + seed); base = S.TE_I[rc.choice(len(S.TE_I), C['N_CF'], replace=False)]; out = {'fact': {}}; csz = []
    MK = [f'{q}|{k}' for q in C['EQ'] for k in C['EK']] + ['das|16']
    for j, fn in enumerate(D.FACT):
        src = D.cf_index(base, j, rc); Fb, Fs = D.F(base), D.F(src); assert (np.delete(Fs, j, 1) == np.delete(Fb, j, 1)).all() and (Fs[:, j] != Fb[:, j]).all()
        sd_ = 6100 + 10*j + seed; Xb, Xs = D.noisy(base, sd_), D.noisy(src, sd_); L0 = logits(A, Xb); p0 = L0.argmax(1); p1 = predict(A, Xs)
        chg = p1 != p0; sec = np.argsort(-L0, 1)[:, 1]; other = np.where(chg, p1, sec); keys = [tuple(sorted((int(x), int(y)))) for x, y in zip(p0, other)]
        pred = {nk: p0.copy() for nk in MK + ['full|0', 'fm|16']}; sub = np.arange(len(base)) < C['N_FM']
        for key in set(keys):
            if key not in AXS: continue
            ii = np.array([n for n, k_ in enumerate(keys) if k_ == key])
            for s_ in range(0, len(ii), A.bs):
                bi = ii[s_:s_+A.bs]; tb = torch.tensor(bi, device=dev)
                with torch.no_grad():
                    hb, hs = A.to(Xb[tb], l).float(), A.to(Xs[tb], l).float(); pred['full|0'][bi] = A.frm(A.from_units(A.units(hb) + A.units(hs - hb), hb), l).argmax(1).cpu().numpy()
                    for nk in MK:
                        q, k = nk.split('|'); k = int(k); rd, wr = DAS if q == 'das' else (np.asarray(AXS[key][q][0])[:k], np.asarray(AXS[key][q][1])[:k]); pred[nk][bi] = _swap_pred(A, l, hb, hs, rd, wr)
                pm = FPS['tvo_cp'].get(key); bm = sub[bi]
                if pm is not None and bm.any():
                    for cur in set(p0[bi][bm].tolist()):
                        if cur not in key: continue
                        msk = bm & (p0[bi] == cur); sb = bi[msk]; mt = torch.tensor(msk, device=dev); hb2, hs2 = hb[mt], hs[mt]; Cs, _ = minimal_cause(A, l, pm, hb2, int(cur))
                        mk = np.zeros((len(sb), 1, K), np.float32); has = np.array([Cc is not None for Cc in Cs])
                        for t_, Cc in enumerate(Cs):
                            if Cc: mk[t_, 0, Cc] = 1; csz.append(len(Cc))
                        Lk = donor_logits(A, l, hb2, hs2[:, None], pm.rd, pm.wr, mk)[:, 0].cpu().numpy().argmax(1); pred['fm|16'][sb] = np.where(has, Lk, p0[sb])
                del hb, hs
        cov = np.array([k_ in AXS for k_ in keys]); Fo = {'R': float(chg.mean()), 'n_chg': int(chg.sum()), 'n_same': int((~chg).sum()), 'n_chg_sub': int(chg[sub].sum()), 'covered': float(cov.mean()), 'm': {}, 'm_sub': {}}
        for nk, pv in pred.items():
            hit = pv == p1
            if nk != 'fm|16': Fo['m'][nk] = {'cap': float(hit[chg].mean()) if chg.sum() else float('nan'), 'spec': float(hit[~chg].mean()) if (~chg).sum() else float('nan'), 'E': float((pv != p0).mean())}
            c_, s_ = chg & sub, ~chg & sub; Fo['m_sub'][nk] = {'cap': float(hit[c_].mean()) if c_.sum() else float('nan'), 'spec': float(hit[s_].mean()) if s_.sum() else float('nan')}
        Fo['full_check'] = float((pred['full|0'][cov] == p1[cov]).mean()) if cov.any() else float('nan')
        assert not cov.any() or Fo['full_check'] > 0.99, f'⚠ full swap does not reproduce the counterfactual prediction ({Fo["full_check"]:.3f}) → swap path error'
        out['fact'][fn] = Fo; del Xb, Xs
    v = list(FPS['tvo_cp'].values()); out['lens_flag_frac'] = float(np.mean([bool(p.flag) for p in v])) if v and v[0].flag is not None else float('nan')
    out['R_s_med'] = float(np.nanmedian([p.R_s for p in v])) if v else float('nan'); out['C_size_mean'] = float(np.mean(csz)) if csz else float('nan'); out['time'] = time.time() - T0
    print(f'  ① experiment 1 {out["time"]:.0f}s: per-factor reliance R ' + ' '.join(f'{fn[:6]} {Fo["R"]:.3f}' for fn, Fo in out['fact'].items()) + f' · mean minimal cause {out["C_size_mean"]:.2f}axes', flush=True)
    torch.cuda.empty_cache(); return out

def e1_main(E, nk, sub=False, nmin=30):
    """per factor (capture + specificity)/2, averaged over factors with at least nmin changed instances"""
    key, nn_ = ('m_sub', 'n_chg_sub') if sub else ('m', 'n_chg'); v = [(Fo[key][nk]['cap'] + Fo[key][nk]['spec'])/2 for Fo in E['fact'].values() if Fo[nn_] >= nmin and nk in Fo[key]]
    return float(np.mean(v)) if v else float('nan')
def e1_false(E, nk):
    v = [1 - Fo['m'][nk]['spec'] for Fo in E['fact'].values() if Fo['R'] < 0.01 and np.isfinite(Fo['m'][nk]['spec'])]; return float(np.mean(v)) if v else float('nan')

# ---------------------------------------------------------------- 5. Kelley: diagnostic statistics · selection · treatment evaluation
@torch.no_grad()
def kelley_diag(A, l, S, seed, C):
    """per factor (N_D probe counterfactual pairs): flip rate R · second moment of hidden differences Σ_Δ (position mean). μ = per-position mean on shortcut-factor bases. SHZ = cross-covariance with one-hot shortcut values (LEACE)"""
    D = S.D; out = {'R': {}, 'SD': {}}; MU = None; nb = 0; SH = ZS = None; nsh = 0
    for j in range(len(D.FACT)):
        Xb, Xs, base = pairs_of(S, j, seed, C['N_D']); S.probe_only(base, 'Kelley diagnosis bases'); SD = None; fl = []; z_all = np.eye(D.NV[j])[D.F(base)[:, j]]; npos = 0
        for i in range(0, len(base), A.bs):
            hb, hs = A.to(Xb[i:i+A.bs], l).float(), A.to(Xs[i:i+A.bs], l).float(); fl.append((A.frm(hb, l).argmax(1) != A.frm(hs, l).argmax(1)).cpu().numpy())
            d = A.units(hs - hb).reshape(-1, hb.shape[1] if hb.dim() == 4 else hb.shape[-1]).double(); SD = d.T @ d if SD is None else SD + d.T @ d; npos = d.shape[0]//len(hb)
            if j == D.J_SC:
                gd = hb.double(); MU = gd.sum(0) if MU is None else MU + gd.sum(0); nb += len(gd); z = torch.tensor(z_all[i:i+A.bs], device=dev, dtype=torch.float64)
                sh = torch.einsum('bchw,bz->cz', gd, z) if gd.dim() == 4 else torch.einsum('btc,bz->cz', gd, z); SH = sh if SH is None else SH + sh; ZS = z.sum(0) if ZS is None else ZS + z.sum(0); nsh += len(gd)
        out['R'][j] = float(np.concatenate(fl).mean()); out['SD'][j] = (SD/(len(base)*npos)).cpu().numpy(); del Xb, Xs
    MU = MU/nb; out['mu'] = MU.float(); P_ = (MU.shape[1]*MU.shape[2]) if MU.dim() == 3 else MU.shape[0]; mu_sum = MU.sum((1, 2)) if MU.dim() == 3 else MU.sum(0)
    out['SHZ'] = ((SH - torch.outer(mu_sum, ZS))/(nsh*P_)).cpu().numpy(); return out

@torch.no_grad()
def make_selector(A, l, S, mu, DIRS, S2, Si2, seed, C):
    D = S.D; r = np.random.default_rng(48000 + seed); b_ = S.PR_I[np.sort(r.choice(len(S.PR_I), C['N_P'], replace=False))]; sd = 4800 + seed; S.probe_only(b_, 'selection-stage bases')
    Hb = hidden(A, D.noisy(b_, sd), l); Hj = {j: hidden(A, D.noisy(D.cf_index(b_, j, r), sd), l) for j in range(len(D.FACT))}
    ia = np.where(S.alp)[0][:C['N_AG']]; Hag = hidden(A, S.XPR[torch.tensor(ia, device=dev)], l)
    return Selector(A, l, mu, DIRS, S2, Si2, Hb, Hj, Hag, D.J_LABEL, D.NUIS, D.FACT)

@torch.no_grad()
def eval_treat(A, l, S, seed, TS, C):
    """test split: accuracy · accuracy on conflicting (not aligned) images acc_conf · flip rate R_sc of shortcut-only pairs"""
    D = S.D; nT = min(C['ED_NTEST'], len(S.TE_I)); yt, alt = S.ytt[:nT], S.alt[:nT]
    rc = np.random.default_rng(9500 + seed); base = S.TE_I[rc.choice(len(S.TE_I), C['ED_NCF'], replace=False)]; src = D.cf_index(base, D.J_SC, rc)
    XS = {'te': S.XTE[:nT], 'f0': D.noisy(base, 4400 + seed), 'f1': D.noisy(src, 4400 + seed)}; P = {nm: {} for nm in TS}; FE = {}
    for k_, X_ in XS.items():
        fe = []
        for i in range(0, len(X_), A.bs):
            h = A.to(X_[i:i+A.bs], l).float(); fe.append(TS['none'].feat(h).double().cpu())
            for nm, T in TS.items(): P[nm].setdefault(k_, []).append(T.head(h).argmax(1).cpu())
        FE[k_] = torch.cat(fe).numpy()
    out = {}
    for nm in TS:
        pr = {k_: torch.cat(v).numpy() for k_, v in P[nm].items()}
        out[nm] = {'acc_all': float((pr['te'] == yt).mean()), 'acc_conf': float((pr['te'][~alt] == yt[~alt]).mean()), 'R_sc': float((pr['f0'] != pr['f1']).mean())}
    return out, FE, (yt, alt)

def dfr_fit(Fv, yv, ncls, seed, Cs=(0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0), folds=5):
    """DFR (Kirichenko+2023) label-only version: L1 logistic regression (liblinear, random_state 0) on standardized output-layer input features. C = held-out log loss of 5-fold CV"""
    from sklearn.preprocessing import StandardScaler; from sklearn.metrics import log_loss
    sc = StandardScaler().fit(Fv); Z = sc.transform(Fv); fold = np.random.default_rng(seed).permutation(len(Z)) % folds; best, bC = np.inf, None
    for Cc in Cs:
        ll = 0.0
        for f in range(folds):
            tr, te = fold != f, fold == f
            if len(np.unique(yv[tr])) < ncls: ll = np.inf; break
            clf = LogisticRegression(penalty='l1', C=Cc, solver='liblinear', max_iter=2000, random_state=0).fit(Z[tr], yv[tr]); ll += log_loss(yv[te], clf.predict_proba(Z[te]), labels=list(range(ncls)), normalize=False)
        if ll < best: best, bC = ll, Cc
    if bC is None: bC = 1.0
    clf = LogisticRegression(penalty='l1', C=bC, solver='liblinear', max_iter=2000, random_state=0).fit(Z, yv); return (lambda F_: clf.predict(sc.transform(F_))), bC

def dfr_probe(A, l, S, seed, FE, ya, C):
    """DFR 400 images (probe, labels only): untreated features. Test metrics on the same images as eval_treat"""
    yt, alt = ya; runs = []
    for dr in range(C['DFR_DRAWS']):
        nV = C['DFR_NV']; rv = np.random.default_rng(9400 + 1000*dr + seed*10 + nV); Vi = rv.choice(len(S.PR_I), nV, replace=False)
        with torch.no_grad(): HV = hidden(A, S.XPR[torch.tensor(Vi, device=dev)], l); FV = torch.cat([Treat(A, l).feat(HV[i:i+A.bs]).double().cpu() for i in range(0, len(HV), A.bs)]).numpy()
        fd, _ = dfr_fit(FV, S.ytp[Vi], S.D.NCLS, 1000*dr + nV); pr = {k_: fd(v) for k_, v in FE.items()}
        runs.append({'acc_all': float((pr['te'] == yt).mean()), 'acc_conf': float((pr['te'][~alt] == yt[~alt]).mean()), 'R_sc': float((pr['f0'] != pr['f1']).mean())})
    return {k_: float(np.mean([r_[k_] for r_ in runs])) for k_ in runs[0]}

# ---------------------------------------------------------------- integration (1–5): explaining shortcut-caused errors → diagnosis
@torch.no_grad()
def integ(A, l, S, FPS, mu, seed, S2, DIRS, top_kelley, C):
    """shortcut-caused error = a conflicting test image that is misclassified but correctly classified on the counterfactual with only the shortcut factor matched to the label (others unchanged).
       X1 cross restoration: found without the original (8 probe donors of the true class) 'why the prediction and not the true class' set only the axes of its minimal cause C to counterfactual values → does it return to the true class
          controls: same procedure with TA 16 · random 16, random subsets of the same size within tv-O 16
       X2 factor pointed to by the explanation: share of the cause axes (whitened q) lying in the Kelley-specific subspace of factor f (top 16, orthonormal) → maximum = factor pointed to
       X3 lens: do pair-level (R_s) · instance-level (residual) lenses predict cross-restoration failure (AUROC) · X4 (reported) alignment margin of the half the lens trusts"""
    D = S.D; T0 = time.time(); pt = predict(A, S.XTE); conf = ~S.alt; err = np.where(conf & (pt != S.ytt))[0]; out = {'n_conf': int(conf.sum()), 'n_conf_err': int(len(err))}
    r = np.random.default_rng(9700 + seed); cand = err[r.permutation(len(err))][:4*C['N_X']]
    if len(cand) == 0: out['skip'] = True; print('  ③ integration: no conflicting errors → skipped', flush=True); return out
    base = S.TE_I[cand]; src = D.sc_align(base, r); Fb, Fs = D.F(base), D.F(src)
    assert (np.delete(Fs, D.J_SC, 1) == np.delete(Fb, D.J_SC, 1)).all() and (Fs[:, D.J_SC] != Fb[:, D.J_SC]).all() and D.aligned(src).all()
    Xs = D.noisy(src, 9710 + seed); ps = predict(A, Xs); ok_cf = ps == S.ytt[cand]; out['frac_sc_err'] = float(ok_cf.mean()); Q = ['tvo_cp', 'ta_or', 'rand_cp']
    keep = [i for i in np.where(ok_cf)[0] if all(tuple(sorted((int(S.ytt[cand[i]]), int(pt[cand[i]])))) in FPS[q] for q in Q)][:C['N_X']]; out['n_sc_err'] = int(len(keep))
    if len(keep) < C['X_NMIN']: out['skip'] = True; print(f'  ③ integration: shortcut-caused errors {len(keep)}(< {C["X_NMIN"]}) → skipped', flush=True); return out
    keep = np.array(keep); ci = cand[keep]; u_ = S.ytt[ci].astype(int); v_ = pt[ci].astype(int); n = len(ci)
    Hb = hidden(A, S.XTE[torch.tensor(ci, device=dev)], l); Hs = hidden(A, Xs[torch.tensor(keep, device=dev)], l); Lb = A.frm(Hb, l).float().cpu().numpy(); Pb = A.pool(Hb).double().cpu().numpy()
    U = {f: np.linalg.qr(DIRS['w'][f][1][:, :16])[0] for f in D.NUIS}; rr = np.random.default_rng(9720 + seed); res = {}; grp = sorted(set(zip(u_.tolist(), v_.tolist())))
    for q in Q:
        ok, rs, nn_ = np.zeros(n, bool), np.zeros(n, bool), np.full(n, np.nan); al = {f: np.full(n, np.nan) for f in D.NUIS}; resid, prs, pfl = np.full(n, np.nan), np.full(n, np.nan), np.zeros(n, bool)
        for u, v in grp:
            ii = np.where((u_ == u) & (v_ == v))[0]; pm = FPS[q][tuple(sorted((u, v)))]; ti = torch.tensor(ii, device=dev)
            Cs, _ = minimal_cause(A, l, pm, Hb[ti], int(v)); ok[ii] = restore(A, l, pm, Hb[ti], Hs[ti][:, None], Cs, u); nn_[ii] = [len(Cc) if Cc is not None else np.nan for Cc in Cs]
            if q == 'tvo_cp':
                Cr = [sorted(rr.choice(len(pm.U), len(Cc), replace=False).tolist()) if Cc else None for Cc in Cs]; rs[ii] = restore(A, l, pm, Hb[ti], Hs[ti][:, None], Cr, u)
                Qw = pm.rd @ S2; Qw = Qw/np.linalg.norm(Qw, axis=1, keepdims=True)
                for t, i in enumerate(ii):
                    if Cs[t]:
                        for f in D.NUIS: al[f][i] = float(np.mean([np.sum((U[f].T @ Qw[j])**2) for j in Cs[t]]))
                resid[ii] = case_lens(pm, Pb[ii], Lb[ii]); prs[ii] = pm.R_s; pfl[ii] = bool(pm.flag)
        o = {'cross': float(ok.mean()), 'none': float(np.isnan(nn_).mean()), 'size': float(np.nanmedian(nn_)) if np.isfinite(nn_).any() else float('nan'), 'ok': ok}
        if q == 'tvo_cp':
            fail = ~ok; auc = lambda s_: float(roc_auc_score(fail, s_)) if 0 < fail.sum() < n and np.isfinite(s_).all() and np.ptp(s_) > 0 else float('nan')
            AL = {D.FACT[f]: float(np.nanmean(al[f])) for f in D.NUIS}; lo = resid <= np.median(resid); oth = [f for f in D.NUIS if f != D.J_SC]
            mg = lambda m: float(np.nanmean(al[D.J_SC][m]) - max(np.nanmean(al[f][m]) for f in oth)) if m.any() else float('nan')
            pair_ok = len(grp) > 1 and len(FPS[q]) >= 3 and FPS[q][next(iter(FPS[q]))].flag is not None
            o.update({'rsub': float(rs.mean()), 'rsub_ok': rs, 'align': AL, 'top_expl': max(AL, key=AL.get), 'lens_auroc_case': auc(resid), 'lens_auroc_pair': auc(-prs) if pair_ok else float('nan'),
                      'cross_flagged_pair': float(ok[pfl].mean()) if pfl.any() else float('nan'), 'cross_unflagged_pair': float(ok[~pfl].mean()) if (~pfl).any() else float('nan'),
                      'margin_reliable': mg(lo), 'margin_unreliable': mg(~lo), 'cross_reliable': float(ok[lo].mean()), 'cross_unreliable': float(ok[~lo].mean())})
        res[q] = o
    t = res['tvo_cp']; out.update({'n': n, 'n_pairs_err': len(grp), 'top_kelley': top_kelley, 'time': time.time() - T0,
                                   'res': {q: {k_: v for k_, v in o.items() if k_ not in ('ok', 'rsub_ok')} for q, o in res.items()}})
    print(f'  ③ integration {out["time"]:.0f}s: shortcut-caused errors {n}({len(grp)}pairs) · cross restoration tv-O {t["cross"]:.3f} / TA {res["ta_or"]["cross"]:.3f} / random {res["rand_cp"]["cross"]:.3f} / same-size random {t["rsub"]:.3f}'
          f' · factor pointed to {t["top_expl"]} (Kelley top {top_kelley}) · lens AUROC instance {t["lens_auroc_case"]:.3f} / pair {t["lens_auroc_pair"]:.3f}', flush=True)
    return out

# ---------------------------------------------------------------- 4. combination risk prediction (grid: factor = counterfactual factor)
def risk_grid(A, l, S, AXS, seed, C, methods):
    """partial tests: N_V probe counterfactual pairs per factor (off=1, samples different from the diagnosis). Combinations: N_V test bases, one per factor pair · images with both changed (same noise). Combined images only for checking against ground truth"""
    D = S.D; head = lambda h: A.frm(h, l).float()
    def part(j):
        Xb, Xs, _ = pairs_of(S, j, seed, C['N_V'], off=1)
        for i in range(0, len(Xb), A.bs): yield A.to(Xb[i:i+A.bs], l).float(), A.to(Xs[i:i+A.bs], l).float()
    rc = np.random.default_rng(9800 + seed); plans = []
    for pi, (j1, j2) in enumerate(itertools.combinations(range(len(D.FACT)), 2)):
        base = S.TE_I[rc.choice(len(S.TE_I), C['N_V'], replace=False)]; Fb = D.F(base); F1 = Fb.copy(); F1[:, j1] = (F1[:, j1] + rc.integers(1, D.NV[j1], len(base))) % D.NV[j1]
        F2 = Fb.copy(); F2[:, j2] = (F2[:, j2] + rc.integers(1, D.NV[j2], len(base))) % D.NV[j2]; F12 = F1.copy(); F12[:, j2] = F2[:, j2]; plans.append((f'{D.FACT[j1]}+{D.FACT[j2]}', [Fb, F1, F2, F12], S.NZ_CF + 500 + 10*pi + seed))
    def comb(Fs, sd):
        X = [D.noisy(D.idx_of(F_), sd) for F_ in Fs]
        for i in range(0, len(X[0]), A.bs): yield tuple(A.to(x[i:i+A.bs], l).float() for x in X)
    T0 = time.time(); out = risk_eval(head, AXS, methods, [(D.FACT[j], part(j)) for j in range(len(D.FACT))], [(nm, comb(Fs, sd)) for nm, Fs, sd in plans], D.NCLS)
    r = np.random.default_rng(45000 + seed); ii = np.sort(r.choice(len(S.PR_I), 1000, replace=False)); H = hidden(A, S.XPR[torch.tensor(ii, device=dev)], l)
    out['_case5'] = case5(H, AXS, [m.split('|')[0] for m in methods if not m.startswith('full')]); out['time'] = time.time() - T0; return out

@torch.no_grad()
def wrap_check(A, EA, T, l, X):
    """wrapper check: treated-network wrapper = Treat head (explanation-layer path and path from the input)"""
    h = A.to(X, l); z0 = T.head(h); return float(max((z0 - EA.frm(EA.to(X, l), l)).abs().max(), (z0 - EA.frm(EA.to(X, 0), 0)).abs().max()))

VARS = {'ours': 'w', 'nok': 'n', 'geo': 'e'}
VMETH = ['tvo_cp|16', 'ta_or|16', 'cpta_cp|16', 'pca_or|16', 'rand_cp|16', 'full|0']

def run_model(A, l, S, rho, seed, C, extra=None):
    """all experiments of one model. extra(A, l, S, seed, TS, DG) → dict: dataset-specific extra evaluation (P3: real Waterbirds WGA · GRIT · DFR)"""
    T0 = time.time(); D = S.D; R = {'rho': rho, 'seed': seed}; arch_check(A, S.XTE[:8])
    yp = predict(A, S.XPR); R['acc_test'] = float((predict(A, S.XTE) == S.ytt).mean()); R['acc_probe'] = float((yp == S.ytp).mean())
    AXS, S2, Si2, POOL = axes_all(A, l, S.XPR, yp, D.PAIRS, seed); FPS, mu_g = fit_pairs(A, l, S.XPR, yp, AXS, POOL, seed, methods=('tvo_cp', 'ta_or', 'rand_cp'))
    R['n_pairs'] = len(AXS); R['lens'] = {'R_s': {f'{a}-{b}': pm.R_s for (a, b), pm in FPS['tvo_cp'].items()}, 'flag': {f'{a}-{b}': pm.flag for (a, b), pm in FPS['tvo_cp'].items()}}
    R['exp1'] = exp1(A, l, S, AXS, FPS, seed, C)
    DG = kelley_diag(A, l, S, seed, C); mu = DG['mu']; DIRS = {g: {f: spec_dirs(DG['SD'][f], DG['SD'][D.J_LABEL], S2, Si2, g) for f in D.NUIS} for g in ['w', 'e', 'n']}
    sel = make_selector(A, l, S, mu, DIRS, S2, Si2, seed, C); b0 = sel.get('w', ()); dsc = {f: b0['R'][f] - sel.get('w', ((f, 16),))['R'][f] for f in D.NUIS}; top = D.FACT[max(dsc, key=dsc.get)]
    R['diag'] = {'R': {D.FACT[j]: DG['R'][j] for j in DG['R']}, 'score': {D.FACT[f]: float(v) for f, v in dsc.items()}, 'top': top, 'spec_share': float(dsc[D.J_SC]/max(DG['R'][D.J_SC], 1e-9)), 'S_none': b0['S']}
    print(f'  ② diagnosis: flips ' + ' '.join(f'{D.FACT[j][:6]} {DG["R"][j]:.3f}' for j in DG['R']) + f' → top {top}', flush=True)
    R['integ'] = integ(A, l, S, FPS, mu_g, seed, S2, DIRS, top, C)
    TS = {'none': Treat(A, l)}; R['select'] = {}; CH = {}
    for nm, g in VARS.items():
        info, best = select(sel, g); gb = sel.get(g, best); info.update({'S': gb['S'], 'P': gb['P'], 'agree': gb['agree']}); R['select'][nm] = info; CH[nm] = best
        TS[nm] = Treat(A, l, (gb['Mx'], mu)) if best else Treat(A, l); print(f'  ② selection [{nm}] {info["key"]} · J {info["J_none"]:.4f} → {info["J"]:.4f}', flush=True)
    ftop = D.FACT.index(top); TS['top16'] = Treat(A, l, (sel.get('w', ((ftop, 16),))['Mx'], mu))
    Mh, k95 = hard_matrix(DG['SD'][D.J_SC], S2, Si2); Ml, rk = leace_matrix(DG['SHZ'], S2, Si2); TS['hard_sc'] = Treat(A, l, (Mh, mu)); TS['leace_sc'] = Treat(A, l, (Ml, mu))
    R['treat_info'] = {'k95_hard': k95, 'leace_rank': rk}; R['eval'], FE, ya = eval_treat(A, l, S, seed, TS, C)
    R['path_check'] = abs(float((predict(A, S.XTE[:len(ya[0])]) == ya[0]).mean()) - R['eval']['none']['acc_all'])          # path from the input vs explanation-layer path
    assert R['path_check'] < 0.002, f'⚠ path check failed ({R["path_check"]})'
    R['dfr400'] = dfr_probe(A, l, S, seed, FE, ya, C)
    if extra is not None: R['extra'] = extra(A, l, S, seed, TS, DG)
    print(f'  ② treatment acc_conf: ' + ' · '.join(f'{nm} {v["acc_conf"]:.3f}' for nm, v in R['eval'].items()) + f' · DFR400 {R["dfr400"]["acc_conf"]:.3f}', flush=True)
    R['verify'] = {'before': risk_grid(A, l, S, AXS, seed, C, VMETH)}
    if CH['ours']:
        EA = EditedArch(A, TS['ours'].E[0], mu, l); R['wrap_check'] = wrap_check(A, EA, TS['ours'], l, S.XTE[:500])
        assert R['wrap_check'] < 1e-3, f'⚠ wrapper check failed ({R["wrap_check"]})'
        AXS_e, _, _, _ = axes_all(EA, l, S.XPR, predict(EA, S.XPR), D.PAIRS, seed); R['verify']['after'] = risk_grid(EA, l, S, AXS_e, seed, C, VMETH); del EA, AXS_e
    else: R['verify']['after'] = R['verify']['before']; R['wrap_check'] = 0.0
    R['verify_after_is_none'] = not CH['ours']
    print(f'  ④ risk prediction Brier before treatment ' + ' '.join(f'{nm.split("|")[0]} {R["verify"]["before"][nm]["brier"]:.4f}' for nm in VMETH) + ' · after treatment ' + ' '.join(f'{nm.split("|")[0]} {R["verify"]["after"][nm]["brier"]:.4f}' for nm in VMETH), flush=True)
    R['time'] = time.time() - T0; del sel, AXS, FPS; torch.cuda.empty_cache(); return R

# ---------------------------------------------------------------- pre-registered verdicts (common to P1–P3) · tables
def ev(R, nm, k_='acc_conf'): return R['dfr400'][k_] if nm == 'dfr' else R['eval'][nm][k_]

def verdict_rows(RD, D, metric, c6_margin=0.01):
    """metric(R, treatment name) → shortcut metric (P1 · P2: acc_conf, P3: real WGA). RD = {(ρ, seed): R}. Returns judge input rows"""
    ALL = list(RD.values()); HI = [R for R in ALL if R['rho'] >= 0.5]; LO = [R for R in ALL if R['rho'] <= 0.25]; rows = []
    dd = lambda a, b, M=HI: [metric(R, a) - metric(R, b) for R in M]
    rows.append(dict(no='C1 ★', desc='shortcut metric (ρ ≥ .5): ours > no treatment (threshold .02)', fam='treatment', d=dd('ours', 'none'), thr=0.02, kind='diff'))
    for b_, nm_, no in [('hard_sc', 'stage20 (shortcut given, k95)', 'C2 ★'), ('leace_sc', 'LEACE (shortcut labels)', 'C3 ★')]:
        la = float(np.mean([ev(R, 'ours', 'acc_all') - ev(R, b_, 'acc_all') for R in HI])) if HI else float('nan')
        rows.append(dict(no=no, desc=f'shortcut metric (ρ ≥ .5): ours > {nm_} (threshold .005), mean difference of acc_all ≥ −.01', fam='treatment', d=dd('ours', b_), thr=0.005, kind='diff', cond=bool(la >= -0.01), acc_all_diff=la))
    rows.append(dict(no='C4 ★', desc='shortcut metric (ρ ≥ .5): Kelley specificity > no shape contrast (threshold .005)', fam='treatment', d=dd('ours', 'nok'), thr=0.005, kind='diff'))
    rows.append(dict(no='C5', desc='shortcut metric (ρ ≥ .5): Σ-orthogonal removal > removal in original coordinates (threshold .005)', fam='treatment', d=dd('ours', 'geo'), thr=0.005, kind='diff'))
    rows.append(dict(no='C6', desc=f'shortcut metric (ρ ≥ .5): ours ≥ DFR − {c6_margin}', fam='treatment', d=[x + c6_margin for x in dd('ours', 'dfr')], thr=0.0, kind='diff'))
    for w_, no, fam in [('before', 'C0', 'before validation'), ('after', 'C9', 'after validation')]:
        Mw = ALL if w_ == 'before' else [R for R in ALL if not R['verify_after_is_none']]
        vv = lambda m_, b_: [R['verify'][w_][b_][m_] - R['verify'][w_]['tvo_cp|16'][m_] for R in Mw]
        for b_ in ['ta_or|16', 'cpta_cp|16', 'pca_or|16']: rows.append(dict(no=f'{no} V1', desc=f'[{w_}] Brier: tv-O < {b_}', fam=fam, d=vv('brier', b_), thr=0.0, kind='diff'))
        for b_ in ['ta_or|16', 'cpta_cp|16']: rows.append(dict(no=f'{no} V2', desc=f'[{w_}] flip-rate error: tv-O < {b_}', fam=fam, d=vv('rate_err', b_), thr=0.0, kind='diff'))
        for b_ in ['ta_or|16', 'cpta_cp|16']: rows.append(dict(no=f'{no} V3', desc=f'[{w_}] AUROC non-inferiority: tv-O ≥ {b_} − .005', fam=fam, d=[-x + 0.005 for x in vv('auroc', b_)], thr=0.0, kind='diff'))
        rows.append(dict(no=f'{no} V3', desc=f'[{w_}] AUROC: tv-O > PCA', fam=fam, d=[-x for x in vv('auroc', 'pca_or|16')], thr=0.0, kind='diff'))
        for b_ in ['ta_or|16', 'cpta_cp|16']: rows.append(dict(no=f'{no} V4', desc=f'[{w_}] tv-O (uncalibrated) Brier ≤ {b_} (slope-calibrated) + .002', fam=fam, d=[R['verify'][w_][b_ + '|cal']['brier'] - R['verify'][w_]['tvo_cp|16']['brier'] + 0.002 for R in Mw], thr=0.0, kind='diff'))
        for b_ in ['ta_or|16', 'cpta_cp|16']: rows.append(dict(no=f'{no} V5', desc=f'[{w_}] ECE: tv-O < {b_}', fam=fam, d=vv('ece', b_), thr=0.0, kind='diff'))
    for b_ in ['ta_or', 'cpta_cp', 'pca_or', 'agop_or']: rows.append(dict(no='E1 ★', desc=f'[experiment 1] main metric (k=16): tv-O > {b_}', fam='experiment1', d=[e1_main(R['exp1'], 'tvo_cp|16') - e1_main(R['exp1'], f'{b_}|16') for R in ALL], thr=0.0, kind='diff'))
    rows.append(dict(no='E3', desc='[experiment 1] main metric (same instances): final model (minimal cause) > TA k=16', fam='experiment1', d=[e1_main(R['exp1'], 'fm|16', True) - e1_main(R['exp1'], 'ta_or|16', True) for R in ALL], thr=0.0, kind='diff'))
    g2 = [x for x in (e1_false(R['exp1'], 'tvo_cp|16') for R in ALL) if np.isfinite(x)]
    rows.append(dict(no='E2', desc=f'[experiment 1] false-change rate (factors with R < .01): tv-O k=16 ≤ .02 (mean {np.mean(g2) if g2 else float("nan"):.4f})', fam='count', d=[bool(g2) and float(np.mean(g2)) <= 0.02]*max(len(g2), 1), thr=0, kind='count'))
    rows.append(dict(no='C7', desc='no harm (ρ ≤ .25): |Δ shortcut metric| ≤ .01 and acc_all loss ≤ .01', fam='count', d=[abs(metric(R, 'ours') - metric(R, 'none')) <= 0.01 and ev(R, 'ours', 'acc_all') >= ev(R, 'none', 'acc_all') - 0.01 for R in LO], thr=0, kind='count'))
    rows.append(dict(no='C8', desc='diagnosis (ρ ≥ .5): top = shortcut factor', fam='count', d=[R['diag']['top'] == D.FACT[D.J_SC] for R in HI], thr=0, kind='count'))
    rows.append(dict(no='C10', desc='harm prevention (ρ ≤ .25): with selection ≥ diagnosis top + fixed k16', fam='count', d=[metric(R, 'ours') >= metric(R, 'top16') for R in LO], thr=0, kind='count'))
    XI = [R for R in ALL if not R['integ'].get('skip')]
    if XI:
        X = lambda R, q, k_='cross': R['integ']['res'][q][k_]
        rows.append(dict(no='X1 ★', desc='cross restoration: final model > TA 16', fam='integration', d=[X(R, 'tvo_cp') - X(R, 'ta_or') for R in XI], thr=0.0, kind='diff'))
        rows.append(dict(no='X1 ★', desc='cross restoration: final model > random 16', fam='integration', d=[X(R, 'tvo_cp') - X(R, 'rand_cp') for R in XI], thr=0.0, kind='diff'))
        rows.append(dict(no='X1 ★', desc='cross restoration: minimal cause > same-size random subset', fam='integration', d=[X(R, 'tvo_cp') - X(R, 'tvo_cp', 'rsub') for R in XI], thr=0.0, kind='diff'))
        rows.append(dict(no='X2 ★', desc='factor pointed to by the explanation = shortcut = Kelley diagnosis top', fam='count', d=[X(R, 'tvo_cp', 'top_expl') == D.FACT[D.J_SC] == R['integ']['top_kelley'] for R in XI], thr=0, kind='count'))
        for k_, nm_ in [('lens_auroc_case', 'instance level (extension)'), ('lens_auroc_pair', 'pair level')]:
            rows.append(dict(no='X3', desc=f'lens {nm_} AUROC (predicting cross-restoration failure) > .5', fam='lens', d=[X(R, 'tvo_cp', k_) - 0.5 for R in XI], thr=0.0, kind='diff'))
        rows.append(dict(no='X4', desc='(reported) alignment margin: half the lens trusts − half it does not', fam='reported', d=[X(R, 'tvo_cp', 'margin_reliable') - X(R, 'tvo_cp', 'margin_unreliable') for R in XI], thr=0.0, kind='report'))
    rows.append(dict(no='D1', desc='(reported) specific-direction share (ρ ≥ .5)', fam='reported', d=[R['diag']['spec_share'] for R in HI], thr=0.0, kind='report'))
    return rows

def mci(v):
    v = np.asarray([x for x in v if x is not None and np.isfinite(x)], float)
    return '—' if len(v) == 0 else f'{v.mean():.4f} ± {1.96*v.std(ddof=1)/np.sqrt(len(v)):.4f}' if len(v) > 1 else f'{v.mean():.4f}'

def tables(RD, D, metric, tag, OUT, names, c6_margin=0.01):
    """tables (CSV · LaTeX) + verdicts. names = {treatment name: label}"""
    P = f'{OUT}/paper'; os.makedirs(P, exist_ok=True); ALL = list(RD.values()); show = lambda df, t, fn: (print(f'\n=== {t} ===\n' + df.to_string()), df.to_csv(f'{P}/{fn}.csv'), df.to_latex(f'{P}/{fn}.tex', float_format='%.4f'))
    rhos = sorted({R['rho'] for R in ALL})
    show(pd.DataFrame({f'ρ={rho}': {lab: mci([metric(R, nm) for R in ALL if R['rho'] == rho]) for nm, lab in names.items()} for rho in rhos}).T, f'{tag} shortcut metric (by ρ)', f'{tag}_shortcut_by_rho')
    show(pd.DataFrame({lab: {k_: mci([ev(R, nm, k_) for R in ALL if R['rho'] >= 0.5]) for k_ in ['acc_all', 'acc_conf', 'R_sc']} for nm, lab in names.items()}).T, f'{tag} treatment (ρ ≥ .5)', f'{tag}_treat_hi')
    nks = [f'{q}|{k}' for q in ['tvo_cp', 'ta_or', 'cpta_cp', 'pca_or', 'agop_or', 'rand_cp'] for k in [4, 16]] + ['das|16', 'full|0']
    E1 = {nk: {'main metric': mci([e1_main(R['exp1'], nk) for R in ALL]), 'false-change rate': mci([e1_false(R['exp1'], nk) for R in ALL]), 'same instances': mci([e1_main(R['exp1'], nk, True) for R in ALL])} for nk in nks}
    E1['★ final model (minimal cause)'] = {'main metric': '—', 'false-change rate': '—', 'same instances': mci([e1_main(R['exp1'], 'fm|16', True) for R in ALL])}; show(pd.DataFrame(E1).T, f'{tag} experiment 1', f'{tag}_exp1')
    for w_ in ['before', 'after']:
        show(pd.DataFrame({nm + c_: {m_: mci([R['verify'][w_][nm + c_][m_] for R in ALL]) for m_ in ['brier', 'ece', 'rate_err', 'auroc', 'auroc_emerg', 'main']} for nm in VMETH for c_ in ('', '|cal')}).T, f'{tag} risk prediction ({w_})', f'{tag}_risk_{w_}')
    XI = [R for R in ALL if not R['integ'].get('skip')]
    if XI: show(pd.DataFrame({q: {k_: mci([R['integ']['res'][q].get(k_, float('nan')) for R in XI]) for k_ in ['cross', 'rsub', 'none', 'size', 'lens_auroc_case', 'lens_auroc_pair', 'margin_reliable', 'margin_unreliable']} for q in ['tvo_cp', 'ta_or', 'rand_cp']}).T, f'{tag} integration (models {len(XI)})', f'{tag}_integ')
    V = judge(verdict_rows(RD, D, metric, c6_margin)); df = pd.DataFrame([{k_: v for k_, v in o.items() if k_ != 'd'} for o in V]); show(df, f'{tag} pre-registered verdicts', f'{tag}_verdict')
    return V

# ===================================================================================================
# ↓↓↓ data_grid.py ↓↓↓
# ===================================================================================================
# ===================================================================================================
# data_grid.py — loading Shapes3D (P1) · MPI3D-real (P2) · factor-order checks
# ===================================================================================================
class _Img:
    """uint8 (N, H, W, 3) array (in memory or memmap) → img(index) = torch uint8 (B, 3, H, W). Reads in sorted order and restores the original order"""
    def __init__(s, a): s.a = a
    def __call__(s, idx):
        idx = np.atleast_1d(np.asarray(idx, dtype=np.int64)); o = np.argsort(idx, kind='stable'); x = np.empty((len(idx),) + s.a.shape[1:], np.uint8); x[o] = s.a[idx[o]]
        return torch.from_numpy(x).permute(0, 3, 1, 2)

def load_shapes3d(paths, url, sig):
    """Shapes3D (Burgess & Kim 2018): 480,000 images 64×64, factors [floor hue 10, wall hue 10, object hue 10, scale 8, shape 4, orientation 15] (C-order index).
       label = shape, shortcut = floor hue (bins {2s, 2s+1} ↔ shape s; 8 · 9 are bound to no shape)"""
    import h5py
    p = next((p for p in paths if os.path.exists(p)), None) or _download([url], paths[0], 'Shapes3D (about 255MB)')
    t0 = time.time(); f = h5py.File(p, 'r'); a = f['images'][:]; lab = f['labels'][:]; f.close()
    FACT = ['floor_hue', 'wall_hue', 'object_hue', 'scale', 'shape', 'orientation']; NV = [10, 10, 10, 8, 4, 15]
    Fi = np.stack([np.searchsorted(np.unique(lab[:, j]), lab[:, j]) for j in range(6)], 1)
    D = GridData('shapes3d', FACT, NV, 4, 0, _Img(a), sig, lambda c: [2*int(c), 2*int(c) + 1])
    assert a.shape == (480000, 64, 64, 3) and [len(np.unique(lab[:, j])) for j in range(6)] == NV, '⚠ number of factor values differs from the documentation'
    assert (D.idx_of(Fi) == np.arange(len(a))).all(), '⚠ storage order differs from the index formula'
    print(f'  Shapes3D {len(a)}images ({time.time()-t0:.0f}s), index-formula check passed', flush=True)
    ch = {'bottom': D.corner_change(bottom=True), 'whole': D.region_change()}
    print('  factor-order check (mean pixel change) bottom corner 8×8 ' + ' '.join(f'{k_} {v:.1f}' for k_, v in ch['bottom'].items()) + ' · whole image ' + ' '.join(f'{k_} {v:.1f}' for k_, v in ch['whole'].items()), flush=True)
    ob = max(v for k_, v in ch['bottom'].items() if k_ != 'floor_hue')
    soft_check(ch['bottom']['floor_hue'] > 3*ob, 'factor-order check ① (only floor hue should change the bottom corner)')
    soft_check(ch['whole']['wall_hue'] > 1.5*ch['whole']['object_hue'] and ch['whole']['wall_hue'] > 2*ch['whole']['shape'], 'factor-order check failed ② (wall hue should change a larger area than object hue and shape)')
    return D, ch

def load_mpi3d(paths, npy, urls):
    """MPI3D-real (Gondal+2019): 1,036,800 images 64×64, factors [object color 6, shape 6, size 2, camera height 3, background color 3, horizontal 40, vertical 40] (C-order index).
       label = shape, shortcut = object color (shape i ↔ color i; Wiles+2022)"""
    if not os.path.exists(npy):
        p = next((p for p in paths if os.path.exists(p)), None) or _download(urls, paths[-1], 'MPI3D-real (about 12.5GB)'); t0 = time.time()
        with zipfile.ZipFile(p) as z, z.open('images.npy') as fi, open(npy + '.part', 'wb') as fo: shutil.copyfileobj(fi, fo, 64 << 20)
        os.replace(npy + '.part', npy); print(f'  extracting images.npy {time.time()-t0:.0f}s', flush=True)
    FACT = ['object_color', 'object_shape', 'object_size', 'camera_height', 'background_color', 'horizontal_axis', 'vertical_axis']; NV = [6, 6, 2, 3, 3, 40, 40]
    a = np.load(npy, mmap_mode='r'); assert a.shape == (int(np.prod(NV)), 64, 64, 3) and a.dtype == np.uint8, a.shape
    try: import psutil; free_ = psutil.virtual_memory().available
    except Exception: free_ = 0
    if free_ > 2.2*a.nbytes: t0 = time.time(); a = np.ascontiguousarray(a); print(f'  MPI3D-real loaded into memory ({a.nbytes/1e9:.1f}GB, {time.time()-t0:.0f}s)', flush=True)
    D = GridData('mpi3d', FACT, NV, 1, 0, _Img(a), 0.0, lambda c: [int(c)]); return D, mpi3d_check(D)

def mpi3d_check(D, n=300):
    """factor-order check (stop condition; version matched to values observed in the real data). Corner change in the real MPI3D-real (2026-11-10 Colab): object color 1.0 · shape 1.1 · size 1.2 · camera height 5.4 · background 0.9 · horizontal 0.9 · vertical 0.8
       ① only camera height moves the whole frame → corner change more than 2× the maximum of the other factors
       ② only object color changes color → median change of mean image chromaticity (r − g, g − b; divided by brightness) more than 3× that of the shape factor"""
    ch = D.corner_change(n); r = np.random.default_rng(1); b = D.idx_of(np.stack([r.integers(0, v, n) for v in D.NV], 1))
    def chroma(x):
        x = x.float() + 1.0; s_ = x.sum(1); return torch.stack([(x[:, 0] - x[:, 1])/s_, (x[:, 1] - x[:, 2])/s_], 1).mean((2, 3))
    c0 = chroma(D.img(b)); cc = {D.FACT[j]: float((chroma(D.img(D.cf_index(b, j, r))) - c0).norm(dim=1).median()) for j in range(len(D.FACT))}
    print('  factor-order check · corner ' + ' '.join(f'{k_} {v:.2f}' for k_, v in ch.items()) + ' · mean chromaticity change ' + ' '.join(f'{k_} {v:.4f}' for k_, v in cc.items()), flush=True)
    oth = max(v for k_, v in ch.items() if k_ != 'camera_height')
    soft_check(ch['camera_height'] > 2*oth, f'factor-order check failed ① (camera height {ch["camera_height"]:.2f} vs other maximum {oth:.2f})')
    soft_check(cc['object_color'] > 3*cc['object_shape'], f'factor-order check failed ② (object color {cc["object_color"]:.4f} vs shape {cc["object_shape"]:.4f})')
    return {'corner': ch, 'chroma': cc}

# ===================================================================================================
# ↓↓↓ p4.py ↓↓↓
# ===================================================================================================
# ===================================================================================================
# p4.py — natural images (CIFAR-10 · Imagenette): factor = corruption type. Per-model experiments
#   S1 misclassification diagnosis (F1 ★ cross restoration) · S2 robustness (F2 Max-Sens) · S7 compound-corruption risk (F3 ★) · S5 number of axes · S6 seed stability · downstream randomization (Adebayo+2018)
# ===================================================================================================
import copy
from scipy.stats import spearmanr
CORR = {'gaussian_noise': [0.04, 0.06, 0.08, 0.09, 0.10], 'shot_noise': [500, 250, 100, 75, 50], 'defocus_blur': [(0.3, 0.4), (0.4, 0.5), (0.5, 0.6), (1, 0.2), (1.5, 0.1)],
        'contrast': [0.75, 0.5, 0.4, 0.3, 0.15], 'jpeg_compression': [80, 65, 58, 50, 40], 'pixelate': [0.95, 0.9, 0.85, 0.75, 0.65]}   # Hendrycks & Dietterich 2019 (CIFAR severities)
INET_IDX = [0, 217, 482, 491, 497, 566, 569, 571, 574, 701]          # ImageNet indices of the 10 Imagenette classes (sorted by wnid)
VIT_PREP = ((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))                          # timm augreg version

def to_u8(x): return (x*255).round().clamp(0, 255).to(torch.uint8)
@torch.no_grad()
def corrupt(X, name, sev, seed=0):
    """uint8 (B, 3, H, W) → corrupted uint8. Same seed gives the same noise realization"""
    x = X.float()/255; c = CORR[name][sev - 1]; g = torch.Generator(device=X.device).manual_seed(int(seed))
    if name == 'gaussian_noise': x = x + c*torch.randn(x.shape, device=X.device, generator=g)
    elif name == 'shot_noise': x = torch.poisson(x*c, generator=g)/c
    elif name == 'contrast': m_ = x.mean((1, 2, 3), keepdim=True); x = (x - m_)*c + m_
    elif name == 'defocus_blur':
        r_, a_ = c; L_ = torch.arange(-8, 9, device=X.device).float(); yy, xx = torch.meshgrid(L_, L_, indexing='ij'); dk = ((xx**2 + yy**2) <= r_**2).float(); dk = dk/dk.sum()
        gk = torch.exp(-torch.arange(-1, 2, device=X.device).float()**2/(2*a_**2)); gk = gk/gk.sum(); dk = F.conv2d(F.conv2d(dk[None, None], gk.view(1, 1, 1, 3), padding=(0, 1)), gk.view(1, 1, 3, 1), padding=(1, 0))[0, 0]
        x = F.conv2d(F.pad(x, (8, 8, 8, 8), mode='reflect'), dk.expand(3, 1, 17, 17).contiguous(), groups=3)
    elif name == 'pixelate': S_ = x.shape[-1]; s_ = int(S_*c); x = F.interpolate(F.interpolate(x, size=s_, mode='area'), size=S_, mode='nearest')
    elif name == 'jpeg_compression':
        from PIL import Image
        out = []
        for im in (x.clamp(0, 1)*255).round().byte().permute(0, 2, 3, 1).cpu().numpy():
            b = io.BytesIO(); Image.fromarray(im).save(b, 'JPEG', quality=c); out.append(np.asarray(Image.open(b)))
        return torch.tensor(np.stack(out), device=X.device).permute(0, 3, 1, 2).contiguous()
    return to_u8(x.clamp(0, 1))

def pgd(A, X, y, eps, steps):
    """L∞ PGD (Madry+2018), input [0,1], step 2.5ε/steps, untargeted (away from the original prediction) → float image not quantized to uint8"""
    out = []
    for i in range(0, len(X), A.bs):
        x0 = X[i:i+A.bs].float()/255; xa = x0.clone(); yy = torch.as_tensor(y[i:i+A.bs], device=dev)
        for _ in range(steps):
            xa.requires_grad_(True)
            with torch.enable_grad(): g, = torch.autograd.grad(F.cross_entropy(A.frm(A.to(xa, 0), 0), yy), xa)
            xa = (x0 + (xa.detach() + 2.5*eps/steps*g.sign() - x0).clamp(-eps, eps)).clamp(0, 1)
        out.append(xa.detach())
    return torch.cat(out)

def input_maps(A, x, a, b, kind, steps=32):
    """input attribution (n, H·W, summed over channels): grad×input (a) · contrastive grad×input (a − b) · IG (Sundararajan+2017; zero baseline, steps along the path, a − b)"""
    x = x.float()/255 if x.dtype == torch.uint8 else x.float(); n = len(x); a = torch.as_tensor(np.asarray(a), device=dev); b = torch.as_tensor(np.asarray(b), device=dev); ar = torch.arange(n, device=dev)
    def grad(xx, contrast):
        xx = xx.clone().requires_grad_(True)
        with torch.enable_grad(): z = A.frm(A.to(xx, 0), 0); g, = torch.autograd.grad((z[ar, a] - (z[ar, b] if contrast else 0)).sum(), xx)
        return g
    if kind == 'grad×input': at = grad(x, False)*x
    elif kind == 'contrast grad×input': at = grad(x, True)*x
    else: at = sum(grad(x*(t + .5)/steps, True) for t in range(steps))/steps*x
    return at.sum(1).flatten(1).double().cpu().numpy()

def spearman_rows(M1, M2): return np.array([spearmanr(u, v).correlation for u, v in zip(M1, M2)], float)

# ---------------------------------------------------------------- data · models
class NatData:
    """XP (probe, held out from the training split) · XT (training) · Xte (test): uint8 (N, 3, H, W) dev"""
    def __init__(s, name, xtr, ytr, xte, yte, n_probe, split_seed=12345):
        perm = torch.randperm(len(xtr), generator=torch.Generator().manual_seed(split_seed)).numpy(); n_probe = min(n_probe, len(xtr))   # same split rule as the previously trained models (stage1 · 2)
        s.P_IDX, s.T_IDX = perm[:n_probe], perm[n_probe:]; s.name = name
        T = lambda a: torch.tensor(a).permute(0, 3, 1, 2).contiguous().to(dev)
        s.XP, s.yP = T(xtr[s.P_IDX]), ytr[s.P_IDX]; s.XT, s.yT = T(xtr[s.T_IDX]), ytr[s.T_IDX]; s.Xte, s.yte = T(xte), np.asarray(yte); s.NCLS = int(ytr.max()) + 1
        s.PAIRS = list(itertools.combinations(range(s.NCLS), 2))

def load_cifar10(npz, root='/content/data'):
    if os.path.exists(npz): d = np.load(npz); return d['xtr'], d['ytr'], d['xte'], d['yte']
    tr_, te_ = torchvision.datasets.CIFAR10(root, train=True, download=True), torchvision.datasets.CIFAR10(root, train=False, download=True)
    out = (tr_.data, np.array(tr_.targets, np.int64), te_.data, np.array(te_.targets, np.int64))
    try: os.makedirs(os.path.dirname(npz), exist_ok=True); np.savez(npz, xtr=out[0], ytr=out[1], xte=out[2], yte=out[3])
    except Exception as e: print('  cache saving skipped:', e)
    return out

def load_imagenette(npz, url='https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-160.tgz'):
    """imagenette2-160: short side 160 → center 160. Training (probe) · validation (test)"""
    if os.path.exists(npz): d = np.load(npz); return d['xtr'], d['ytr'], d['xte'], d['yte']
    from PIL import Image
    tgz = _download([url], '/content/imagenette2-160.tgz', 'Imagenette')
    with tarfile.open(tgz) as t: t.extractall('/content')
    root = '/content/imagenette2-160'; wn = sorted(d for d in os.listdir(f'{root}/train') if d.startswith('n') and os.path.isdir(f'{root}/train/{d}')); out = []; assert len(wn) == 10, wn
    for sp in ['train', 'val']:
        X, Y = [], []
        for ci, w in enumerate(wn):
            for fn in sorted(x for x in os.listdir(f'{root}/{sp}/{w}') if not x.startswith('.') and x.lower().endswith(('.jpeg', '.jpg', '.png'))):
                im = Image.open(f'{root}/{sp}/{w}/{fn}').convert('RGB'); s = 160/min(im.size); im = im.resize((max(160, round(im.size[0]*s)), max(160, round(im.size[1]*s))), Image.BILINEAR)
                L_, T_ = (im.size[0] - 160)//2, (im.size[1] - 160)//2; X.append(np.asarray(im.crop((L_, T_, L_ + 160, T_ + 160)), np.uint8)); Y.append(ci)
        out += [np.stack(X), np.array(Y, np.int64)]
    try: np.savez(npz, xtr=out[0], ytr=out[1], xte=out[2], yte=out[3])
    except Exception as e: print('  cache saving skipped:', e)
    return out

def crop_flip(x, g):
    """CIFAR augmentation: 4-pixel reflect padding + random 32 crop + horizontal flip"""
    B = x.shape[0]; xp = F.pad(x, (4, 4, 4, 4), mode='reflect'); i = torch.randint(0, 9, (B,), device=x.device, generator=g); j = torch.randint(0, 9, (B,), device=x.device, generator=g); ar = torch.arange(32, device=x.device)
    out = xp[torch.arange(B, device=x.device)[:, None, None, None], torch.arange(3, device=x.device)[None, :, None, None], (i[:, None] + ar)[:, None, :, None], (j[:, None] + ar)[:, None, None, :]]
    return torch.where((torch.rand(B, device=x.device, generator=g) < 0.5)[:, None, None, None], out.flip(3), out)

def train_rn18_cifar(ND, seed, C):
    """SGD .1 (Nesterov, momentum .9, wd 5e-4), batch 256, OneCycle 30 epochs, crop + flip (probe images excluded)"""
    torch.manual_seed(seed); m = ResNet18(10).to(dev).to(memory_format=torch.channels_last); A = RN18Arch(m, make_prep(*PREP_CIFAR))
    opt = torch.optim.SGD(m.parameters(), lr=0.1, momentum=0.9, nesterov=True, weight_decay=5e-4); X, Y = ND.XT, torch.tensor(ND.yT, device=dev); BS = 256; nb = math.ceil(len(X)/BS)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=0.1, total_steps=C['RN_EPOCHS']*nb, pct_start=0.15); g = torch.Generator(device=dev).manual_seed(seed)
    for ep in range(C['RN_EPOCHS']):
        m.train(); p = torch.randperm(len(X), device=dev, generator=g)
        for i in range(0, len(X), BS):
            b = p[i:i+BS]; xb = crop_flip(X[b].float()/255, g).contiguous(memory_format=torch.channels_last)
            with torch.autocast('cuda', dtype=torch.bfloat16, enabled=(dev == 'cuda')): loss = F.cross_entropy(A.frm(A.to(xb, 0), 0), Y[b])
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step(); sched.step()
    return m.eval().to(memory_format=torch.contiguous_format)

def train_vit_cifar(ND, seed, C):
    """fine-tuning timm ViT-S/16 (ImageNet-21k → 1k pretrained): 224 upsampling, AdamW 1e-4, wd .05, batch 128, 3 epochs, flip + crop"""
    import timm
    torch.manual_seed(seed); m = timm.create_model(C['VIT_NAME'], pretrained=True, num_classes=10).to(dev); A = ViTArch(m, make_prep(*VIT_PREP), bs=64, size=224)
    opt = torch.optim.AdamW(m.parameters(), lr=C['VIT_LR'], weight_decay=0.05); X, Y = ND.XT, torch.tensor(ND.yT, device=dev); BS = 128; nb = math.ceil(len(X)/BS)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=C['VIT_LR'], total_steps=C['VIT_EPOCHS']*nb, pct_start=0.1); g = torch.Generator(device=dev).manual_seed(seed)
    for ep in range(C['VIT_EPOCHS']):
        m.train(); p = torch.randperm(len(X), device=dev, generator=g)
        for i in range(0, len(X), BS):
            b = p[i:i+BS]; xb = crop_flip(X[b].float()/255, g)
            with torch.autocast('cuda', dtype=torch.bfloat16, enabled=(dev == 'cuda')): loss = F.cross_entropy(A.frm(A.to(xb, 0), 0), Y[b])
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step(); sched.step()
    return m.eval()

def get_p4_model(kind, seed, ND, C, mdir):
    """kind: rn18 (CIFAR-10, from scratch) · vit (CIFAR-10 fine-tuned) · inet (torchvision ResNet-50 ImageNet-pretrained, logits of the 10 Imagenette classes only)"""
    if kind == 'inet':
        m = torchvision.models.resnet50(weights=torchvision.models.ResNet50_Weights.IMAGENET1K_V2); fc = nn.Linear(2048, 10)
        with torch.no_grad(): fc.weight.copy_(m.fc.weight[INET_IDX]); fc.bias.copy_(m.fc.bias[INET_IDX])
        m.fc = fc; return RN50Arch(m.to(dev).eval().requires_grad_(False), make_prep(*PREP_IMNET), bs=64)
    os.makedirs(mdir, exist_ok=True); old = C.get('OLD', {}).get(kind, [])                                   # look for previously trained models first
    fn = next((f_ for f_ in [f'{d_}/{fmt.format(seed=seed)}' for d_, fmt in old] if os.path.exists(f_)), f'{mdir}/{kind}_s{seed}.pt'); print('  model', fn, '(exists)' if os.path.exists(fn) else '(newly trained)', flush=True)
    if kind == 'rn18':
        m = ResNet18(10).to(dev)
        if os.path.exists(fn): m.load_state_dict(torch.load(fn, map_location=dev))
        else: t0 = time.time(); m = train_rn18_cifar(ND, seed, C); torch.save(m.state_dict(), fn); print(f'  ResNet-18 seed {seed} training {(time.time()-t0)/60:.1f}min', flush=True)
        return RN18Arch(m.eval().requires_grad_(False), make_prep(*PREP_CIFAR), bs=250)
    import timm
    m = timm.create_model(C['VIT_NAME'], pretrained=False, num_classes=10).to(dev)
    if os.path.exists(fn): m.load_state_dict(torch.load(fn, map_location=dev))
    else: t0 = time.time(); m = train_vit_cifar(ND, seed, C); torch.save(m.state_dict(), fn); print(f'  ViT-S/16 seed {seed} fine-tuning {(time.time()-t0)/60:.1f}min', flush=True)
    return ViTArch(m.eval().requires_grad_(False), make_prep(*VIT_PREP), bs=64, size=224)

# ---------------------------------------------------------------- pair fit (four groups from the same pair samples)
def p4_sets(A, l, ND, seed):
    yp = predict(A, ND.XP); AXS, S2, Si2, POOL = axes_all(A, l, ND.XP, yp, ND.PAIRS, seed)
    FPS, mu = fit_pairs(A, l, ND.XP, yp, AXS, POOL, seed, methods=('tvo_cp', 'ta_or', 'rand_cp'))
    F4, _ = fit_pairs(A, l, ND.XP, yp, AXS, POOL, seed, methods=('tvo_cp',), k=4); FPS['tvo4'] = F4['tvo_cp']
    return FPS, AXS, S2, Si2, POOL, yp, mu

# ---------------------------------------------------------------- S1 misclassification diagnosis
def diag(A, l, ND, FPS, seed, C):
    """instances where corrupting a correctly classified clean test image (6 corruptions × severities · PGD) changes the decision u → v. First DIAG_PER instances per condition; all methods use the same instances (only instances with pairs in all four groups).
       ★ cross restoration: found without the original (8 probe donors of u) 'why v and not u' set only the axes of its minimal cause C to the values of the original image → full prediction = u.
       (reported) restoration without original = revert with the same donors · original-based = find with the original and revert to the original. Controls: TA 16 · random 16 · tv-O 4 · same-size random subsets within tv-O 16"""
    te = np.random.default_rng(1300 + seed).choice(len(ND.Xte), min(C['DIAG_N'][A.name], len(ND.Xte)), replace=False); Xc = ND.Xte[torch.tensor(te, device=dev)]; pc = predict(A, Xc)
    ok = pc == ND.yte[te]; Xc, pc = Xc[torch.tensor(ok, device=dev)], pc[ok]; CASES = {}
    for nm in CORR:
        for sev in C['DIAG_SEV']: CASES[f'{nm}@{sev}'] = ('natural', corrupt(Xc, nm, sev, seed))
    for eps in C['ADV_EPS']: CASES[f'pgd@{eps*255:.0f}'] = (f'adv{eps*255:.0f}', pgd(A, Xc, pc, eps, C['ADV_STEPS']))
    rec = {}; rr = np.random.default_rng(5300 + seed)
    for key, (kind, xt) in CASES.items():
        lt = logits(A, xt); pt = lt.argmax(1); fi = np.where(pt != pc)[0][:C['DIAG_PER']]
        if len(fi) == 0: continue
        ti_ = torch.tensor(fi, device=dev); Ht, Hc = hidden(A, xt[ti_], l), hidden(A, Xc[ti_], l); a_, b_ = pc[fi], pt[fi]; l2 = lt[fi].copy(); l2[np.arange(len(fi)), b_] = -1e9; c_ = l2.argmax(1); R_ = rec.setdefault(kind, [])
        for u, v in sorted(set(zip(a_.tolist(), b_.tolist()))):
            pms = {q: FPS[q].get(tuple(sorted((u, v)))) for q in FPS}
            if any(p is None for p in pms.values()): continue
            idx = np.where((a_ == u) & (b_ == v))[0]; it = torch.tensor(idx, device=dev); H_, Dc = Ht[it], Hc[it][:, None]; row = {}
            for q, pm in pms.items():
                Cs, cn = minimal_cause(A, l, pm, H_, int(v))
                row[q] = {'cross': restore(A, l, pm, H_, Dc, Cs, u), 'noref': restore(A, l, pm, H_, pm.Hd[int(u)], Cs, u), 'n': cn, 'none': np.array([Cc is None for Cc in Cs])}
                if q == 'tvo_cp':
                    Cr = [sorted(rr.choice(len(pm.U), len(Cc), replace=False).tolist()) if Cc else None for Cc in Cs]; row[q]['rsub'] = restore(A, l, pm, H_, Dc, Cr, u)
                    C2, cn2 = minimal_cause(A, l, pm, H_, int(v), D=Dc); row[q]['ref'] = restore(A, l, pm, H_, Dc, C2, u); row[q]['ref_n'] = cn2
            pt_ = pms['tvo_cp']
            for i in range(len(idx)):
                R_.append({**{f'{q}_{m}': (bool(r[m][i]) if r[m].dtype == bool else int(r[m][i])) for q, r in row.items() for m in r}, 'runner': bool(c_[idx[i]] == u), 'flag': pt_.flag, 'R_s': float(pt_.R_s), 'cond': key})
        del Ht, Hc
    out = {}
    for kind, v in rec.items():
        g = lambda f_: np.array([r[f_] for r in v]); o = {'n': len(v), 'runner_up': float(g('runner').mean())}
        for q in FPS:
            nn_, sz = g(f'{q}_none'), g(f'{q}_n'); o[q] = {'cross': float(g(f'{q}_cross').mean()), 'noref': float(g(f'{q}_noref').mean()), 'size': float(np.median(sz[~nn_])) if (~nn_).any() else float('nan'), 'none': float(nn_.mean())}
        rf = g('tvo_cp_ref'); o['tvo_cp'].update({'rsub': float(g('tvo_cp_rsub').mean()), 'ref': float(rf.mean()), 'ref_size': float(np.median(g('tvo_cp_ref_n')[rf])) if rf.any() else float('nan')})
        fl = np.array([bool(r['flag']) for r in v]); cx = g('tvo_cp_cross'); rs = g('R_s')
        o['lens'] = {'frac_flagged': float(fl.mean()), 'cross_flagged': float(cx[fl].mean()) if fl.any() else float('nan'), 'cross_unflagged': float(cx[~fl].mean()) if (~fl).any() else float('nan'),
                     'auroc_Rs_cross': float(roc_auc_score(cx.astype(int), rs)) if 0 < cx.sum() < len(cx) and np.isfinite(rs).all() else float('nan')}
        out[kind] = o
    print('  S1 cross restoration (tv-O16 / TA16 / random16 / tv-O4 / same-size random): ' + ' · '.join(
        f'{k_} n={o["n"]} {o["tvo_cp"]["cross"]:.2f}/{o["ta_or"]["cross"]:.2f}/{o["rand_cp"]["cross"]:.2f}/{o["tvo4"]["cross"]:.2f}/{o["tvo_cp"]["rsub"]:.2f}' for k_, o in out.items()), flush=True)
    torch.cuda.empty_cache(); return out

# ---------------------------------------------------------------- S2 robustness
def robust(A, l, ND, FP, seed, C):
    """small random perturbations (uniform ±r/255, ROB_S draws): map Max-Sensitivity (Yeh+2019) = max ||m' − m|| / ||m||, Jaccard of minimal causes. Same image · same perturbation · same pair (top-1 vs runner-up)"""
    Lt = logits(A, ND.Xte); top2 = np.argsort(-Lt, 1)[:, :2]; idx = np.random.default_rng(2100 + seed).choice(len(ND.Xte), C['ROB_N'][A.name], replace=False); out = {}
    def jac(s_, t_):
        if s_ is None or t_ is None: return float(s_ is None and t_ is None)
        return 1.0 if not s_ and not t_ else len(set(s_) & set(t_))/max(1, len(set(s_) | set(t_)))
    for r in C['ROB_R']:
        sens = {}
        for i in idx:
            a, b = int(top2[i, 0]), int(top2[i, 1]); pm = FP.get(tuple(sorted((a, b))))
            if pm is None: continue
            x0 = ND.Xte[i:i+1].float()/255; xs = (x0 + (torch.rand((C['ROB_S'],) + x0.shape[1:], device=dev, generator=torch.Generator(device=dev).manual_seed(int(i)))*2 - 1)*r).clamp(0, 1); xx = torch.cat([x0, xs])
            H = hidden(A, xx, l); Cs, _ = minimal_cause(A, l, pm, H, a); M = cause_map(A, pm, H, a, Cs)
            sens.setdefault('ours', []).append(float(np.max(np.linalg.norm(M[1:] - M[0], axis=1))/(np.linalg.norm(M[0]) + 1e-12))); sens.setdefault('cause_jaccard', []).append(float(np.mean([jac(Cs[0], c_) for c_ in Cs[1:]])))
            for q in ['grad×input', 'contrast grad×input', 'IG']:
                Mq = input_maps(A, xx, [a]*len(xx), [b]*len(xx), q); sens.setdefault(q, []).append(float(np.max(np.linalg.norm(Mq[1:] - Mq[0], axis=1))/(np.linalg.norm(Mq[0]) + 1e-12)))
        out[f'{r*255:.0f}'] = {q: {'median': float(np.median(v)), 'mean': float(np.mean(v))} for q, v in sens.items()}
    print('  S2 robustness (median Max-Sens): ' + ' | '.join(f'r={r_} ' + ' '.join(f'{q} {v["median"]:.2f}' for q, v in d.items()) for r_, d in out.items()), flush=True)
    return out

# ---------------------------------------------------------------- S7 compound-corruption risk (no. 4)
def risk_corr(A, l, ND, AXS, seed, C, methods):
    """factors = 6 corruptions (severity RISK_SEV). Partial test = one corruption on RISK_N clean test images. Combination = c2(c1(x)) (noise realizations of c1 · c2 same as for single corruptions). Combined images only for checking against ground truth"""
    head = lambda h: A.frm(h, l).float(); CF = list(CORR); sev = C['RISK_SEV']; N = C['RISK_N']
    r = np.random.default_rng(9900 + seed); base = np.sort(r.choice(len(ND.Xte), N, replace=False)); Xb = ND.Xte[torch.tensor(base, device=dev)]
    Xc = {c: corrupt(Xb, c, sev, 9910 + 7*j + seed) for j, c in enumerate(CF)}
    def part(c):
        for i in range(0, N, A.bs): yield A.to(Xb[i:i+A.bs], l).float(), A.to(Xc[c][i:i+A.bs], l).float()
    def comb(j1, j2):
        X12 = corrupt(Xc[CF[j1]], CF[j2], sev, 9910 + 7*j2 + seed)
        for i in range(0, N, A.bs): yield tuple(A.to(x[i:i+A.bs], l).float() for x in (Xb, Xc[CF[j1]], Xc[CF[j2]], X12))
    T0 = time.time(); out = risk_eval(head, AXS, methods, [(c, part(c)) for c in CF], [(f'{CF[a]}+{CF[b]}', comb(a, b)) for a, b in itertools.combinations(range(len(CF)), 2)], ND.NCLS)
    out['time'] = time.time() - T0; print(f'  S7 compound-corruption Brier: ' + ' · '.join(f'{nm.split("|")[0]} {out[nm]["brier"]:.4f}' for nm in methods), flush=True); return out

# ---------------------------------------------------------------- S5 number of axes
def ksweep(A, l, ND, AXS, POOL, seed, C):
    """k = KS: sufficiency of swapping all k axes (by the source decision) · e/T (share of the contrast-logit change), lens R_s, minimal-cause size, fraction with no cause within the k axes. Test pairs = per pair NB_MC bases (decided as a) · sources (b)"""
    yt = predict(A, ND.Xte); rng = np.random.default_rng(6600 + seed); out = {str(k): {} for k in C['KS']}
    yp = predict(A, ND.XP)
    for k in C['KS']:
        FP, _ = fit_pairs(A, l, ND.XP, yp, AXS, POOL, seed, methods=('tvo_cp',), k=k); FP = FP['tvo_cp']
        for (a, b), pm in FP.items():
            ia, ib = np.where(yt == a)[0], np.where(yt == b)[0]; m = min(C['NB_MC'], len(ia), len(ib))
            if m == 0: continue
            pb = np.concatenate([rng.choice(ia, m), rng.choice(ib, m)]); ps = np.concatenate([rng.choice(ib, m), rng.choice(ia, m)]); tsrc, ybas = yt[ps], yt[pb]
            Hb, Hs = hidden(A, ND.Xte[torch.tensor(pb, device=dev)], l), hidden(A, ND.Xte[torch.tensor(ps, device=dev)], l)
            with torch.no_grad(): L0, L1 = A.frm(Hb, l).float().cpu().numpy(), A.frm(Hs, l).float().cpu().numpy()
            LU = donor_logits(A, l, Hb, Hs[:, None], pm.rd, pm.wr, np.ones((1, k), np.float32))[:, 0].cpu().numpy(); ar = np.arange(len(pb)); c = lambda L_: L_[ar, tsrc] - L_[ar, ybas]
            cn = []
            for ac in (a, b):
                sel = np.where(ybas == ac)[0]; st = torch.tensor(sel, device=dev); cn += list(minimal_cause(A, l, pm, Hb[st], int(ac), D=Hs[st][:, None])[1])
            cn = np.array(cn); out[str(k)][f'{a}-{b}'] = {'suf': float((LU.argmax(1) == tsrc).mean()), 'eT': float((c(LU) - c(L0)).mean()/((c(L1) - c(L0)).mean() + 1e-12)), 'R_s': pm.R_s,
                                                          'size': float(np.median(cn[cn <= k])) if (cn <= k).any() else float('nan'), 'none': float((cn > k).mean())}
    for k in C['KS']:
        v = out[str(k)]
        if v: print(f'  S5 k={k}: ' + ' '.join(f'{f_} {np.nanmean([x[f_] for x in v.values()]):.3f}' for f_ in ['suf', 'eT', 'R_s', 'size', 'none']), flush=True)
    return out

# ---------------------------------------------------------------- S6 seed stability · downstream randomization
def maps_on(A, l, FP, X, pa, pb):
    """per image 'why pa and not pb' final-model map (per-position contribution of the minimal-cause axes; nan without a pair)"""
    H = hidden(A, X, l); M = None
    for key in set(tuple(sorted((int(u), int(v)))) for u, v in zip(pa, pb)):
        pm = FP.get(key)
        if pm is None: continue
        for ac in key:
            sel = np.where((np.minimum(pa, pb) == key[0]) & (np.maximum(pa, pb) == key[1]) & (pa == ac))[0]
            if len(sel) == 0: continue
            st = torch.tensor(sel, device=dev); Cs, _ = minimal_cause(A, l, pm, H[st], int(ac)); mp = cause_map(A, pm, H[st], int(ac), Cs)
            if M is None: M = np.full((len(X), mp.shape[1]), np.nan)
            M[sel] = mp
    return M if M is not None else np.full((len(X), 1), np.nan)

def stability(kind, seeds, ND, C, mdir):
    """rank correlation of maps of models with different seeds on the same image · same pair (true class vs runner-up of the first-seed model). Controls grad×input · IG"""
    idx = np.sort(np.random.default_rng(77).choice(len(ND.Xte), C['STAB_N'], replace=False)); X = ND.Xte[torch.tensor(idx, device=dev)]; y = ND.yte[idx]; MAPS = {}; pb = None
    for s in seeds:
        A = get_p4_model(kind, s, ND, C, mdir); l = explain_layer(A); L = logits(A, X)
        if pb is None: L2 = L.copy(); L2[np.arange(len(y)), y] = -1e9; pb = L2.argmax(1)
        FPS, _, _, _, _, _, _ = p4_sets(A, l, ND, s); MAPS[s] = {'ours': maps_on(A, l, FPS['tvo_cp'], X, y, pb), 'ok': L[np.arange(len(y)), y] > L[np.arange(len(y)), pb]}
        for q in ['grad×input', 'IG']: MAPS[s][q] = np.concatenate([input_maps(A, X[i:i+50], y[i:i+50], pb[i:i+50], q) for i in range(0, len(X), 50)])
        del A, FPS; torch.cuda.empty_cache()
    R = {}
    for q in ['ours', 'grad×input', 'IG']:
        v = []
        for i_, s1 in enumerate(seeds):
            for s2 in seeds[i_ + 1:]:
                ok = MAPS[s1]['ok'] & MAPS[s2]['ok'] & np.isfinite(MAPS[s1]['ours']).all(1) & np.isfinite(MAPS[s2]['ours']).all(1); v.append(float(np.nanmean(spearman_rows(MAPS[s1][q][ok], MAPS[s2][q][ok]))))
        R[q] = v
    print(f'  S6 [{kind}] map rank correlation across seeds: ' + ' '.join(f'{q} {np.mean(v):.3f}' for q, v in R.items()), flush=True); return R

def sanity(kind, seed, ND, C, mdir):
    """downstream randomization (Adebayo+2018): |rank correlation| of maps for the same image · same pair on a model with all layers after the explanation layer randomized (lower = more dependent on the learned computation).
       for our method, axes and pair fits are redone on the random model (probe groups by the decisions of the original model). Controls grad×input · IG"""
    A = get_p4_model(kind, seed, ND, C, mdir); l = explain_layer(A); m2 = copy.deepcopy(A.m)
    mods = (list(m2.stages[l:]) + [m2.fc]) if kind == 'rn18' else (list(m2.blocks[l:]) + [m2.norm, m2.head])
    for mod in mods:
        for sm in mod.modules():
            if hasattr(sm, 'reset_parameters'): sm.reset_parameters()
    A2 = type(A)(m2.eval().requires_grad_(False), A.prep, A.bs, **({'size': A.size} if kind == 'vit' else {}))
    idx = np.sort(np.random.default_rng(78 + seed).choice(len(ND.Xte), C['STAB_N'], replace=False)); X = ND.Xte[torch.tensor(idx, device=dev)]; L = logits(A, X); t2 = np.argsort(-L, 1)[:, :2]; pa, pb = t2[:, 0], t2[:, 1]
    PS = [p for i_, p in enumerate(ND.PAIRS) if i_ % 3 == 0]; keep = np.array([tuple(sorted((int(u), int(v)))) in PS for u, v in zip(pa, pb)]); X, pa, pb = X[torch.tensor(np.where(keep)[0], device=dev)], pa[keep], pb[keep]
    yp0 = predict(A, ND.XP); MP = {}
    for nm, B in [('orig', A), ('rand', A2)]:
        AX, _, _, PO = axes_all(B, l, ND.XP, yp0, PS, seed); FP, _ = fit_pairs(B, l, ND.XP, yp0, AX, PO, seed)
        MP[nm] = {'ours': maps_on(B, l, FP['tvo_cp'], X, pa, pb), **{q: np.concatenate([input_maps(B, X[i:i+50], pa[i:i+50], pb[i:i+50], q) for i in range(0, len(X), 50)]) for q in ['grad×input', 'IG']}}
    R = {'n': int(keep.sum())}
    for q in ['ours', 'grad×input', 'IG']:
        ok = np.isfinite(MP['orig'][q]).all(1) & np.isfinite(MP['rand'][q]).all(1); R[q] = float(np.nanmean(np.abs(spearman_rows(np.abs(MP['orig'][q][ok]), np.abs(MP['rand'][q][ok])))))
    print(f'  S6 [{kind} seed {seed}] |rank correlation| after downstream randomization: ' + ' '.join(f'{q} {R[q]:.3f}' for q in ['ours', 'grad×input', 'IG']), flush=True)
    del A, A2, m2; torch.cuda.empty_cache(); return R

def run_p4_model(kind, seed, ND, C, mdir):
    T0 = time.time(); A = get_p4_model(kind, seed, ND, C, mdir); l = explain_layer(A); arch_check(A, ND.Xte[:4]); R = {'kind': kind, 'seed': seed, 'acc': float((predict(A, ND.Xte) == ND.yte).mean())}
    FPS, AXS, S2, Si2, POOL, yp, mu = p4_sets(A, l, ND, seed); R['lens'] = {q: {'R_s_med': float(np.nanmedian([p.R_s for p in F_.values()])), 'flag': float(np.mean([bool(p.flag) for p in F_.values()]))} for q, F_ in FPS.items()}
    print(f'  [{kind} seed {seed}] test accuracy {R["acc"]:.4f} · pairs {len(AXS)}', flush=True)
    R['diag'] = diag(A, l, ND, FPS, seed, C); R['robust'] = robust(A, l, ND, FPS['tvo_cp'], seed, C)
    R['risk'] = risk_corr(A, l, ND, AXS, seed, C, ['tvo_cp|16', 'ta_or|16', 'cpta_cp|16', 'pca_or|16', 'rand_cp|16', 'full|0'])
    if seed in C['K_SEEDS'].get(kind, []): R['k'] = ksweep(A, l, ND, AXS, POOL, seed, C)
    R['time'] = time.time() - T0; del A, FPS, AXS; torch.cuda.empty_cache(); return R

def p4_verdict(RS):
    """F1 ★ (family S1) · F2 (S2) · F3 ★ · F3 (S7). RS = list of model results"""
    rows = []; nat = [R for R in RS if 'natural' in R['diag']]; dg = lambda R, q, k_='cross': R['diag']['natural'][q][k_] if q != 'rsub' else R['diag']['natural']['tvo_cp']['rsub']
    for b_, nm_ in [('ta_or', 'TA 16'), ('rand_cp', 'random 16'), ('rsub', 'same-size random subset')]:
        rows.append(dict(no='F1 ★', desc=f'cross restoration (natural corruptions): final model > {nm_}', fam='S1', d=[dg(R, 'tvo_cp') - dg(R, b_) for R in nat], thr=0.0, kind='diff'))
    rows.append(dict(no='F1b', desc='(reported) cross restoration: 16 axes − 4 axes', fam='reported', d=[dg(R, 'tvo_cp') - dg(R, 'tvo4') for R in nat], thr=0.0, kind='report'))
    rb = lambda R, r_, q: R['robust'].get(r_, {}).get(q, {}).get('median', float('nan'))                     # nan if the pair does not exist (excluded from verdicts)
    for r_ in ['2', '8']: rows.append(dict(no='F2', desc=f'Max-Sens r={r_}/255: final model < grad×input', fam='S2', d=[rb(R, r_, 'grad×input') - rb(R, r_, 'ours') for R in RS], thr=0.0, kind='diff'))
    for r_ in ['2', '8']: rows.append(dict(no='F2b', desc=f'(reported) Max-Sens r={r_}/255: IG − final model', fam='reported', d=[rb(R, r_, 'IG') - rb(R, r_, 'ours') for R in RS], thr=0.0, kind='report'))
    rk = lambda R, nm, m_: R['risk'][nm][m_]
    for b_ in ['ta_or|16', 'cpta_cp|16', 'pca_or|16']: rows.append(dict(no='F3 ★', desc=f'compound-corruption Brier: tv-O < {b_}', fam='S7', d=[rk(R, b_, 'brier') - rk(R, 'tvo_cp|16', 'brier') for R in RS], thr=0.0, kind='diff'))
    for m_, nm_ in [('rate_err', 'rate error'), ('ece', 'ECE')]:
        for b_ in ['ta_or|16', 'cpta_cp|16']: rows.append(dict(no='F3', desc=f'compound corruption {nm_}: tv-O < {b_}', fam='S7', d=[rk(R, b_, m_) - rk(R, 'tvo_cp|16', m_) for R in RS], thr=0.0, kind='diff'))
    for b_ in ['ta_or|16', 'cpta_cp|16']: rows.append(dict(no='F3', desc=f'tv-O (uncalibrated) Brier ≤ {b_} (slope-calibrated) + .002', fam='S7', d=[rk(R, b_ + '|cal', 'brier') - rk(R, 'tvo_cp|16', 'brier') + 0.002 for R in RS], thr=0.0, kind='diff'))
    rows.append(dict(no='F3b', desc='(reported) AUROC: tv-O − PCA', fam='reported', d=[rk(R, 'tvo_cp|16', 'auroc') - rk(R, 'pca_or|16', 'auroc') for R in RS], thr=0.0, kind='report'))
    for adv in ['adv2', 'adv8']:
        A_ = [R for R in RS if adv in R['diag']]
        rows.append(dict(no='F1c', desc=f'(reported) {adv} cross restoration: final model − TA 16', fam='reported', d=[R['diag'][adv]['tvo_cp']['cross'] - R['diag'][adv]['ta_or']['cross'] for R in A_], thr=0.0, kind='report'))
    return judge(rows)

# ===================================================================================================
# ↓↓↓ c2_defs.py ↓↓↓
# ===================================================================================================
# ==== C2 definitions (verbatim from run_C2.py) ====
# ===================================================================================================
# confirmatory C2 (main study of the paper): tv-O axes + spatial-rule scoring model (guided search + attentional spotlight) — reproduces the network decisions and explains where it looks at what
#   method (fixed in S5p; the networks in this notebook were not used in the pilots):
#     axes = class-global tv-O (eigenvectors of Σ_pos^½ M Σ_pos^½, M = Σ_c E Σ_u g_c g_cᵀ, g_c = ∂(z_c − mean z)/∂h), k axes, codes z_x at every position (token)
#     score = guided search (Wolfe 1994) + attentional spotlight (Eriksen & St. James 1986): priority p_x,c = λ_x − |x − c_c|²/(2 s_c²) + Σ_j Π_jc |z_xj| → a_x,c = softmax_x (p · τ) → score_c = Σ_x a_x,c (z_x · B_c) + b_c
#     fitting: probe (images held out from the training split) · labels = network predictions · cross-entropy + L2 — same as the pilots
#   controls (same network · same layer · same probe · same optimization)
#     scoring models: mean (position mean + weighted sum = original method) · whatwhere2 (class-specific fixed spatial map × feature weights = form of Kumar+2025 SF · Klindt+2017) · poslin (fully linear over positions × axes = position-wise linear ceiling) · tvaf_where (auxiliary rule)
#     axis dictionaries: PRCA (Chormai+) · LRP-SVD (LRP-0 relevance, original method) · PCA · NMF (CRAFT-style, CNNs only) · SAE (ReLU + L1, k atoms)
#     maps: Grad-CAM (same layer) · IG (Sundararajan+2017, zero baseline, 32 steps) · grad×input
#   standard evaluation · sanity checks
#     fidelity (top-1 agreement) · probability EMD (Kumar+2025, = ½ Σ|p_net − p_surrogate|) · interventional fidelity (agreement with the new network decision after swapping k/2 axes; MIB causal-variable format) · real-counterfactual fidelity (Shapes3D: real images with one factor changed)
#     axis ceiling (network decision on hidden states keeping only k axes) · deletion / insertion AUC (Petsiuk+2018) · downstream randomization (Adebayo+2018) · Max-Sensitivity (Yeh+2019)
#   applications
#     A1 shortcut audit (Shapes3D, networks with different shortcut strength ρ): rank correlation across networks between the share an explanation places on the floor region and the true floor-hue reliance (flips on true counterfactuals changing only floor hue) · Kelley factor decomposition (ResNet)
#     A2 pre-deployment risk prediction (CIFAR-10 corruptions): predict the flip probability of two-corruption combinations from single-corruption tests (Thurstone + Anderson, core.risk_eval) — axis-free control noisy-OR (Cheng 1997) added
#   groups · verdicts: C-RN (CIFAR ResNet-18 seeds 3–12) · S-RN (Shapes3D 11d ρ .25 · .75 · .9 × seeds 2–4) · S-ViT (13V 18) use core.judge (① ≥⌈5/6·n⌉ + mean difference > threshold, ② Wilcoxon + Holm);
#     C-ViT (stage2 ViT 3) · I-RN (Imagenette, 6 torchvision ImageNet ResNets) reported only. Criteria fixed before seeing results (claude/C1-design.md (run as C2))
#   v2 (rigor audit, before results): same number of steps for all scoring models · L2 strength λ chosen identically for all rules · dictionaries on a probe validation split · H0 (vs original method LRP-SVD + position mean, dictionary-independent region-swap intervention)
#     · component ablations (guidance only · spotlight only) · last-layer Grad-CAM · TopK SAE (4k overcomplete) · ViT CLS-mean ceiling · H4b as separate family · A1 primary analysis fixed (S-all × Grad-CAM at two layers · IG)
#   v3 (external review, before results): verdict ② = one-sided Wilcoxon on d − thr (non-inferiority: one-sided on d with the margin added) + bootstrap 95% CI of the mean difference · parameter-matched non-spatial control (mlp_pool)
#     · intervention dose-response (swapped axis fraction ¼ · ½ · ¾) · distribution shift of interventions (whitened distance) · A1 stratified analysis (ranks within architecture × ρ) · zero-denominator handling of floor share · convergence · eigenvalue gap · model provenance record
#   v4: saving example maps (8 test images per network · all maps) + paper figures (maps by method · shortcut maps by ρ · A1 scatter)
#     · FunnyBirds (Hesse+2023, official checkpoints · official 6 metrics): ours (tv-O + main rule) · original method (LRP-SVD + position mean) · IG · Grad-CAM · Input×Gradient (reported)
# ===================================================================================================
K_MAIN, K_ALL = 16, [8, 16]; PC = dict(N_FIT=2000, STEPS=1200, LR=0.05, N_USE=10000, SAE_STEPS=3000, N_MAP=300, DEL_STEPS=16, N_STAB=100, STAB_R=2/255, STAB_S=5,
                                        N_CFT=1000, N_D=2000, TOT=24, SANITY_PER=3, RISK_SEV=3, RISK_N=500, BOOT=2000, LAMS=[1.0, 0.3, 3.0], VAL=0.2)
PCG = {'I-RN': dict(N_USE=4000, N_FIT=1000)}; PC0 = dict(PC)                                                     # per-group overrides (Imagenette: only sample sizes reduced because hidden states are large)
RULES = ['mean', 'gs_spot', 'guided', 'spotlight', 'tvaf_where', 'whatwhere2', 'poslin', 'mlp_pool']; MAIN = 'gs_spot'   # guided · spotlight = component ablations · spotlight = input-independent attention · mlp_pool = parameter-matched non-spatial control (reported)
DOSE = [0.25, 0.5, 0.75]                                                                                         # intervention dose-response: fraction of axes swapped (½ = H2)
INETS = [('resnet18', 'IMAGENET1K_V1'), ('resnet34', 'IMAGENET1K_V1'), ('resnet50', 'IMAGENET1K_V1'), ('resnet50', 'IMAGENET1K_V2'), ('resnet101', 'IMAGENET1K_V1'), ('resnet152', 'IMAGENET1K_V1')]

# ---------------------------------------------------------------- position units (ViT: patch tokens only, CLS excluded; writes to patch tokens only)
def is_tok(A): return A.name in ('vit', 'fb_vit')                                                              # token layout (CLS is index 0)
def sp(A, h): u = A.units(h); return u[:, 1:] if is_tok(A) else u
def sp_back(A, u, h, cls=None):
    if not is_tok(A): return A.from_units(u, h)
    full = A.units(h).clone(); full[:, 1:] = u
    if cls is not None: full[:, 0] = cls                                                                            # CLS set to the probe mean (prevents information leakage in the ViT ceiling)
    return A.from_units(full, h)
def grid_hw(A, H): return tuple(H.shape[2:]) if not is_tok(A) else (int(round(math.sqrt(H.shape[1] - 1))),)*2

# ---------------------------------------------------------------- dictionaries (enc · write delta · reconstruction recon)
class Lin:
    def __init__(s, R, W, mu): s.R, s.W, s.mu = (torch.tensor(np.asarray(x), device=dev, dtype=torch.float32) for x in (R, W, mu))
    def enc(s, u): return (u - s.mu) @ s.R.T
    def delta(s, dc): return dc @ s.W
    def recon(s, c): return s.mu + c @ s.W
class NNeg:
    def __init__(s, D): s.D = torch.tensor(D, device=dev, dtype=torch.float32); s.G = s.D @ s.D.T; s.L = float(torch.linalg.eigvalsh(s.G).max()); s.Pi = torch.linalg.pinv(s.G)
    def enc(s, u):
        c = torch.clamp(u @ s.D.T @ s.Pi, min=0)
        for _ in range(200): c = torch.clamp(c - ((c @ s.D - u) @ s.D.T)/s.L, min=0)
        return c
    def delta(s, dc): return dc @ s.D
    def recon(s, c): return c @ s.D
class SAETopK:
    """TopK SAE (Gao+2024): K active out of m atoms, decoder rows normalized"""
    def __init__(s, X, m, K, seed, mu):
        torch.manual_seed(seed); C = X.shape[1]; s.K = K; s.Wd = torch.randn(m, C, device=dev); s.Wd = s.Wd/s.Wd.norm(dim=1, keepdim=True); s.Wd = nn.Parameter(s.Wd)
        s.We = nn.Parameter(s.Wd.detach().clone()); s.be = nn.Parameter(torch.zeros(m, device=dev)); s.bd = nn.Parameter(torch.tensor(mu, device=dev, dtype=torch.float32))
        opt = torch.optim.Adam([s.We, s.be, s.Wd, s.bd], 1e-3); g = torch.Generator(device=dev).manual_seed(seed)
        for _ in range(PC['SAE_STEPS']):
            b = X[torch.randint(0, len(X), (1024,), device=dev, generator=g)]
            with torch.enable_grad(): loss = ((s.enc(b) @ s.Wd + s.bd - b)**2).sum(1).mean()
            opt.zero_grad(); loss.backward(); opt.step()
            with torch.no_grad(): s.Wd.div_(s.Wd.norm(dim=1, keepdim=True) + 1e-12)
        for p_ in (s.We, s.be, s.Wd, s.bd): p_.requires_grad_(False)
    def enc(s, u):
        pre = (u - s.bd) @ s.We.T + s.be; v, i = pre.topk(s.K, -1); return torch.zeros_like(pre).scatter(-1, i, F.relu(v))
    def delta(s, dc): return dc @ s.Wd
    def recon(s, c): return c @ s.Wd + s.bd
class SAE:
    def __init__(s, X, m, l1, seed, mu):
        torch.manual_seed(seed); C = X.shape[1]; s.We = nn.Parameter(torch.randn(m, C, device=dev)*0.1); s.be = nn.Parameter(torch.zeros(m, device=dev)); s.Wd = nn.Parameter(s.We.detach().clone())
        s.bd = nn.Parameter(torch.tensor(mu, device=dev, dtype=torch.float32)); opt = torch.optim.Adam([s.We, s.be, s.Wd, s.bd], 1e-3); g = torch.Generator(device=dev).manual_seed(seed)
        for _ in range(PC['SAE_STEPS']):
            b = X[torch.randint(0, len(X), (1024,), device=dev, generator=g)]
            with torch.enable_grad(): c = F.relu((b - s.bd) @ s.We.T + s.be); loss = ((c @ s.Wd + s.bd - b)**2).sum(1).mean() + l1*(c.abs()*s.Wd.norm(dim=1)).sum(1).mean()
            opt.zero_grad(); loss.backward(); opt.step()
        for p_ in (s.We, s.be, s.Wd, s.bd): p_.requires_grad_(False)
    def enc(s, u): return F.relu((u - s.bd) @ s.We.T + s.be)
    def delta(s, dc): return dc @ s.Wd
    def recon(s, c): return c @ s.Wd + s.bd

def ucov(X): F_ = X.reshape(-1, X.shape[-1]); return F_.T @ F_
def dict_stats(A, l, HP, seed, ncls):
    r = np.random.default_rng(100 + seed); ii = torch.tensor(np.sort(r.choice(len(HP), min(PC['N_FIT'], len(HP)), replace=False)), device=dev); Hf = HP[ii].float()
    U = sp(A, Hf).double(); C = U.shape[-1]; mu = U.reshape(-1, C).mean(0); Uc = U - mu; S = ucov(Uc - Uc.mean(0, keepdim=True))/(U.shape[0]*U.shape[1])
    def gr(fn_):
        out = []
        for i in range(0, len(Hf), A.bs):
            h = Hf[i:i+A.bs].clone().requires_grad_(True)
            with torch.enable_grad(): g, = torch.autograd.grad(fn_(A.frm(h, l)).sum(), h)
            out.append(sp(A, g).double())
        return torch.cat(out)
    M = 0
    for c in range(ncls): M = M + ucov(gr(lambda z: z[:, c] - z.mean(1)))/len(Hf)
    gp = gr(lambda z: z.gather(1, z.argmax(1, keepdim=True))[:, 0]); L2 = ucov(U*gp)/len(Hf); PR = (Uc.reshape(-1, C).T @ gp.reshape(-1, C))/len(Hf); PR = (PR + PR.T)/2
    flat = U.reshape(-1, C).float(); sub = flat[torch.tensor(np.random.default_rng(seed).choice(len(flat), min(20000, len(flat)), replace=False), device=dev)]
    return dict(S=S.cpu().numpy(), M=M.cpu().numpy(), L2=L2.cpu().numpy(), PR=PR.cpu().numpy(), mu=mu.cpu().numpy(), sub=sub)
def dicts(ST, k, seed, conv):
    S2, Si2 = msqrt(ST['S'], 0.5), msqrt(ST['S'], -0.5); q = top_eig(S2 @ ST['M'] @ S2)[:k]; mu = ST['mu']; out = {'tvo': Lin(q @ Si2, q @ S2, mu)}
    for nm, Mx in [('prca', ST['PR']), ('lrp_svd', ST['L2']), ('pca', ST['S'])]: V = orth_rows(top_eig(Mx)[:k]); out[nm] = Lin(V, V, mu)
    if conv:
        from sklearn.decomposition import NMF
        out['nmf'] = NNeg(NMF(k, init='nndsvda', max_iter=400, random_state=seed).fit(np.clip(ST['sub'].cpu().numpy(), 0, None)).components_)
    out['sae'] = SAE(ST['sub'], k, 1e-3, seed, mu); out['sae_topk'] = SAETopK(ST['sub'], 4*k, k, seed, mu); return out      # sae = same dimension (verdicts) · sae_topk = 4k overcomplete (reported)

@torch.no_grad()
def codes(A, Dc, H): return torch.cat([Dc.enc(sp(A, H[i:i+500].float())) for i in range(0, len(H), 500)])
@torch.no_grad()
def swap_hidden(A, Dc, H, Hd, k, rng, frac=0.5):
    out = []
    for i in range(0, len(H), 500):
        h, hd = H[i:i+500].float(), Hd[i:i+500].float(); u, ud = sp(A, h), sp(A, hd); m = len(u); cu, cd = Dc.enc(u), Dc.enc(ud); kc = cu.shape[-1]     # kc = code dimension (4k for TopK)
        msk = torch.tensor(np.argsort(np.argsort(rng.random((m, kc)), 1), 1) < max(1, int(round(kc*frac))), device=dev, dtype=torch.float32)
        out.append(sp_back(A, u + Dc.delta((cd - cu)*msk[:, None, :]), h).to(H.dtype))
    return torch.cat(out)
@torch.no_grad()
def maha(A, H, mu, Wt):
    """per-position whitened distance ||(u − μ) Σ^{-½}||² / C (≈ 1 on average for natural hidden states): how far intervened hidden states leave the original distribution"""
    return torch.cat([((sp(A, H[i:i+500].float()) - mu) @ Wt).pow(2).mean(-1).flatten() for i in range(0, len(H), 500)]).cpu().numpy()
@torch.no_grad()
def region_swap(A, H, Hd, hw, rng):
    """dictionary-independent intervention (H0 · reported): for each image, positions in one of the top · bottom · left · right halves are replaced by the donor hidden state — all dictionaries · rules evaluated on the same set of interventions"""
    gy, gx = np.meshgrid(np.arange(hw[0]), np.arange(hw[1]), indexing='ij'); gy, gx = gy.flatten(), gx.flatten()
    HV = torch.tensor(np.stack([gy < hw[0]/2, gy >= hw[0]/2, gx < hw[1]/2, gx >= hw[1]/2]), device=dev, dtype=torch.float32); out = []
    for i in range(0, len(H), 500):
        h, hd = H[i:i+500].float(), Hd[i:i+500].float(); u, ud = sp(A, h), sp(A, hd); sel = HV[torch.tensor(rng.integers(0, 4, len(u)), device=dev)][:, :, None]
        out.append(sp_back(A, u*(1 - sel) + ud*sel, h).to(H.dtype))
    return torch.cat(out)
@torch.no_grad()
def proj_pred(A, l, Dc, C_, H, cls=None): return torch.cat([A.frm(sp_back(A, Dc.recon(C_[i:i+500]), H[i:i+500].float(), cls), l).argmax(1) for i in range(0, len(H), 500)]).cpu().numpy()
@torch.no_grad()
def net_pred(A, l, H): return torch.cat([A.frm(H[i:i+A.bs].float(), l).argmax(1) for i in range(0, len(H), A.bs)]).cpu().numpy()

# ---------------------------------------------------------------- scoring models (same definitions as S4p · S5p) + spatial maps
def P0(*shape, v=0.0): return nn.Parameter(torch.full(shape, float(v), device=dev))
class Scorer(nn.Module):
    def __init__(s, rule, Cp, hw, ncls, seed):
        super().__init__(); torch.manual_seed(seed); s.rule, s.hw = rule, hw; n, U, k = Cp.shape; C = ncls; sd_ = Cp.reshape(-1, k).std(0); s.register_buffer('sd', torch.clamp(sd_, min=1e-4*float(sd_.max()) + 1e-12))   # so that axes with near-zero variance are not inflated by standardization
        yy, xx = torch.meshgrid(torch.linspace(-1, 1, hw[0], device=dev), torch.linspace(-1, 1, hw[1], device=dev), indexing='ij'); s.register_buffer('pos', torch.stack([yy.flatten(), xx.flatten()], 1))
        s.b = P0(C); s.W = []
        if rule in ('mean', 'gs_spot', 'guided', 'spotlight', 'tvaf_where'): s.B = P0(k, C); s.W.append(s.B)
        s.has_g, s.has_s = rule in ('gs_spot', 'guided'), rule in ('gs_spot', 'spotlight')                          # guidance (feature priority) · spotlight (spatial priority) components
        if s.has_g or s.has_s: s.lt = P0(1); s.lam = P0(U)
        if s.has_g: s.Pi = P0(k, C); s.W.append(s.Pi)
        if s.has_s: s.cen = P0(C, 2); s.lw = P0(C, v=math.log(2.0))
        if rule == 'tvaf_where': s.pi = P0(k, v=-4.0); s.lamc = P0(C, U)
        if rule == 'whatwhere2': s.A = P0(C, 2, U, v=1.0/U); s.Bw = nn.Parameter(torch.randn(C, 2, k, device=dev)*0.01); s.W.append(s.Bw)
        if rule == 'poslin': s.Wp = P0(U, k, C); s.W.append(s.Wp)
        if rule == 'mlp_pool':                                                                                  # hidden-layer MLP after position averaging, parameter count = main rule (control that adds capacity without spatial information)
            m = max(1, round((2*k*C + U + 4*C + 1 - C)/(k + 1 + C))); g_ = torch.Generator(device=dev).manual_seed(seed)
            s.W1 = nn.Parameter(torch.randn(k, m, device=dev, generator=g_)/math.sqrt(k)); s.b1 = P0(m); s.W2 = nn.Parameter(torch.randn(m, C, device=dev, generator=g_)/math.sqrt(m)); s.W += [s.W1, s.W2]
        s.nparam = sum(p.numel() for p in s.parameters())
    def att(s, z):
        p = s.lam[None, :, None].expand(z.shape[0], -1, s.b.shape[0])
        if s.has_g: p = p + z.abs() @ s.Pi
        if s.has_s: p = p - (((s.pos[None] - s.cen[:, None])**2).sum(-1)/(2*torch.exp(s.lw)[:, None]**2)).T[None]
        return torch.softmax(p*torch.exp(s.lt), 1)
    def contrib(s, C_):
        """position × class contributions (n, U, C): score = Σ_x contributions + b"""
        z = C_/s.sd; r = s.rule
        if r == 'mean': return (z @ s.B)/z.shape[1]
        if r in ('gs_spot', 'guided', 'spotlight'): return s.att(z)*(z @ s.B)
        if r == 'tvaf_where':
            w = F.softplus(s.lamc + 2.0)[None]*(1 + (z.abs()*F.softplus(s.pi)).sum(-1))[:, None, :]; return ((w/w.sum(2, keepdim=True))*(z @ s.B).transpose(1, 2)).transpose(1, 2)
        if r == 'whatwhere2': return torch.einsum('nuk,cru,crk->nuc', z, s.A, s.Bw)
        if r == 'poslin': return torch.einsum('nuk,ukc->nuc', z, s.Wp)
    def forward(s, C_):
        if s.rule == 'mlp_pool': return F.relu((C_/s.sd).mean(1) @ s.W1 + s.b1) @ s.W2 + s.b                     # no spatial decomposition → not used for maps
        return s.contrib(C_).sum(1) + s.b
def fit_scorer(rule, Cp, yp, hw, ncls, seed, lam=1.0):
    """same number of steps (STEPS) for all rules · full-batch Adam · cross-entropy + λ·||W||²/(2n)"""
    sc = Scorer(rule, Cp, hw, ncls, seed); y = torch.tensor(yp, device=dev); n = len(y); opt = torch.optim.Adam(sc.parameters(), PC['LR'] if rule != 'poslin' else 0.01)
    for t in range(PC['STEPS']):
        with torch.enable_grad(): loss = F.cross_entropy(sc(Cp), y) + lam*sum((w**2).sum() for w in sc.W)/(2*n)
        opt.zero_grad(); loss.backward(); opt.step()
        if t == int(PC['STEPS']*0.9) - 1: l90 = float(loss)
    sc.loss = float(loss); sc.conv = (l90 - sc.loss)/max(abs(sc.loss), 1e-12)                                    # convergence: relative decrease of the loss over the last 10% of steps (smaller = more converged)
    return sc.eval()
def tune_lam(rule, Cp, yp, hw, ncls, seed):
    """choose λ ∈ LAMS by agreement on the VAL validation split of the probe set (identical for all rules · dictionaries; ties go to the first in LAMS = 1). Test images are not used"""
    perm = np.random.default_rng(4200 + seed).permutation(len(yp)); nv = int(len(yp)*PC['VAL']); va, tr = perm[:nv], perm[nv:]; tv, vv = torch.tensor(tr, device=dev), torch.tensor(va, device=dev); acc = []
    for lam in PC['LAMS']: sc = fit_scorer(rule, Cp[tv], yp[tr], hw, ncls, seed, lam); acc.append(float((sc_logits(sc, Cp[vv]).argmax(1).cpu().numpy() == yp[va]).mean())); del sc
    return PC['LAMS'][int(np.argmax(acc))]
@torch.no_grad()
def sc_logits(sc, C_): return torch.cat([sc(C_[i:i+2000]) for i in range(0, len(C_), 2000)])
@torch.no_grad()
def sc_map(sc, C_, c):
    """per-position contribution map of the predicted class c (n, U)"""
    return torch.cat([sc.contrib(C_[i:i+500])[torch.arange(len(C_[i:i+500]), device=dev), :, torch.as_tensor(c[i:i+500], device=dev)] for i in range(0, len(C_), 500)])

# ---------------------------------------------------------------- input · layer maps (controls)
def gradcam_map(A, l, H, c):
    """Grad-CAM (Selvaraju+2017) at the explanation layer: ReLU(Σ_ch (mean gradient) · activation)"""
    out = []
    for i in range(0, len(H), A.bs):
        h = H[i:i+A.bs].float().clone().requires_grad_(True); cc = torch.as_tensor(c[i:i+A.bs], device=dev)
        with torch.enable_grad(): z = A.frm(h, l); g, = torch.autograd.grad(z[torch.arange(len(h), device=dev), cc].sum(), h)
        u, gu = sp(A, h.detach()), sp(A, g); out.append(F.relu((u*gu.mean(1, keepdim=True)).sum(-1)))
    return torch.cat(out)
def input_map(A, X, c, kind, steps=32):
    """IG (zero baseline) · grad×input — input resolution (n, H, W), summed over channels"""
    out = []
    for i in range(0, len(X), 50):
        x = X[i:i+50].float()/255 if X.dtype == torch.uint8 else X[i:i+50].float(); cc = torch.as_tensor(c[i:i+50], device=dev); ar = torch.arange(len(x), device=dev)
        def g_(xx):
            xx = xx.clone().requires_grad_(True)
            with torch.enable_grad(): z = A.frm(A.to(xx, 0), 0); gg, = torch.autograd.grad(z[ar, cc].sum(), xx)
            return gg
        at = g_(x)*x if kind == 'gxi' else sum(g_(x*(t + .5)/steps) for t in range(steps))/steps*x
        out.append(at.sum(1))
    return torch.cat(out)
def cam_last(A): return A.last - 1 if A.name == 'vit' else A.last        # standard Grad-CAM layer: last stage output for CNNs · input of the last block for ViTs (token pooling uses CLS, so patch gradients at the last block output are 0)
def up(m, hw_in): return F.interpolate(m[:, None].float(), size=hw_in, mode='bilinear', align_corners=False)[:, 0]
def grid_to_img(A, m, H, hw_in): return up(m.reshape(len(m), *grid_hw(A, H)), hw_in)

@torch.no_grad()
def del_ins(A, X, c, M, fill, steps):
    """deletion · insertion AUC (Petsiuk+2018): pixels in descending map order go from the fill value → original (insertion) / original → fill value (deletion); mean of the class-c probability curve of the network"""
    x = X.float()/255 if X.dtype == torch.uint8 else X.float(); n, Ch, Hh, Ww = x.shape; order = torch.argsort(M.reshape(n, -1), 1, descending=True); cc = torch.as_tensor(c, device=dev); ar = torch.arange(n, device=dev)
    fl = fill.view(1, Ch, 1, 1).expand_as(x); dl, ins = [], []
    for t in range(steps + 1):
        m = torch.zeros(n, Hh*Ww, device=dev); kk = int(round(t/steps*Hh*Ww))
        if kk: m.scatter_(1, order[:, :kk], 1.0)
        m = m.view(n, 1, Hh, Ww); xd = x*(1 - m) + fl*m; xi = fl*(1 - m) + x*m
        dl.append(F.softmax(A.frm(A.to(xd, 0), 0).float(), 1)[ar, cc]); ins.append(F.softmax(A.frm(A.to(xi, 0), 0).float(), 1)[ar, cc])
    dl, ins = torch.stack(dl, 1), torch.stack(ins, 1); return float(dl.mean()), float(ins.mean())

# ---------------------------------------------------------------- main experiment on one network
def run_main(A, l, XP, XE, seed, conv, extra=None):
    T0 = time.time(); HP, HE = hidden(A, XP, l), hidden(A, XE, l)
    if HP.numel() + HE.numel() > 6e8: HP, HE = HP.half(), HE.half()                                                   # Imagenette: hidden states stored in half precision only (computation in float)
    yp, ye = predict(A, XP), predict(A, XE); pe_net = F.softmax(torch.tensor(logits(A, XE), device=dev), 1); ncls = pe_net.shape[1]; hw = grid_hw(A, HP)
    ST = dict_stats(A, l, HP, seed, ncls); donor = torch.tensor(np.random.default_rng(700 + seed).permutation(len(HE)), device=dev); R = {'acc_agree_n': len(ye), 'k': {}}; keep = {}; LAM = {}
    cls0 = HP[:, 0].float().mean(0) if A.name == 'vit' else None
    S2, Si2 = msqrt(ST['S'], 0.5), msqrt(ST['S'], -0.5); ev = np.sort(np.linalg.eigvalsh(S2 @ ST['M'] @ S2))[::-1]; R['eig_gap'] = {k_: float(ev[k_ - 1]/max(ev[k_], 1e-30)) for k_ in K_ALL}   # tv-O eigenvalue gap λ_k/λ_k+1
    Wt, mu_t = torch.tensor(Si2, device=dev, dtype=torch.float32), torch.tensor(ST['mu'], device=dev, dtype=torch.float32); dnat = maha(A, HE, mu_t, Wt); q99 = float(np.quantile(dnat, 0.99))
    def ood(Hx): dx = maha(A, Hx, mu_t, Wt); return {'ratio': float(dx.mean()/dnat.mean()), 'out99': float((dx > q99).mean())}   # natural hidden states: ratio 1 · out99 .01
    Hr = region_swap(A, HE, HE[donor], hw, np.random.default_rng(800 + seed)); yr = net_pred(A, l, Hr); chg_r = yr != ye; R['chg_reg'] = float(chg_r.mean())   # intervention shared by all dictionaries · rules
    R['ood'] = {'region': ood(Hr)}; R['dose'] = {}
    for k in sorted(K_ALL, key=lambda k_: k_ != K_MAIN):                                                          # K_MAIN first: λ chosen at K_MAIN and reused for other k
        R['k'][k] = {}
        for dn, Dc in dicts(ST, k, seed, conv).items():
            Cp, Ce, Cr = codes(A, Dc, HP), codes(A, Dc, HE), codes(A, Dc, Hr); Hs = swap_hidden(A, Dc, HE, HE[donor], k, np.random.default_rng(900 + seed + k)); ys = net_pred(A, l, Hs)
            Cs = codes(A, Dc, Hs); chg = ys != ye; o = {'chg': float(chg.mean()), 'proj': {'fid': float((proj_pred(A, l, Dc, Ce, HE) == ye).mean())}}
            if k == K_MAIN: R['ood'][f'axis|{dn}'] = ood(Hs)
            del Hs
            if cls0 is not None: o['proj']['fid_cls0'] = float((proj_pred(A, l, Dc, Ce, HE, cls0) == ye).mean())
            rules = RULES if dn == 'tvo' else ['mean', MAIN]
            for rule in rules:
                if (dn, rule) not in LAM: LAM[(dn, rule)] = tune_lam(rule, Cp, yp, hw, ncls, seed)
                sc = fit_scorer(rule, Cp, yp, hw, ncls, seed, LAM[(dn, rule)]); Le = sc_logits(sc, Ce); pe = Le.argmax(1).cpu().numpy(); ps = sc_logits(sc, Cs).argmax(1).cpu().numpy(); pr = sc_logits(sc, Cr).argmax(1).cpu().numpy()
                o[rule] = {'fid': float((pe == ye).mean()), 'emd': float(0.5*(F.softmax(Le, 1) - pe_net).abs().sum(1).mean()), 'cf': float((ps == ys).mean()),
                           'cf_chg': float((ps[chg] == ys[chg]).mean()) if chg.any() else float('nan'), 'cf_reg': float((pr == yr).mean()),
                           'cf_reg_chg': float((pr[chg_r] == yr[chg_r]).mean()) if chg_r.any() else float('nan'), 'nparam': sc.nparam, 'lam': LAM[(dn, rule)], 'loss': sc.loss, 'conv': sc.conv}
                if extra is not None and 'cf_sets' in extra: o[rule]['rcf'] = extra['rcf_fn'](A, l, Dc, sc)
                if dn == 'tvo' and k == K_MAIN: keep[rule] = sc
            R['k'][k][dn] = o
            if dn == 'tvo' and k == K_MAIN:
                keep['Dc'] = Dc
                for fr in DOSE:                                                                                  # dose-response: network decision change · tracking by scoring models · distribution shift by fraction of swapped axes
                    Hf = swap_hidden(A, Dc, HE, HE[donor], k, np.random.default_rng(950 + seed + int(100*fr)), fr); yf = net_pred(A, l, Hf); Cf = codes(A, Dc, Hf); cg = yf != ye
                    R['dose'][str(fr)] = {'chg': float(cg.mean()), **ood(Hf), **{r_: float((sc_logits(keep[r_], Cf).argmax(1).cpu().numpy() == yf).mean()) for r_ in ['mean', MAIN, 'whatwhere2']},
                                          **{f'{r_}_chg': float((sc_logits(keep[r_], Cf).argmax(1).cpu().numpy()[cg] == yf[cg]).mean()) if cg.any() else float('nan') for r_ in ['mean', MAIN, 'whatwhere2']}}; del Hf, Cf
            del Cp, Ce, Cs, Cr
        print(f'  k={k} ({time.time()-T0:.0f}s) fidelity tv-O: ' + ' '.join(f'{r_} {R["k"][k]["tvo"][r_]["fid"]:.3f}' for r_ in RULES) + ' | dictionaries (guided search+spotlight): ' + ' '.join(f'{d_} {v[MAIN]["fid"]:.3f}' for d_, v in R['k'][k].items())
              + f' | H0 region swap: ours {R["k"][k]["tvo"][MAIN]["cf_reg"]:.3f} original method {R["k"][k]["lrp_svd"]["mean"]["cf_reg"]:.3f} | axis ceiling: ' + ' '.join(f'{d_} {v["proj"]["fid"]:.3f}' for d_, v in R['k'][k].items()), flush=True)
        torch.cuda.empty_cache()
    del Hr
    # maps: used for deletion · insertion · floor share (application A1). Grad-CAM at the same layer (gradcam) + the standard last layer (gradcam_last)
    r_ = np.random.default_rng(1300 + seed); mi = torch.tensor(np.sort(r_.choice(len(XE), PC['N_MAP'], replace=False)), device=dev); Xm, Hm = XE[mi], HE[mi].float(); cm = ye[mi.cpu().numpy()]; hw_in = tuple(Xm.shape[-2:])
    def gcl(A_, Xq, cq): Lc = cam_last(A_); Hq = hidden(A_, Xq, Lc); return grid_to_img(A_, gradcam_map(A_, Lc, Hq, cq), Hq, hw_in)
    Cm = codes(A, keep['Dc'], Hm); MAPS = {'ours': grid_to_img(A, sc_map(keep[MAIN], Cm, cm), Hm, hw_in), 'orig': grid_to_img(A, sc_map(keep['mean'], Cm, cm), Hm, hw_in),
                                          'static': grid_to_img(A, sc_map(keep['whatwhere2'], Cm, cm), Hm, hw_in), 'gradcam': grid_to_img(A, gradcam_map(A, l, Hm, cm), Hm, hw_in),
                                          'gradcam_last': gcl(A, Xm, cm), 'ig': input_map(A, Xm, cm, 'ig'), 'gxi': input_map(A, Xm, cm, 'gxi')}
    xp_ = XP[:2000].float()/255 if XP.dtype == torch.uint8 else XP[:2000].float(); fill = xp_.mean((0, 2, 3))
    R['delins'] = {nm: dict(zip(['del', 'ins'], del_ins(A, Xm, cm, M_, fill, PC['DEL_STEPS']))) for nm, M_ in MAPS.items()}
    for nm in R['delins']: R['delins'][nm]['ins_minus_del'] = R['delins'][nm]['ins'] - R['delins'][nm]['del']
    print('  deletion/insertion (insertion − deletion): ' + ' '.join(f'{nm} {v["ins_minus_del"]:.3f}' for nm, v in R['delins'].items()), flush=True)
    # stability (Max-Sensitivity): STAB_S small input-noise draws, same class
    si = mi[:PC['N_STAB']]; Xs0 = XE[si].float()/255 if XE.dtype == torch.uint8 else XE[si].float(); cs = ye[si.cpu().numpy()]; ms = {'ours': [], 'gradcam': [], 'gradcam_last': [], 'ig': []}
    def maps3(Xq, cq):
        Hq = hidden(A, Xq, l); return {'ours': grid_to_img(A, sc_map(keep[MAIN], codes(A, keep['Dc'], Hq), cq), Hq, hw_in), 'gradcam': grid_to_img(A, gradcam_map(A, l, Hq, cq), Hq, hw_in),
                                       'gradcam_last': gcl(A, Xq, cq), 'ig': input_map(A, Xq, cq, 'ig')}
    m0 = maps3(Xs0, cs); g = torch.Generator(device=dev).manual_seed(5 + seed); mx = {nm: torch.zeros(len(si), device=dev) for nm in ms}
    for _ in range(PC['STAB_S']):
        mq = maps3(Xs0 + (torch.rand(Xs0.shape, device=dev, generator=g)*2 - 1)*PC['STAB_R'], cs)
        for nm in ms: mx[nm] = torch.maximum(mx[nm], (mq[nm] - m0[nm]).flatten(1).norm(dim=1)/(m0[nm].flatten(1).norm(dim=1) + 1e-12))
    R['maxsens'] = {nm: float(v.median()) for nm, v in mx.items()}
    R['_maps'] = {'idx': mi.cpu().numpy(), 'cls': cm, 'maps': MAPS, 'Dc': keep['Dc'], 'sc': keep, 'lam': LAM}; R['time'] = time.time() - T0; return R

# ---------------------------------------------------------------- downstream randomization (Adebayo+2018)
def sanity_one(A, l, XP, XE, seed, conv, R0):
    """randomize all layers after the explanation layer → refit dictionaries · scoring models on that network (labels = predictions of the random network) → |rank correlation| of maps for the same images · original predicted classes"""
    from scipy.stats import spearmanr
    m2 = copy.deepcopy(A.m)
    if A.name == 'rn18': mods = list(m2.stages[l:]) + [m2.fc]
    elif A.name == 'rn50': mods = [m2.layer1, m2.layer2, m2.layer3, m2.layer4][l:] + [m2.fc]
    else: mods = list(m2.blocks[l:]) + [m2.norm, m2.head]
    for mod in mods:
        for sm in mod.modules():
            if hasattr(sm, 'reset_parameters'): sm.reset_parameters()
    m2 = m2.eval().requires_grad_(False); A2 = RN18Arch(m2, A.prep, A.bs) if A.name == 'rn18' else RN50Arch(m2, A.prep, A.bs) if A.name == 'rn50' else ViTArch(m2, A.prep, A.bs, size=A.size)
    HP2 = hidden(A2, XP, l); yp2 = predict(A2, XP); ST2 = dict_stats(A2, l, HP2, seed, int(R0['_maps']['sc']['mean'].b.shape[0])); D2 = dicts(ST2, K_MAIN, seed, False)['tvo']
    mi = torch.tensor(R0['_maps']['idx'], device=dev); Xm = XE[mi]; Hm = hidden(A2, Xm, l); cm = R0['_maps']['cls']; hw = grid_hw(A2, HP2); hw_in = tuple(Xm.shape[-2:])
    Cp2 = codes(A2, D2, HP2); out = {}
    for rule, nm in [(MAIN, 'ours'), ('mean', 'orig')]:                                                            # λ = value chosen on the original network
        sc2 = fit_scorer(rule, Cp2, yp2, hw, int(R0['_maps']['sc']['mean'].b.shape[0]), seed, R0['_maps']['lam'][('tvo', rule)]); out[nm] = grid_to_img(A2, sc_map(sc2, codes(A2, D2, Hm), cm), Hm, hw_in)
    out['gradcam'] = grid_to_img(A2, gradcam_map(A2, l, Hm, cm), Hm, hw_in); out['ig'] = input_map(A2, Xm, cm, 'ig')
    Lc = cam_last(A2); HL = hidden(A2, Xm, Lc); out['gradcam_last'] = grid_to_img(A2, gradcam_map(A2, Lc, HL, cm), HL, hw_in)
    res = {}
    for nm, M2 in out.items():
        M1 = R0['_maps']['maps'][nm]; res[nm] = float(np.nanmean([abs(spearmanr(a.flatten().cpu().numpy(), b.flatten().cpu().numpy()).correlation) for a, b in zip(M1, M2)]))
    del A2, m2, HP2; torch.cuda.empty_cache(); return res

# ---------------------------------------------------------------- Shapes3D: true counterfactuals · floor region · Kelley factor decomposition (ResNet)
def shapes_cf(A, l, S, seed):
    """per factor, N_CFT test bases + images with only that factor changed (same noise): hidden states · network decisions"""
    D = S.D; rc = np.random.default_rng(9100 + seed); CF = {}
    for j in range(len(D.FACT)):
        base = S.TE_I[rc.choice(len(S.TE_I), PC['N_CFT'], replace=False)]; src = D.cf_index(base, j, rc); sd_ = 6100 + 10*j + seed; Xb, Xs = D.noisy(base, sd_), D.noisy(src, sd_)
        CF[j] = dict(Hb=hidden(A, Xb, l), Hs=hidden(A, Xs, l), pb=predict(A, Xb), ps=predict(A, Xs)); del Xb, Xs
    return CF
def make_rcf(CF):
    def f(A, l, Dc, sc):
        a_, c_ = [], []
        for j, v in CF.items():
            p = sc_logits(sc, codes(A, Dc, v['Hs'])).argmax(1).cpu().numpy(); a_.append(float((p == v['ps']).mean())); ch = v['ps'] != v['pb']
            if ch.sum() >= 10: c_.append(float((p[ch] == v['ps'][ch]).mean()))
        return {'all': float(np.mean(a_)), 'chg': float(np.mean(c_)) if c_ else float('nan')}
    return f
def floor_mask(D, n=300):
    """floor region (ground truth): mean amount of pixel change when only the floor hue changes (normalized to 0–1)"""
    r = np.random.default_rng(0); b = D.idx_of(np.stack([r.integers(0, v, n) for v in D.NV], 1)); d = (D.img(D.cf_index(b, D.J_SC, r)).float() - D.img(b).float()).abs().mean((0, 1))
    return (d/d.max()).to(dev)
def share_in(M, mask):
    """share of the positive evidence of a map inside the mask region (image mean)"""
    P_ = F.relu(M); tot = P_.flatten(1).sum(1); ok = tot > 1e-8*float(tot.max()) + 1e-30                         # images with (almost) no positive evidence are excluded from the mean (pre-registered)
    return float(((P_*mask[None]).flatten(1).sum(1)[ok]/tot[ok]).mean()) if ok.any() else float('nan')

def kelley_c1(A, l, S, ST, HP, HE, yp, ye, CF, seed):
    """same definition as S5p (factor-specific subspaces, label-factor denominator = mean of nuisance factors) × scoring models (mean · main rule). Control: post hoc assignment of global tv-O axes of the same dimension
       attribution accuracy = on counterfactuals changing only factor g 'change of the predicted-class score when each factor-group code is set to its counterfactual value' share of g in
       factor reliance index (application A1) = share of that factor in the score change when the factor-group codes of a test image are set to those of another test image"""
    D = S.D; NF = len(D.FACT); hw = grid_hw(A, HP); S2, Si2 = msqrt(ST['S'], 0.5), msqrt(ST['S'], -0.5); mu = ST['mu']; m = PC['TOT']//NF
    DG = kelley_diag(A, l, S, seed, dict(N_D=PC['N_D'])); SD = DG['SD']; Cn = np.mean([SD[f] for f in D.NUIS], 0); rows, gid = [], []
    for f in range(NF):
        _, W = spec_dirs(SD[f], Cn if f == D.J_LABEL else SD[D.J_LABEL], S2, Si2, 'w'); rows.append(W[:, :m].T @ Si2); gid += [f]*m
    q = top_eig(S2 @ ST['M'] @ S2)[:PC['TOT']]; Rt = q @ Si2; var = np.stack([np.einsum('kc,cd,kd->k', Rt, SD[f], Rt) for f in range(NF)], 1)
    GR = {'kelley': (np.concatenate(rows), np.array(gid)), 'assign_tvo': (Rt, var.argmax(1))}; out = {}; donor = torch.tensor(np.random.default_rng(77 + seed).permutation(len(HE)), device=dev)
    for gn, (Rr, gidv) in GR.items():
        Dc = Lin(Rr, Rr, mu); Cp, Ce = codes(A, Dc, HP), codes(A, Dc, HE); ar = torch.arange(len(Ce), device=dev); ce_ = torch.tensor(ye, device=dev)
        for rule in ['mean', MAIN]:
            lam = tune_lam(rule, Cp, yp, hw, D.NCLS, seed); sc = fit_scorer(rule, Cp, yp, hw, D.NCLS, seed, lam); o = {'fid': float((sc_logits(sc, Ce).argmax(1).cpu().numpy() == ye).mean()), 'lam': lam}; att = []
            for j in range(NF):
                Cb, Cs_ = codes(A, Dc, CF[j]['Hb']), codes(A, Dc, CF[j]['Hs']); s0 = sc_logits(sc, Cb); a2 = torch.arange(len(Cb), device=dev); c_ = torch.tensor(CF[j]['pb'], device=dev); Dg = []
                for g in range(NF):
                    Cm = Cb.clone(); sel = torch.tensor(gidv == g, device=dev)
                    if sel.any(): Cm[:, :, sel] = Cs_[:, :, sel]
                    Dg.append((sc_logits(sc, Cm)[a2, c_] - s0[a2, c_]).abs().cpu().numpy())
                Dg = np.stack(Dg, 1); att.append(float((Dg[:, j]/(Dg.sum(1) + 1e-12)).mean()))
            s0 = sc_logits(sc, Ce); Dg = []
            for g in range(NF):
                Cm = Ce.clone(); sel = torch.tensor(gidv == g, device=dev)
                if sel.any(): Cm[:, :, sel] = Ce[donor][:, :, sel]
                Dg.append((sc_logits(sc, Cm)[ar, ce_] - s0[ar, ce_]).abs().mean().item())
            Dg = np.array(Dg); o.update({'attr': float(np.mean(att)), 'reliance': {D.FACT[g]: float(Dg[g]/(Dg.sum() + 1e-12)) for g in range(NF)}}); out[f'{gn}|{rule}'] = o
        del Cp, Ce
    print('  Kelley: ' + ' · '.join(f'{key} fidelity {v["fid"]:.3f} attribution {v["attr"]:.3f} floor reliance {v["reliance"][D.FACT[D.J_SC]]:.3f}' for key, v in out.items()), flush=True); return out

# ---------------------------------------------------------------- CIFAR: pre-deployment risk prediction (A2)
def risk_c1(A, l, ND, seed, C):
    """p4.risk_corr (Thurstone + Anderson, axes: tv-O · TA · CP-TA · PCA · random · full hidden state) + axis-free control noisy-OR (Cheng 1997): per instance 1 − (1 − f1)(1 − f2) · rates 1 − (1 − r1)(1 − r2)"""
    yp = predict(A, ND.XP); AXS, _, _, _ = axes_all(A, l, ND.XP, yp, ND.PAIRS, seed); out = risk_corr(A, l, ND, AXS, seed, C, ['tvo_cp|16', 'ta_or|16', 'cpta_cp|16', 'pca_or|16', 'rand_cp|16', 'full|0'])
    CFn = list(CORR); sev, N = C['RISK_SEV'], C['RISK_N']; r = np.random.default_rng(9900 + seed); base = np.sort(r.choice(len(ND.Xte), N, replace=False)); Xb = ND.Xte[torch.tensor(base, device=dev)]
    Xc = {c: corrupt(Xb, c, sev, 9910 + 7*j + seed) for j, c in enumerate(CFn)}; p0 = predict(A, Xb); P1 = {c: predict(A, Xc[c]) for c in CFn}; bi, br, bo = [], [], []
    for j1, j2 in itertools.combinations(range(len(CFn)), 2):
        c1, c2 = CFn[j1], CFn[j2]; p12 = predict(A, corrupt(Xc[c1], c2, sev, 9910 + 7*j2 + seed)); fl = (p12 != p0).astype(float); f1, f2 = (P1[c1] != p0).astype(float), (P1[c2] != p0).astype(float)
        bi.append(float(np.mean((1 - (1 - f1)*(1 - f2) - fl)**2))); br.append(float(np.mean((1 - (1 - f1.mean())*(1 - f2.mean()) - fl)**2)))
        bo.append(float(np.mean((fl.mean() - fl)**2)))
    out['noisyor_case'] = {'brier': float(np.mean(bi))}; out['noisyor_rate'] = {'brier': float(np.mean(br))}; out['oracle_rate'] = {'brier': float(np.mean(bo))}   # reference: actual flip rate per combination (uses ground truth, not a control)
    print(f'  A2 risk Brier: tv-O {out["tvo_cp|16"]["brier"]:.4f} · TA {out["ta_or|16"]["brier"]:.4f} · CP-TA {out["cpta_cp|16"]["brier"]:.4f} · PCA {out["pca_or|16"]["brier"]:.4f} · noisy-OR per instance {out["noisyor_case"]["brier"]:.4f} / rates {out["noisyor_rate"]["brier"]:.4f}', flush=True)
    return out


# ===================================================================================================
# ↓↓↓ c2_jobs.py ↓↓↓
# ===================================================================================================
# ==== C2 network list · data · model loading (verbatim from run_C2.py) ====
# ---------------------------------------------------------------- run (resumes network by network)
CC = dict(RN_EPOCHS=30, VIT_EPOCHS=3, VIT_LR=1e-4, VIT_NAME='vit_small_patch16_224.augreg_in21k_ft_in1k', RISK_SEV=PC['RISK_SEV'], RISK_N=PC['RISK_N'],
          OLD={'rn18': [(f'{D_}/{d_}', 'resnet18_s{seed}.pt') for d_ in ['xai_stage1', 'xai_stage8', 'xai_stage7c', 'xai_stage7', 'xai_stage2', 'xai_P4/models']], 'vit': [(f'{D_}/xai_stage2', 'vit_s{seed}.pt'), (f'{D_}/xai_stage8', 'vit_s{seed}.pt')]})
JOBS = ([('C-RN', 0.0, s) for s in range(3, 13)] + [('C-ViT', 0.0, s) for s in range(3)] + [('S-RN', r_, s) for r_ in [0.25, 0.75, 0.9] for s in [2, 3, 4]]
        + [('S-ViT', r_, s) for r_ in [0.0, 0.25, 0.5, 0.75, 0.9, 0.97] for s in [2, 3, 4]] + [('I-RN', 0.0, i) for i in range(len(INETS))])
mdir = f'{OUT}/models'; os.makedirs(mdir, exist_ok=True); RES = {}; SAN = {}; CACHE = {}
def data_of(grp):
    key = grp[0]
    if key in CACHE: return CACHE[key]
    if key == 'C': CACHE[key] = NatData('cifar10', *load_cifar10(f'{DATA}/c10.npz'), n_probe=10000)                       # same split as stage1 (torch randperm 12345)
    elif key == 'I': CACHE[key] = NatData('imagenette', *load_imagenette(f'{DATA}/imagenette160.npz'), n_probe=PCG['I-RN']['N_USE'])   # probe = Imagenette training images · test = validation images (ImageNet val)
    else:
        D, _ = load_shapes3d([f'{DATA}/3dshapes.h5', '/content/3dshapes.h5'], 'https://storage.googleapis.com/3d-shapes/3dshapes.h5', 2.0)
        S = Split(D, dict(SPLIT=2027, NZ=dict(pr=21, te=22, cf=877), N_PROBE=20000, N_TEST=20000)); CACHE[key] = S; CACHE['mask'] = floor_mask(D)                           # same split · noise as 11d · 13V
    return CACHE[key]
def save_examples(fn, X, R, n=8):
    """for paper figures: inputs · predicted classes · maps of all methods for the first n map images (float16)"""
    mm = R['_maps']; ii = torch.tensor(mm['idx'][:n], device=dev); x = X[ii]; x = (x.float()/255 if x.dtype == torch.uint8 else x.float()).cpu().numpy().astype(np.float16)
    np.savez_compressed(fn, x=x, cls=np.asarray(mm['cls'][:n]), **{f'm_{k_}': v[:n].float().cpu().numpy().astype(np.float16) for k_, v in mm['maps'].items()})
def model_src(grp, rho, s):
    """model provenance (path · first 12 digits of md5): records existing and newly trained models separately"""
    if grp == 'I-RN': return {'file': f'torchvision {INETS[s][0]} {INETS[s][1]}'}
    if grp in ('C-RN', 'C-ViT'):
        kind = 'rn18' if grp == 'C-RN' else 'vit'; fn = next((f_ for f_ in [f'{d_}/{fmt.format(seed=s)}' for d_, fmt in CC['OLD'][kind]] if os.path.exists(f_)), f'{mdir}/{kind}_s{s}.pt')
    else: fn = f'{D_}/xai_stage11d/s3d_rho{rho}_s{s}.pt' if grp == 'S-RN' else f'{D_}/xai_stage13/s3dvit_rho{rho}_s{s}.pt'
    return {'file': fn, 'md5': hashlib.md5(open(fn, 'rb').read()).hexdigest()[:12] if os.path.exists(fn) else None}
def model_of(grp, rho, s):
    if grp in ('C-RN', 'C-ViT'): return get_p4_model('rn18' if grp == 'C-RN' else 'vit', s, data_of(grp), CC, mdir)
    if grp == 'I-RN':                                                                                              # torchvision ImageNet weights · logits of the 10 Imagenette classes only (same as p4 inet)
        nm, wv = INETS[s]; Wc = getattr(torchvision.models, {'resnet18': 'ResNet18_Weights', 'resnet34': 'ResNet34_Weights', 'resnet50': 'ResNet50_Weights', 'resnet101': 'ResNet101_Weights', 'resnet152': 'ResNet152_Weights'}[nm])
        m = getattr(torchvision.models, nm)(weights=getattr(Wc, wv)); fc = nn.Linear(m.fc.in_features, 10)
        with torch.no_grad(): fc.weight.copy_(m.fc.weight[INET_IDX]); fc.bias.copy_(m.fc.bias[INET_IDX])
        m.fc = fc; print(f'  I-RN {nm} {wv}', flush=True); return RN50Arch(m.to(dev).eval().requires_grad_(False), make_prep(*PREP_IMNET), bs=64)
    f_ = f'{D_}/xai_stage11d/s3d_rho{rho}_s{s}.pt' if grp == 'S-RN' else f'{D_}/xai_stage13/s3dvit_rho{rho}_s{s}.pt'
    if not os.path.exists(f_): return None
    A = RN18Arch(ResNet18(4).to(dev), make_prep(*PREP_CIFAR), bs=250) if grp == 'S-RN' else ViTArch(make_vit(4, 64, 8, 192, 6, 3).to(dev), make_prep(*PREP_CIFAR), bs=250)
    A.m.load_state_dict(torch.load(f_, map_location=dev)); A.m.eval().requires_grad_(False); return A

from scipy.stats import wilcoxon as _wx
def judge1(rows):
    """C2 verdict (v3): ① d > 0 in ≥⌈5/6·n⌉ networks + mean d > thr · ② one-sided Wilcoxon on d − thr (H: median > 0; for non-inferiority rows the margin is already added to d and thr = 0) + Holm (within family).
       bootstrap 95% CI of mean d (resampling networks) reported as well — for non-inferiority rows, a CI lower bound > 0 means within the margin"""
    out = []; rb = np.random.default_rng(0)
    for r in rows:
        d = np.asarray([x for x in r['d'] if x is not None and np.isfinite(x)], float); n = len(d); need = math.ceil(5*n/6); ds = d - r['thr']
        p = float(_wx(ds, alternative='greater').pvalue) if r['kind'] == 'diff' and n >= 6 and np.any(ds != 0) else float('nan')
        bm = np.array([d[rb.integers(0, n, n)].mean() for _ in range(PC['BOOT'])]) if n >= 2 else np.array([np.nan])
        out.append({**r, 'n': n, 'win': int((d > 0).sum()), 'mean': float(d.mean()) if n else np.nan, 'ci_lo': float(np.nanpercentile(bm, 2.5)), 'ci_hi': float(np.nanpercentile(bm, 97.5)),
                    'p': p, 'pass1': bool(n > 0 and (d > 0).sum() >= need and d.mean() > r['thr'])})
    for fam in {o['fam'] for o in out if o['kind'] == 'diff'}:
        ix = [i for i, o in enumerate(out) if o['fam'] == fam and o['kind'] == 'diff']; adj = holm([out[i]['p'] if np.isfinite(out[i]['p']) else 1.0 for i in ix])
        for i, a in zip(ix, adj): out[i]['p_holm'] = float(a)
    for o in out: o.setdefault('p_holm', np.nan); o['verdict'] = 'reported' if o['kind'] == 'report' else 'confirmed' if o['pass1'] and o['p_holm'] < 0.05 else 'only ① passed' if o['pass1'] else 'not confirmed'
    return out

# ===================================================================================================
# ↓↓↓ run_CHK.py ↓↓↓
# ===================================================================================================
# ===================================================================================================
# CHK — two checks of C2 (checks after seeing the results · pre-registered verdicts are not changed)
#   ① convergence sensitivity: in C2 the loss of the fixed spatial map (whatwhere2) was still decreasing at 1200 steps (median decrease over the last 10% of steps S-RN 8.6% · I-RN 8.0%)
#      → refit position mean · main rule · fixed spatial map · position-wise linear with 1200 and 3600 steps on the same 46 networks · same axes · same λ (values chosen in C2) and compare
#      → re-judge H1 (main rule > position mean) · H3 (main rule ≥ fixed spatial map − .01) with the 3600-step results (sensitivity analysis, same decision rule)
#   ② paper figures: redraw Shapes3D maps on the noise-free original images (maps saved in C2 unchanged · originals at the same test indices)
# ===================================================================================================
CC['OLD']['rn18'].insert(0, (f'{D_}/xai_C2/models', 'rn18_s{seed}.pt'))                                         # CIFAR seeds 5–12 newly trained in C2, as is
C2D = f'{D_}/xai_C2'; CHK = dict(MULT=[1, 3], RULES=['mean', MAIN, 'whatwhere2', 'poslin'])

def chk_one(A, l, XP, XE, seed, R2):
    T0 = time.time(); HP, HE = hidden(A, XP, l), hidden(A, XE, l)
    if HP.numel() + HE.numel() > 6e8: HP, HE = HP.half(), HE.half()
    yp, ye = predict(A, XP), predict(A, XE); ncls = int(torch.tensor(logits(A, XE[:2])).shape[1]); hw = grid_hw(A, HP); k = K_MAIN
    ST = dict_stats(A, l, HP, seed, ncls); S2, Si2 = msqrt(ST['S'], 0.5), msqrt(ST['S'], -0.5); q = top_eig(S2 @ ST['M'] @ S2)[:k]; Dc = Lin(q @ Si2, q @ S2, ST['mu'])   # same axes as C2 (same seeds · samples)
    Cp, Ce = codes(A, Dc, HP), codes(A, Dc, HE); out = {}
    for rule in CHK['RULES']:
        lam = R2['k'][str(k)]['tvo'][rule]['lam']; out[rule] = {'c2_fid': R2['k'][str(k)]['tvo'][rule]['fid'], 'lam': lam}
        for mu_ in CHK['MULT']:
            PC['STEPS'] = PC0['STEPS']*mu_; sc = fit_scorer(rule, Cp, yp, hw, ncls, seed, lam)
            out[rule][f'x{mu_}'] = {'fid': float((sc_logits(sc, Ce).argmax(1).cpu().numpy() == ye).mean()), 'loss': sc.loss, 'conv': sc.conv}; del sc
        PC['STEPS'] = PC0['STEPS']
    print(f'  ({time.time()-T0:.0f}s) ' + ' | '.join(f'{r_}: C2 {v["c2_fid"]:.3f} · ×1 {v["x1"]["fid"]:.3f} (convergence {v["x1"]["conv"]:.3f}) · ×3 {v["x3"]["fid"]:.3f} (convergence {v["x3"]["conv"]:.3f})' for r_, v in out.items()), flush=True)
    return out

RES = {}
for grp, rho, s in JOBS:
    PC.clear(); PC.update(PC0); PC.update(PCG.get(grp, {})); f_ = f'{OUT}/chk_{grp}_rho{rho}_s{s}.json'; f2 = f'{C2D}/r3_{grp}_rho{rho}_s{s}.json'
    if os.path.exists(f_): RES[(grp, rho, s)] = json.load(open(f_)); continue
    if not os.path.exists(f2): print(f'  ⚠ no C2 result: {f2}'); continue
    A = model_of(grp, rho, s)
    if A is None: print(f'  ⚠ no model: {grp} ρ={rho} seed {s}'); continue
    l = explain_layer(A); print(f'\n[{grp} ρ={rho} seed {s}]', flush=True)
    if grp[0] in 'CI': ND = data_of(grp); XP, XE = ND.XP[:PC['N_USE']], ND.Xte[:PC['N_USE']]
    else: S = data_of(grp); XP, XE = S.XPR[:PC['N_USE']], S.XTE[:PC['N_USE']]
    R = chk_one(A, l, XP, XE, s, json.load(open(f2))); json.dump(jsonable(R), open(f_, 'w')); RES[(grp, rho, s)] = R
    del A; torch.cuda.empty_cache(); PC.clear(); PC.update(PC0)

# ---------------------------------------------------------------- convergence sensitivity table · re-judging (sensitivity analysis)
P_d = f'{OUT}/paper'; os.makedirs(P_d, exist_ok=True)
T = pd.DataFrame([{'group': g_, 'rho': r_, 'seed': s_, 'rule': ru, 'c2_fid': v['c2_fid'], **{f'{m_}_{x_}': v[m_][x_] for m_ in ['x1', 'x3'] for x_ in ['fid', 'loss', 'conv']}} for (g_, r_, s_), R in RES.items() for ru, v in R.items()])
T.to_csv(f'{P_d}/CHK_conv_all.csv', index=False)
print('\n=== convergence sensitivity (group means; ×1 = 1200 steps · ×3 = 3600 steps; conv = relative loss decrease over the last 10% of steps) ===\n' + T.groupby(['group', 'rule'])[['c2_fid', 'x1_fid', 'x3_fid', 'x1_conv', 'x3_conv']].agg(['mean']).round(4).to_string())
rows_all = []
for grp in ['C-RN', 'S-RN', 'S-ViT', 'C-ViT', 'I-RN']:
    Rs = [R for (g_, _, _), R in RES.items() if g_ == grp]
    if not Rs: continue
    kd = 'report' if grp in ('C-ViT', 'I-RN') else 'diff'; rows = []
    for x_ in ['x1', 'x3']:
        rows.append(dict(no=f'H1 ({x_})', desc=f'fidelity: {MAIN} > mean, threshold .01 [{x_}]', fam=f'sensitivity {x_}', d=[R[MAIN][x_]['fid'] - R['mean'][x_]['fid'] for R in Rs], thr=0.01, kind=kd))
        rows.append(dict(no=f'H3 ({x_})', desc=f'non-inferior fidelity: {MAIN} ≥ whatwhere2 − .01 [{x_}]', fam=f'sensitivity {x_}', d=[R[MAIN][x_]['fid'] - R['whatwhere2'][x_]['fid'] + 0.01 for R in Rs], thr=0.0, kind=kd))
        rows.append(dict(no=f'R ({x_})', desc=f'(reported) position-wise linear − {MAIN} [{x_}]', fam='reported', d=[R['poslin'][x_]['fid'] - R[MAIN][x_]['fid'] for R in Rs], thr=0.0, kind='report'))
    for r_ in judge1(rows): rows_all.append({'group': grp, **{k_: v for k_, v in r_.items() if k_ != 'd'}})
V = pd.DataFrame(rows_all); print('\n=== sensitivity verdicts (same rule as the C2 verdicts; pre-registered verdicts are not changed) ===\n' + V[['group', 'no', 'n', 'win', 'mean', 'ci_lo', 'ci_hi', 'p_holm', 'verdict']].to_string())
V.to_csv(f'{P_d}/CHK_verdict.csv', index=False)

# ---------------------------------------------------------------- paper figures: Shapes3D maps on noise-free originals
def clean_figs():
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    S = data_of('S-RN'); D = S.D
    def clean_x(seed, n=8):                                                                                       # same map indices as C2 run_main (rng 1300 + seed) → test indices → originals
        mi = np.sort(np.random.default_rng(1300 + seed).choice(min(PC0['N_USE'], len(S.TE_I)), PC0['N_MAP'], replace=False))[:n]; x = D.img(S.TE_I[mi])
        x = x.float()/255 if x.dtype == torch.uint8 else x.float(); return x.cpu().numpy()
    def img(x): x = np.asarray(x, np.float32); x = x.transpose(1, 2, 0) if x.shape[0] in (1, 3) else x; return np.clip(x, 0, 1)
    def ov(ax, x, m):
        v = float(np.abs(m).max()) + 1e-12; ax.imshow(img(x).mean(-1), cmap='gray', vmin=0, vmax=1); ax.imshow(np.asarray(m, np.float32), cmap='bwr', vmin=-v, vmax=v, alpha=0.6); ax.axis('off')
    COLS = [('ours', 'Ours (tv-O + GS-spot)'), ('orig', 'Original (pos. mean)'), ('static', 'Static map (SF-type)'), ('gradcam', 'Grad-CAM (same layer)'), ('gradcam_last', 'Grad-CAM (last)'), ('ig', 'IG')]
    for grp, rho_, s_ in [('S-RN', 0.75, 2), ('S-ViT', 0.75, 2)]:
        f_ = f'{C2D}/maps_{grp}_rho{rho_}_s{s_}.npz'
        if not os.path.exists(f_): continue
        Z = np.load(f_); X0 = clean_x(s_); n = 4; fig, axs = plt.subplots(n, len(COLS) + 1, figsize=(2*(len(COLS) + 1), 2*n), squeeze=False)
        for i in range(n):
            axs[i, 0].imshow(img(X0[i])); axs[i, 0].axis('off')
            for j, (k_, t_) in enumerate(COLS):
                ov(axs[i, j + 1], X0[i], Z[f'm_{k_}'][i])
                if i == 0: axs[i, j + 1].set_title(t_, fontsize=8)
        fig.suptitle(f'{grp} (rho={rho_}, seed {s_}): explanation maps for the predicted class, shown on the noise-free test image', fontsize=9); fig.tight_layout(); fig.savefig(f'{P_d}/fig_maps_{grp}_clean.png', dpi=200); plt.close(fig)
    fs = [(r_, f'{C2D}/maps_S-RN_rho{r_}_s2.npz') for r_ in [0.25, 0.75, 0.9]]; fs = [(r_, f_) for r_, f_ in fs if os.path.exists(f_)]
    if fs:
        X0 = clean_x(2); n = 4; fig, axs = plt.subplots(len(fs) + 1, n, figsize=(2*n, 2.1*(len(fs) + 1)), squeeze=False)
        for i in range(n): axs[0, i].imshow(img(X0[i])); axs[0, i].axis('off')
        axs[0, 0].set_title('test images (noise-free)', fontsize=8, loc='left')
        for r, (rho_, f_) in enumerate(fs, start=1):
            Z = np.load(f_); RR = json.load(open(f'{C2D}/r3_S-RN_rho{rho_}_s2.json'))
            for i in range(n): ov(axs[r, i], X0[i], Z['m_ours'][i])
            axs[r, 0].set_title(f'rho={rho_}   floor reliance={RR["R_floor"]:.2f}   floor share of our map={RR["floor_share"]["ours"]:.2f}', fontsize=8, loc='left')
        fig.suptitle('Shortcut audit: our maps for ResNet-18s trained with stronger floor-colour shortcut (same test images)', fontsize=9); fig.tight_layout(); fig.savefig(f'{P_d}/fig_shortcut_maps_clean.png', dpi=200); plt.close(fig)
    print('figure saved:', sorted(f_ for f_ in os.listdir(P_d) if f_.endswith('.png')), flush=True)
try: clean_figs()
except Exception as e: print('⚠ figure failed:', repr(e), flush=True)

# ===================================================================================================
# end: environment record · zip · download
# ===================================================================================================
import torch as _t, shutil as _sh
with open(f'{OUT}/env.txt', 'w') as f:
    f.write(f'GPU: {_t.cuda.get_device_name(0) if _t.cuda.is_available() else "cpu"}\npython {sys.version}\ntorch {_t.__version__}  sklearn {sklearn.__version__}\ncore sha1 64099c2a4cd7\n')
    f.write(subprocess.run([sys.executable, '-m', 'pip', 'freeze'], capture_output=True, text=True).stdout)
print(f'\ntotal {(time.time()-T_ALL)/60:.1f}min', flush=True)
import zipfile as _zf
zp = f'/content/xai_{VERSION}_results.zip' if os.path.exists('/content') else f'{OUT}/../xai_{VERSION}_results.zip'
with _zf.ZipFile(zp, 'w', _zf.ZIP_DEFLATED) as z:                                  # results only (model files excluded)
    for r_, _, fs in os.walk(OUT):
        if '/models' in r_: continue
        for f_ in fs:
            if f_.endswith(('.json', '.csv', '.tex', '.png', '.pdf', '.py', '.txt', '.npz')): z.write(os.path.join(r_, f_), os.path.relpath(os.path.join(r_, f_), OUT))
print('results zip:', zp)
try:
    from google.colab import files; files.download(zp)
except Exception as e: print('automatic download skipped:', e)
